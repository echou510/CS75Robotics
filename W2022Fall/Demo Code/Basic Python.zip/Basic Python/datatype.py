# Comments 
i = 1     # integer 
f = 3.4   # floating point
s = "String"   # there is no separate char/string.  '', "", """ """
b = 3 > 4 

# all data in python are objects. 
fstr = str(f)  # data type conversion
ix = int("3")