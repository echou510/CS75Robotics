# String "", '', """ """
# String are text.   array of characters. 
s = "3.0"
f = float(s)
print(f)
print("The length of the string s: ", len(s))

# Indexing
    #  987654321  (-)
    #01234567890
s = "abcdefghikj"
print("s[3]=", s[3])

# slicing
# s[start:end:step] end is not inclusive. 
# s[start:end] === s[start:end:1]
print("s[2:4] = ", s[2:4])   # substring 

# s[:end] === s[0:end:1]
print("s[:7]=", s[:7])
# s[start:] === s[start:len(s):1]
print("s[2:]=", s[2:])  

# negative indexing 
# s[-3] === s[len(s)-3]
print("s[-3]=", s[-3])

# tuples ()
# fixed length data entity: fixed length array
# no change, immutable 
# vector 
# points 
p1 = (2, 3)  # (x, y), 2D 
p2 = (2, 3, 4)  # (x, y, z), 3D
print(p1)
print(p2)
print("p1[0]=", p1[0])   # p1.getX()
#p1[0] = 4
#print("p1=", p1)

p1 = (4, p1[1])
print("p1=", p1)

import numpy as np
a = np.array(p2)
print(a)

# list [] 
# flexible length, you can add, remove, or insert, append
# mutable, you can update the elements in the list. 
# quick conversion to numpy array
alist = [1, 3, 5, 7, 9]
alist.append(11)  # append to the tail. 
print("alist=", alist)
alist.insert(2, 4) # insert to the location. 
print("alist=", alist)
removed_data = alist.pop()  # pop out the tail 
print("alist=", alist)
print("removed=", removed_data)
removed_data = alist.pop(2)
print("alist=", alist)
print("removed=", removed_data)

alist2 = [2, 4, 6, 8, 10]
alist3 = alist+alist2
print("alist3=", alist3)
alist3.sort()
print("alist3=", alist3)

arr = np.array(alist)
print("arr=", arr)

# set {}
aset = {'a', 'b', 'c'}
bset = {'a', 'd', 'e'}
cset1 = aset | bset     # union | 
print("Union(aset, bset)=", cset1)
cset2 = aset & bset     # intersection &
print("Intersection(aset, bset)=", cset2)
if ('a' in aset): 
    print('a is in set A')
else: 
    print('a is not in set A')

# dictionary { property: value }
# map 
d = {
    'a': 1, 
    'b': 2, 
    'c': 3,
    'd': 4, 
    'e': 5
}
print(d)

print('d[\'a\']=', d['a'])

properties = d.keys() 
values = d.values() 
plist =list(properties)
print(plist)
vlist = list(values)
print(vlist)
dtuples = list(d.items())  # list of tuples
print(dtuples)

# zipping 
ztuples = list(zip(plist, vlist))
print(ztuples)

recovered_d = dict(ztuples)
print(recovered_d)