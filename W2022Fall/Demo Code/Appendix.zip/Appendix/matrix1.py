import numpy as np 

# (2, 2) is tuple, is the shape of the matrix
# (row, col)
m = np.zeros((2, 2))
print(m)
print()

a = np.array([1, 2, 3, 4, 5, 6, 7, 8])
a = a.reshape(2, 4)
print(a)
aT = a.T
print()
print(aT)