import numpy as np
a = [7, 9, 1, 2, 8, 10, 5, 4, 3, 6]

a = np.array(a)
print("Max: ", a.max())
print("Min: ", a.min())
print("Sum: ", a.sum())

def avg(*args):  # group the args into a list 
    return np.array(args).sum()/len(args) 

def makeArray(*args): 
    return np.array(args)

a5 = avg(1, 3, 5, 7, 9)
print(a5)

arr = makeArray(1, 3, 5, 6, 2, 4)
print(type(arr))
print(arr)