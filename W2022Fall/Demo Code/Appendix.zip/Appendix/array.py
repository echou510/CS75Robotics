alist = [1, 2, 3]

print(alist)

alist.append(4)
print(alist)

alist.pop()
print(alist)

alist.pop(1)  # 1 is index 
print(alist)
