import numpy as np 

a30 = np.deg2rad(30)
a45 = np.deg2rad(45)
v1 = np.array([np.cos(a30), np.sin(a30)])
v2 = np.array([np.cos(a45), np.sin(a45)])
p12 = v1 * v2

print(p12)

v = np.array([0, 1, 2, 3, 4, 5, 6, 7])

# [s:e:j] # e: ending index element will not be included. 
# v[0:len(v):1]
print(v[::])  # print(v)
# v[:3]  v[0:3]
print(v[:3])
# v[-1]  == v[len(v)-1]
print(v[-1])
print(v[-5]) # v[len(v)-5] == v[3]
print(v[-1::-1])
print(v[-1::-2])