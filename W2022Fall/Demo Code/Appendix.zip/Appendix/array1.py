import numpy as np 
alist = [1, 2, 3]

arr = np.array(alist)
print(type(arr))
print(arr)

blist = list(arr)
print(blist)
print(type(blist))