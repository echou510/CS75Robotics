import numpy as np 

e = 1E-9

def rx(start, end): 
    span = end - start 
    x = np.random.random()*(span+e)+start  # 0<= x < 1, --. start<= x < end+e
    while x>end:  # exit: x<= end
        x = np.random.random()*(span+e)+start
    return x 

z3 = np.zeros(3)
print(z3)
O3 = np.ones(3)
print(O3)

# random
r3 = np.random.random(3)  #   0<= x < 1
print(r3)

r32 = np.array([rx(-3, 3) for t in range(3)])
print(r32)


