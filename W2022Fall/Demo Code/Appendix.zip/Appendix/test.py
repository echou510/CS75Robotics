from pylab import * 
import numpy as np 
x = linspace(-6.28, 6.28, 101)
y = [np.sin(t) for t in x]

figure()
plot(x, y, 'green') 
show()