# simple porportional controller. 
import numpy as np
from pylab import * 

Time = 30.0       # total simulation time
Precision = 0.1   # 10 ms 
STEPS = int(Time/Precision)+1

Kp = 1.5

t = np.linspace(0, Time, STEPS)

# preparation of the signals
Xd = np.zeros(STEPS) 
u = np.zeros(STEPS)
Xe = np.zeros(STEPS)
e = np.zeros(STEPS)
for i in range(int(len(t)/6), int(len(t)/2)): 
    Xd[i] = 1.0 


# time-based simulation 
for tick in t: 
    tick = int(tick/Precision+0.5)

    if (tick !=0): 
        e[tick] = Xd[tick]-Xe[tick-1]
    u[tick] = Kp * (e[tick])
    if (tick !=0): 
        Xe[tick] = Xe[tick-1] + u[tick]

# Generate Graphics
fig, ax = subplots(3, 1)
ax[0].plot(t, Xd, 'r')
ax[0].plot(t, Xe, 'b')
ax[0].set_ylabel("Xd(red)/Xe(blue)")
ax[1].plot(t, u, 'orange')
ax[1].set_ylabel("u(t)")
ax[2].plot(t, e, 'g')
ax[2].set_ylabel("e(t)")
xlabel("time (sec)")
show() 

