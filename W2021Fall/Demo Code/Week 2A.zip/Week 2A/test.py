from pylab import *
import numpy as np

z = np.array([1, 0]).T
phi = math.pi * 30/180      # radian for 30 degree 
M = np.array([[np.cos(phi), -np.sin(phi)],[np.sin(phi), np.cos(phi)]])

z2 = M.dot(z)
print(z2)
