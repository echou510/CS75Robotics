from pylab import *
import numpy as np 
from pprint import *

theta = np.linspace(0, 2*np.pi, 361)  # a theta from 0 to 360 
x = np.array([np.cos(t) for t in theta]) 
y = np.array([np.sin(t) for t in theta])
 
p = np.array(list(zip(x, y)))   # p is the circle represented in array of points 
U = np.array([1, 1])
Pnew = p + U 

X = np.array([c[0] for c in Pnew])
Y = np.array([c[1] for c in Pnew])

phi = math.pi * 30/180      # radian for 30 degree 
M = np.array([[np.cos(phi), -np.sin(phi)],[np.sin(phi), np.cos(phi)]])
Pnew = [np.array(c).T for c in Pnew]

Protate = [M.dot(c).T for c in Pnew]   # 
Xr = np.array([c[0] for c in Protate])
Yr = np.array([c[1] for c in Protate])

pprint(p)
pprint(Pnew)
pprint(Protate)

figure()
plot(x, y, 'r')
plot(X, Y, 'b')
plot(Xr, Yr, 'g')
show()

