import numpy as np
p = np.array([2, 3])
U = np.array([1, 2]) 

P = p + U 

print(P)







