from pylab import *
import numpy as np 
from pprint import *
PRECISION = 10 
p0 = np.array([1, np.sqrt(3), 1]).T  # column vector 

# Scaling
Sx = 2
Sy = 3
S = np.array([[Sx, 0, 0], [0, Sy, 0], [0, 0, 1]])
p1 = S.dot(p0)

print("p0=")
pprint(p0)
print()
print("p1=")
pprint(p1)

# Rotation 
theta = 90/180*np.pi   # converting the degree to radian 
CT = np.cos(theta)
ST = np.sin(theta)
R = np.array([[CT, -ST, 0], [ST, CT, 0], [0, 0, 1]])

p2 = R.dot(p0)
print()
print("p2=")
pprint(p2)

# Translation (Displacement)
a = 1
b = 1
T = np.array([[1, 0, a], [0, 1, b], [0, 0, 1]])
p3 = T.dot(p0)

print()
print("p3=")
pprint(p3)


# combine rotation and displacement
theta = 30/180*np.pi   # converting the degree to radian 
u = 0 
v = 1
CT = np.cos(theta)
ST = np.sin(theta)
R = np.array([[CT, -ST, u], [ST, CT, v], [0, 0, 1]])

p4 = R.dot(p0)
p4 = np.round(p4, PRECISION)
print()
print("p4=")
pprint(p4)
