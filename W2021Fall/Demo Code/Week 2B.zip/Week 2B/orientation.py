from pylab import *
import numpy as np 
from pprint import *
PRECISION = 10 

# Homogenuous Matrix Solution for Orientation Matrix
p0 = np.array([1, 0, 0, 1]).T  # column vector 

R = np.array([[0, 1, 0, 0], [0, 0, 1, 0], [-1, 0, 0, 0], 
[0, 0, 0, 1]])

p0_1 = R.dot(p0).T

print("p0_1=", p0_1)

# Traditional Matrix for Orientation
q0 = np.array([1, 0, 0]).T  # column vector 
Q = np.array([[0, 1, 0], [0, 0, 1], [-1, 0, 0]])
q0_1 = Q.dot(q0).T

print("q0_1=", q0_1)