from scipy.integrate import odeint
import numpy as np 
from pylab import *

# Define a function which calculates the derivative
def dy_dx(y, x):
    return np.sin(x)

t = np.linspace(0,5,100)
y0 = 1.0  # the initial condition
ys = odeint(dy_dx, y0, t)
ys = np.array(ys).flatten()

figure()
plot(t, ys, 'r')
show()