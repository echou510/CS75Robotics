import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

points = 10000 
DT = 1/10000

def derivative(f, x, h): 
    fp = (f(x+h)-f(x))/h
    return fp

def integrate(f, F0, t): 
    z = [F0]
    for i in range(len(t)-1): 
        F1 = F0 + f(t[i])*(t[i+1]-t[i])
        F0 = F1
        z.append(F1)
    return z 


t = np.linspace(0, 10, points+1)
F0 = -1  # initial value for integral 

y = [np.sin(ty) for ty in t]
yp = [derivative(np.sin, x, DT) for x in t]

# dy_dt for differential equation for ODE
def dy_dt(y, x):
    return np.sin(x)

yi = odeint(dy_dt, F0, t) 

# custom designed integrate
yi2 = integrate(np.sin, F0, t)


print(len(yi))

f, ax = plt.subplots(4, 1)
ax[0].plot(t, y, 'b')
ax[1].plot(t, yp, 'g')
ax[2].plot(t, yi, 'orange')
ax[3].plot(t, yi2,'r')
plt.show()
