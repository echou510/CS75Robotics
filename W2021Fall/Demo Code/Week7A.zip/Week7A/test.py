from pylab import *
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

def dsin_dt(f, x): 
    return f(x)

t = np.linspace(0, 1.0, 11)
y = odeint(dsin_dt, 0, t, args=(np.sin))

figure()
plot(t, y, 'r')
show()