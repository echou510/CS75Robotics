import numpy as np 

a = np.array([1, 2, 3])
z = np.ones(3)
w = np.array([4, 5, 6])

b = a + 1
print("b[]=", b)
c = a + z
print("c[]=", c)
d = a + w
print("d[]=", d)

m = [1, 2, 3, 4]
m = np.array(m).reshape((2, 2))
z = np.ones((2, 2))

k = m + z
print("k[[]]: \n", k)

data = [x for x in range(1, 11)]
data = np.array(data)
print("data[0:5]:", data[0:5])
print("data[0:8:3]", data[0:8:3])
print("data[::3]", data[::3])

toRad = np.pi/180
v30 = np.array([np.cos(30*toRad), np.sin(30*toRad)])
v90 = np.array([np.cos(90*toRad), np.sin(90*toRad)])

product = v30.dot(v90)
print(product)

m = [1, 2, 3, 4]
m = np.array(m).reshape((2, 2))
print(m)
mt = m.T
print(mt)