from pylab import *

x = linspace(-6.28, 6.28, 721)
y = [sin(t) for t in x]


for t in x: 
    print(t)

figure()
plot(x, y, 'green')
show()