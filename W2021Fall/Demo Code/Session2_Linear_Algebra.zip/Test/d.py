from pylab import *
import numpy as np
a = [1, 2, 3] # list

m = [
 [1, 2], 
 [2, 3]
]

# convert the list of lists to 2D array (matrix)
ary = np.array(a)
mat = np.array(m)

print(ary)
print(ary.shape)
print(mat)
print(mat.shape)

row = mat.shape[0]
col = mat.shape[1]

print("row=", row, "col=", col)