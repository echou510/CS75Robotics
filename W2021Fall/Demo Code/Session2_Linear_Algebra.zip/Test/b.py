from pylab import *
import numpy as np

x = np.linspace(-1, 1, 101)
y = [t**2  for t in x]

figure()
plot(x, y, 'r')
show()
