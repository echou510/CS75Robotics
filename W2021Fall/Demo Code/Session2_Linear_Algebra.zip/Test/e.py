from pylab import *
import numpy as np

a = array([5, 6, 1, 2, 7, 9, 3, 4, 10, 8]) # numpy.array

print(a.max())
print(a.min())
print(a.sum())
print(a.size)

m = array([[1, 2], [3, 4]])
print(m.ndim)
print(m.shape)
print(m.size)

m2 = a.reshape((2, 5)) # shape is a tuple data 
print(m2)

a = array([1, 2, 3, 4, 5, 6, 7, 8, 9]) 
m3 = a.reshape((3, 3))
print(m3)

a = [t for t in range(1, 28)]
print(a)
mt3 = array(a).reshape((3, 3, 3))
print(mt3)

a10 = np.zeros(10)
a10 = list(a10)  # convert numpy array back to python list
print(a10)

a10.append(1.0)
a10.append(2.0)

print(a10)

m12 = np.array(a10).reshape(3, 4)
print(m12)

"""
b = np.zeros(4)
b.append(10)
print(b)
"""

m33 = np.random.randint(1, 7, size=(3, 3))
print(m33)

x = np.random.random()  # [0, 1)
e = 1E-9
x = np.random.random()*(6+e)- 3.0          # [-3, 3)

while x > 3: # exit condition of x <= 3
    x = np.random.random()*(6+e)- 3.0 

# post-condition for while:    -3 <= x <= 3    [-3. 3]