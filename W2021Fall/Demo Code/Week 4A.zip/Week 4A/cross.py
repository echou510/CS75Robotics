from pylab import *
import numpy as np 

A = np.array([1, 1, 0]) 
B = np.array([0, 1, 1])

C = np.cross(A, B)

print(C)  # [ 1 -1  1]