from pylab import *
t = linspace(0, 10, 101)

def f(a, cL, cU):
    b = []
    y = 0
    for i in range(len(a)-1):
        x = a[i+1]-a[i]
        if (x < 0):
            if a[i]>=cU: y=0
            b.append(y)
        else:
            if a[i]<=cL: y=1
            b.append(y)
    return b

u = [sin(t[i]) for i in range(len(t))]
s = [u[i] for i in range(len(t))]
s.insert(0, -1)
p = f(s, -0.9, 0.9)
cUU = [0.9 for i in range(len(t))]
cLL = [-0.9 for i in range(len(t))]
fig, axs = plt.subplots(2)
fig.suptitle('On_off Controller')
axs[0].plot(t, u)
axs[0].plot(t, cUU, 'y')
axs[0].plot(t, cLL, 'g')
axs[1].plot(t, p)
axs[0].set_xlabel("Time (sec)")
axs[1].set_xlabel("Time (sec)")
axs[0].set_ylabel("u(t)")
axs[1].set_ylabel("On(1)/Off(0)")
show()