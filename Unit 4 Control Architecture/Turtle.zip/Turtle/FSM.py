from turtle import *
# program setups
Sname = ["Forward", "Turn R"]
bgcolor("#f9facf")
t = Turtle()
t.shapesize(1,2,3)
t.pencolor("brown")
t.width(3)

# Robot functions
def r(t):
    t.right(90)
def f(t): 
    t.forward(100)
def next(s, i):
    if (s==0 and i==1):
        return (1, "Change State")
    if (s==0 and i==0):
        return (0, "Same State")
    if (s==1 and i==0):
        return (1, "Same State")
    if (s==1 and i==1):
        return (0, "Change State")

# simulation 
state = 0
simulation_steps = 30

for time in range(simulation_steps):
    print("Step: ", time, ":")
    if (state == 0): f(t)
    if (state == 1): r(t)
    # input by user.  For Robot? Sensor -> Plan -> Act
    user_input = int(input("Enter your control input: "))
    (state, action) = next(state, user_input)
    print(" Next State: %s(%d), Action: %s" % (Sname[state], state, action))
    
