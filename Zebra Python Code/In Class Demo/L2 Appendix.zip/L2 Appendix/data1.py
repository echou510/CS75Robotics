#from numpy import * # merging the namespace
import numpy as np

a = np.cos(2*np.pi)
print(a)
