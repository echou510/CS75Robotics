# data2.py
# author: Eric Chou
# version: 10/30/2020
# Note:
#   import pylab -> numpy, scipy, and matplotlib ---> matlab (Python Matlab)
#
from pylab import *

f = open("data1.csv", "r")
a = []
b = []

# prime-reading
line = f.readline()
print(line)
line = f.readline()
while line:
    tokens = line.strip().split(",")
    print(tokens)
    a.append(int(tokens[0]))
    b.append(int(tokens[1]))
    line = f.readline()

print(a)
print(b)
f.close()

# data visualization
figure()
plot(a, b, 'r')
scatter(a, b)
show()
