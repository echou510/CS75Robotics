# data3.py
# author: Eric Chou
# version 10/30/2020
from pylab import *
import numpy as np

E = 10  # 10 digits after decimal points=

def getRotationalMatrix(angle):
    mm = [np.cos(angle), -np.sin(angle), np.sin(angle), np.cos(angle)]
    mm = np.array(mm)
    mm = mm.reshape((2, 2))
    mm = np.round(mm, E)  # E error level .0000000001
    #print(mm)
    return mm

    
p0 = [1, 0]        # (1, 0)
p0 = np.array(p0)  # convert to numpy array

for T in range(45, 361, 45): 
    Tr  = np.deg2rad(T) # T means theta
    #print(Tr)
    m = getRotationalMatrix(Tr)
    p1 = np.dot(m, p0)
    p1 = np.round(p1, E)  # default E = 0 
    print("Angle ", T, ":")
    print(p1)
    print()

