import numpy as np

predictions = np.array([1, 1, 1])
labels      = np.array([1, 2, 3])
print("predictions: ", predictions)
print("label      : ", labels)
MSE         = np.sum(np.square(predictions-labels))
print("MSE        : ", MSE)