import numpy as np
a = np.arange(6)
print("1-D: ", a)
a.reshape(2, 3)
print("2-D: ", a)
print("Shape: ", a.shape)
print("Dimension: ", a.ndim)
print("Size: ", a.size)
