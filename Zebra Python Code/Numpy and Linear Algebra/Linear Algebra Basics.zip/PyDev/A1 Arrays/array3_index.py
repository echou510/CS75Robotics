import numpy as np
data = np.arange(0, 11)  # 0-10
print("data    : ", data)
print("data[1] : ", data[1])
print("data[-3]: ", data[-3])
print("data[2:5] : ", data[2:5])
print("data[-1:-9:-2] : ", data[-1:-9:-2])
print("data[-1:0] : ", data[-1:0])
print("data[-1:0:-1] : ", data[-1:0:-1])
print("data[3:-2] : ", data[3:-2])
print("data[:-2] : ", data[:-2])
print("data[2:] : ", data[2:])
