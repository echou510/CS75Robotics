import numpy as np
data = np.array([
 [1, 2],
 [3, 4],
 [5, 6]
])
print(data)
ones32 = np.ones((3, 2))
ones = np.ones(2)
one  = 1
print("data+ones32:\n", (data+ones32))
print("data+ones:\n", (data+ones))
print("data+one:\n", (data+one))