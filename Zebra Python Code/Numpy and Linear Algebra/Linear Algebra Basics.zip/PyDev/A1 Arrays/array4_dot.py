import numpy as np

data = np.array([1, 2, 3])
power = [10**i for i in range(6)]
power_of_ten = np.array(power).reshape((3, 2))
print("data:\n", data)
print("power:\n", power_of_ten)
dot_product = data.dot(power_of_ten)
print("dot_product:\n", dot_product)