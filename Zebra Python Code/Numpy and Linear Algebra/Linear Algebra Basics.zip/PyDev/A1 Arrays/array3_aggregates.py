import numpy as np
data = np.arange(0, 11)  # 0-10
print("data      : ", data)
print("data.sum(): ", data.sum())
print("data.max(): ", data.max())
print("data.min(): ", data.min())
print("np.average(a): ", np.average(data))
print("np.mean(a): ", np.mean(data))
print("np.median(a): ", np.median(data))
print("np.std(a): ", np.std(data))
print("np.var(a): ", np.var(data))