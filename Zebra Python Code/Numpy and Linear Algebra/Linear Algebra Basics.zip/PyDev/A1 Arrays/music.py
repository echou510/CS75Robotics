import numpy as np
import pandas as pd

m = pd.read_csv("music.csv")
print(type(m))
print(m)
print()
print(type(m.keys()))
header = list(m.keys())
print("Header: ", header)
print()
ma = m.values
print(type(ma))
print(ma)