import numpy as np

data = np.array([1, 2, 3])
power = [10**i for i in range(6)]
power_of_ten = np.array(power).reshape((3, 2))
c0 = power_of_ten[:, 0]
c1 = power_of_ten[:, 1]
print("data:", data)
print("c0:", c0)
print("c1:", c1)
x0 = data.dot(c0)
x1 = data.dot(c1)
print("sum of data * c0 : ", x0)
print("sum of data * c1 : ", x1)
s0 = sum(data * c0)
s1 = sum(data * c1)
print("sum of data * c0.T : ", s0)
print("sum of data * c1.T : ", s1)
