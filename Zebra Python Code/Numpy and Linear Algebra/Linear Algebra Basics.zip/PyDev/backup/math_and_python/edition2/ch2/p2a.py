# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p2a.py
"""

import numpy as np

A = np.array([[1, 2], [3, 4]])
C = np.array([[5, 6], [7, 8]])
E = np.array([[1, 0], [0, 1]])
print 'A = ', str(A)
print 'A.E = ', np.dot(A, E)
print 'E.A = ', np.dot(E, A)
inv_A = np.linalg.inv(A)
print 'inverse matrix of A = ', inv_A
print 'A.inv_A = ', np.dot(A, inv_A)
print 'matrices product:'
print 'C = ', str(C)
print 'A.C = ', np.dot(A, C)
print 'C.A = ', np.dot(C, A)
