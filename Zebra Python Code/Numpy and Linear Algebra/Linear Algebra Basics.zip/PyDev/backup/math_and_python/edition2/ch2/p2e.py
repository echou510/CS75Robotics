# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p2e.py
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

# resuelve la ecuación az² +bz + c = 0
a = 1.0
b = 2.0
c = 3.0


def equation():
    if b >= 0:
        strb = '+ ' + str(b)
    else:
        strb = str(b)
    if c >= 0:
        strc = '+ ' + str(c)
    else:
        strc = str(c)
    strec = '$' + str(a) + 'z^{2} ' + strb + 'z ' + strc + '=0$\n'
    strec = strec + '$z_{1}=' + str(z1) + '$\n$z_{2}=' + str(z2) + '$'
    return strec

plt.figure()
rc('text', usetex=True)
rc('font', family='serif')
plt.ylabel('Im')
plt.xlabel('Re')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.grid(b=None, which='major')


def pointsR(t, sol1, sol2):
    x = []
    y = [0, 0, 0]
    plt.ylim(-1, 1)
    #-b/2a
    x.append(t)
    #z1 y z2
    x.append(float(sol1))
    x.append(float(sol2))
    xmin = np.floor(x[np.argmin(x)])
    xmin = xmin - abs((xmin / 10))
    xmax = np.ceil(x[np.argmax(x)])
    xmax = xmax + abs((xmax / 10))
    plt.xlim(xmin, xmax)
    plt.plot(x, y, 'ko')
    if sol1 == sol2:
        plt.text(1.01 * x[1], -0.25, '$z_{1}$',
                 horizontalalignment='center', color='blue',
                 fontsize=20)
        plt.text(0.99 * x[2], -0.25, '$z_{2}$',
                 horizontalalignment='center', color='red',
                 fontsize=20)
        plt.text(x[0], 0.15, r"$\displaystyle\frac{-b}{2a}$",
                 horizontalalignment='center', color='green',
                 fontsize=16)
    else:
        plt.text(x[1], 0.15, '$z_{1}$',
                 horizontalalignment='center', color='blue',
                 fontsize=20)
        plt.text(x[2], 0.15, '$z_{2}$',
                 horizontalalignment='center', color='red',
                 fontsize=20)
        plt.text(x[0], 0.15, r"$\displaystyle\frac{-b}{2a}$",
                 horizontalalignment='center', color='green',
                 fontsize=16)
    textstr = equation()
    props = dict(boxstyle='round', facecolor='#FCE945',
                 alpha=0.9)
    plt.text(0.9 * xmin, 0.90,
             textstr, fontsize=14, verticalalignment='top',
             bbox=props)


def pointsC(t, re, im):
    x = []
    y = [0]
    #-b/2a
    x.append(t)
    #z1 y z2
    x.append(float(re))
    x.append(float(re))
    #xmin = np.floor(x[np.argmin(x)])
    xmin = x[0] - abs((x[0] / 5))
    xmax = np.ceil(x[np.argmax(x)])
    xmax = xmax + abs((xmax / 10))
    if xmax <= 0:
        xmax = abs(xmin / 3)
    if xmin >= 0:
        xmin = -1 * xmax / 3
    #print xmin, xmax
    plt.xlim(xmin, xmax)
    y.append(float(im))
    y.append(float(-im))
    ymin = np.floor(y[np.argmin(y)])
    ymin = ymin - abs((ymin / 10))
    ymax = np.ceil(y[np.argmax(y)])
    ymax = ymax + abs((ymax / 10))
    plt.ylim(ymin, ymax)
    plt.plot(x, y, 'ko')
    plt.text(1.05 * re, 1.15 * y[1], '$z_{1}$',
             horizontalalignment='center', color='blue',
             fontsize=20)
    plt.text(1.05 * re, 1.05 * y[2], '$z_{2}$',
             horizontalalignment='center', color='red',
             fontsize=20)
    if x[0] == 0:
        plt.text(xmax, 0.25, r"$\displaystyle\frac{-b}{2a}$",
                 horizontalalignment='left', color='green',
                 fontsize=16)
    else:
        plt.text(x[0], 0.25, r"$\displaystyle\frac{-b}{2a}$",
                 horizontalalignment='center', color='green',
                 fontsize=16)
    textstr = equation()
    props = dict(boxstyle='round', facecolor='#FCE945',
                 alpha=0.9)
    if re >= 0:
        plt.text(0.9 * xmin, 0.9 * ymax,
                 textstr, fontsize=14,
                 verticalalignment='top', bbox=props)
    else:
        plt.text(0.3 * xmin, 0.90 * ymax,
                 textstr, fontsize=14,
                 verticalalignment='top', bbox=props)

if a != 0:
    radicando = b ** 2 - 4 * a * c
    t1 = -b / (2 * a)
    t2 = radicando / (2 * a)
    if radicando > 0:  # la ecuación tiene dos soluciones reales
        z1 = "%6.4f" % (t1 + t2)
        z2 = "%6.4f" % (t1 - t2)
        pointsR(t1, z1, z2)
    elif radicando == 0:  # la ecuación tiene una raíz real doble
        z1 = "%6.4f" % t1
        z2 = z1
        pointsR(t1, z1, z1)
    else:
        aa = float("%6.4f" % t1)
        bb = float("%6.4f" %
                   (np.sqrt(-radicando) / (2 * a)))
        z1 = complex(aa, bb)
        z2 = complex(aa, -bb)
        plt.plot([0, aa], [0, bb], 'b', lw=2)
        plt.plot([0, aa], [0, -bb], 'r', lw=2)
        pointsC(t1, aa, bb)
    print 'z1 = ', z1
    print 'z2 = ', z2
else:
    print 'coefficient a cannot be null'

plt.show()
