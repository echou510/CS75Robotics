# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p2c.py
"""

import numpy as np


def r2(z):
    a = z.real
    b = z.imag
    rdos = a ** 2 + b ** 2
    return rdos


def length(z):
    m = np.sqrt(r2(z))
    return m


def explaincomplex(z):
    explain = (str(z) + '; Re(z) = ' +
               str(z.real) + '; Im(z) = ' +
               str(z.imag) + '; |z| = ' +
               "%6.4f" % length(z) +
               '; r2(z) = ' + str(r2(z)))
    return explain


def str_inverse(z):
    coef = '(1/' + str(r2(z)) + ')'
    conjugate = np.conjugate(z)
    strinverse = coef + '*' + str(conjugate)
    return strinverse


def checkinverse(z):
    print 'z = ' + str(z)
    print 'conjugate of z = ' + str(np.conjugate(z))
    print 'z * conjugate(z) = ', z * np.conjugate(z)
    print 'inverse of z = ' + str_inverse(z)
    print ('z * inv(z) = ' + str(z) +
           ' * [' + str_inverse(z) + '] = (1/' +
           str(r2(z)) + ') * ' + str(np.conjugate(z)) +
           ' = 1')

print 'powers of j:'
j = complex(0, 1)
print 'j^1 = j'
print 'j^2 = ' + str(j * j) + ' = -1'
print 'j^3 = ' + str(-1 * j) + ' = -j'
print 'j^4 = ' + str(-j * j) + ' = 1'
print '--------------------------------'
z1 = 3 + 4j
z2 = complex(-1, 1)
print 'z1 = ' + explaincomplex(z1)
print 'z2 = ' + explaincomplex(z2)
print 'z1 + z2 = ', z1 + z2
print 'z1 - z2 = ', z1 - z2
print 'z1 * z2 = ', z1 * z2
print '--------------------------------'
print 'checking z1 inverse:'
checkinverse(z1)
print '--------------------------------'
print 'checking z2 inverse:'
checkinverse(z2)
