# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p2b.py
"""

import sympy as sy

a, b, r2 = sy.symbols('a b r2')
sy.init_printing(use_unicode=True)

row1 = sy.Matrix([[a, b, 1, 0]])
row2 = sy.Matrix([[-b, a, 0, 1]])
print row1
print row2
print 'r2 = a**2 + b**2'


def printoutput():
    print '-------------'
    print row1
    print row2


def H(row, k):
    for col in range(0, 3):
        Haux = row * k
        return Haux

row2 = row2 + H(row1, b / a)
printoutput()

row2[1] = r2 / a
printoutput()

row2 = row2 * (a / r2)
printoutput()

row1 = row1 + H(row2, -b)
printoutput()

row1[2] = a ** 2 / r2
row1 = row1 * (1 / a)
printoutput()

print
print 'inverse matrix = '
print '(1/r2) . [', row1[2] * r2, ', ', row1[3] * r2, ']'
print '         [', row2[2] * r2, ', ', row2[3] * r2, ']'
