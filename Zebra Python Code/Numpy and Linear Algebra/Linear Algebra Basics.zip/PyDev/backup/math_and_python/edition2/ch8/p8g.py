# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8g.py
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

y0 = 0.0
v0 = 31.08
print 'v0 = ' + "%.2f" % v0 + ' m/s'
g = -9.81
H = (v0 ** 2) / (-2 * g)  # maximum attainable height
print 'maximum height = ', "%.1f" % H, ' m'
maximumrange = 2 * H
print 'maximum range = ', "%.1f" % maximumrange, ' m'
angles_list = [15.0, 30.0, 45.0, 60.0, 85.0]
#vy = v0y - g * t
#time to reach the highest point: tfloor / 2
#vx = v0x
#x = v0x * t
#y = y0 + v0y*t + 0.5*g*t**2
#y = y0 + v0y*x/v0x + (0.5*g/v0x**2)*x**2
#ymax = y0 + v0y*tfloor/2 + 0.5*g*(tfloor/2)**2

print 'angle      ymax      range       time'
for j in range(0, 5):
    alfa = np.deg2rad(angles_list[j])
    v0y = v0 * np.sin(alfa)
    tfloor = - 2 * v0y / g
    v0x = v0 * np.cos(alfa)
    Range = - (v0 ** 2) * np.sin(2 * alfa) / g
    ymax = y0 + (v0y * tfloor / 2) + (0.5 * g * (tfloor / 2) ** 2)
    print (str(angles_list[j]) + "%11.1f" % ymax +
           "%11.1f" % Range + "%11.2f" % tfloor)


def f(x, beta):
    v0x = v0 * np.cos(np.deg2rad(beta))
    #coeficientes a0, a1,... an
    a = [y0, (np.tan(np.deg2rad(beta))), ((0.5 * g) / (v0x ** 2))]
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


pointsnum = 300
x = np.linspace(0, np.ceil(maximumrange), pointsnum)

y15 = np.zeros(pointsnum, float)
y30 = np.zeros(pointsnum, float)
y45 = np.zeros(pointsnum, float)
y60 = np.zeros(pointsnum, float)
y85 = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    y15[i] = f(x[i], 15.0)
    y30[i] = f(x[i], 30.0)
    y45[i] = f(x[i], 45.0)
    y60[i] = f(x[i], 60.0)
    y85[i] = f(x[i], 85.0)

plt.plot(x, y15, 'k:', lw=2, label='$15$')
plt.plot(x, y30, 'k-.', lw=2, label='$30$')
plt.plot(x, y45, 'r-', lw=2.5, label='$45$')
plt.plot(x, y60, 'k--', lw=2, label='$60$')
plt.plot(x, y85, 'k:', lw=2, label='$85$')

plt.plot(-x, y15, 'k:', lw=2, label='$15$')
plt.plot(-x, y30, 'k-.', lw=2, label='$30$')
plt.plot(-x, y45, 'r-', lw=2.5, label='$45$')
plt.plot(-x, y60, 'k--', lw=2, label='$60$')
plt.plot(-x, y85, 'k:', lw=2, label='$85$')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)

plt.legend(('$15\,^{\circ}$', '$30\,^{\circ}$',
            '$45\,^{\circ}$', '$60\,^{\circ}$',
            '$85\,^{\circ}$'), loc='best')
plt.ylabel('y')
plt.xlabel('x')

#security parabola
print 'security parabola: Ax^2 + Bx + C = 0'
A = -H / (maximumrange ** 2)
print 'A = -H / v0^2 = ', A
print 'B = 0'
print 'C = H = ', H
print ('y = ' + "%.6f" % A + 'x^2 + ' + "%.6f" % H)
#calculates 100 points of the parabola
xvalues = np.linspace(-maximumrange, maximumrange, 100)
yvalues = np.zeros(100, float)

for k in range(0, 100):
    yvalues[k] = A * xvalues[k] ** 2 + H
plt.plot(xvalues, yvalues, 'k-', lw=1.0)
plt.fill_between(xvalues, yvalues, 0, alpha=0.2, color='#BDD0D7')
plt.ylim(0, 1.1 * (v0 ** 2) / (-2 * g))
plt.show()
