# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8f.py
represents polynomials, with M, m, axis cuts and inflection point
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

#coefficients a0, a1,... an
#a = [1, -1, -7, 1, 6]
#a = [-1, 0, 0, -4, 0, 2]
a = [-3, 2, -1, -2, 1]
#a = [0, 16.4, -0.06]
'''
fis_y0 = 0.0
fis_v0 = 50.0
fis_g = -9.81
a = [fis_y0, fis_v0, 0.5 * fis_g]
'''

importantx = [0]
importanty = [0]


def latexpoly(p):
    if p[0] > 0:
        polynomial = '+' + str(p[0])
    elif p[0] < 0:
        polynomial = str(p[0])
    else:
        polynomial = ''
    n = 1
    while n <= (len(p) - 1):
        if p[n] == 0:
            n += 1
        else:
            sign = ''
            if p[n] < 0:
                sign = ' '
            elif p[n] > 0:
                sign = '+'
            if n > 0:
                polynomial = ' ' + str(p[n]) + 'x^{' + str(n) + '} ' + polynomial
            else:
                polynomial = ' ' + str(p[n]) + polynomial
            polynomial = sign + polynomial
            n += 1
    if (polynomial[0]) == '+':
        polynomial = polynomial[1:len(polynomial)]
    return polynomial


def derivative(p):
    d = np.zeros(len(p), float)
    i = len(p) - 1
    while i > 0:
        d[i - 1] = p[i] * i
        i -= 1
    return d


def f(x):
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


print 'polynomial P: ' + str(a) + ' = ' + latexpoly(a)
print 'Cuts axis Y: (0,', f(0), ')'
plt.plot(0, f(0), 'yo')
phrase = '$' + "%3.1f" % f(0) + '$'
plt.text(0.1, f(0), phrase, horizontalalignment='left',
         fontsize=12, color='black', weight='bold')

#cuts axis X
cutX = np.roots(a[::-1])
cut_axis_X = False
cutXreal = []
for cut in cutX:
    if np.iscomplex(cut) == False:
        cut = float(np.real(cut))
        print 'cuts axis X: (' + "%6.3f" % cut + ', 0)'
        cutXreal.append(cut)
        cut_axis_X = True
        plt.plot(cut, f(cut), 'yo')
        phrase = '$' + "%3.1f" % cut + '$'
        plt.text(cut, -0.2, phrase, horizontalalignment='center',
                 verticalalignment='top', fontsize=12, color='black', weight='bold')
        importantx.append(cut)
        importanty.append(cut)
if cut_axis_X == False:
    print 'the function does not cut axis X'

#derivatives
d1 = np.zeros(len(a), float)
d2 = np.zeros(len(a), float)
d1 = derivative(a)
d2 = derivative(d1)
print 'P' + "'" + ': ' + str(d1) + ' = ' + latexpoly(d1)
print 'P' + "''" + ': ' + str(d2) + ' = ' + latexpoly(d2)

#roots of derivative d1
list1 = d1[::-1]
roots1 = np.roots(list1)
#print roots1
for i in range(0, len(roots1)):
    if np.iscomplex(roots1[i]) is True:
        np.delete(roots1, i)
    else:
        plt.plot(roots1[i], f(roots1[i]), 'k+')
        print 'derivative is null when  x= ' + "%5.2f" % roots1[i]
        importantx.append(roots1[i])
        importanty.append(f(roots1[i]))

for r in roots1:
    if np.iscomplex(r) == False:
        valor = d2[0]
        for i in range(1, len(d2)):
            valor = valor + d2[i] * r ** [i]
            position = '(' + "%4.1f" % r + ', ' + "%4.1f" % f(r) + ')'
            if valor < 0:
                point = 'Maximum: ' + position
                letters = 'M'
            elif valor > 0:
                point = 'minimum: ' + position
                letters = 'm'
            else:
                point = 'Inflection point: ' + position
                letters = 'In'
        print 'd2(' + str(r) + ') = ' + str(valor) + ': ' + point
        plt.text(r, 0.3 + f(r), letters, horizontalalignment='center',
                 verticalalignment='bottom', fontsize=13, color='blue', weight='bold')

pointsnum = 300
if len(a) < 3:
    xmax = 2 * np.max(importantx)
    xmin = 2 * np.min(importantx)
else:
    xmax = 1.2 * np.max(importantx)
    xmin = 1.2 * np.min(importantx)
if xmin == 0:
    xmin = -1
if xmax == 0:
    xmax = 1
importanty.append(f(xmax))
importanty.append(f(xmin))
ymax = 1.15 * np.max(importanty)
ymin = 1.15 * np.min(importanty)
if ymin == 0:
    ymin = -1
if ymax == 0:
    ymax = 1

x = np.linspace(xmin, xmax, pointsnum)
y = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    y[i] = f(x[i])
plt.xlim(xmin, xmax)
plt.ylim(ymin, ymax)
plt.plot(x, y, 'r-', lw=1.5)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()