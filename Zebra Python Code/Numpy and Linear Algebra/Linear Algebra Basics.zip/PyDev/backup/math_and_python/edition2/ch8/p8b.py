# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8b.py
Theorem of Lagrange
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)
pointsnum = 300


def datasample(poli, a, b, A, B):
    print 'f(x)='
    print poli
    print 'a = ', a, '; A = f(a) = ', A
    print 'b = ', b, '; B = f(b) = ', B


#-------------- Lagrange example -----
#coefficients an, an-1,... a0
#for the Lagrange example
fpoli = np.poly1d([6, 1, 0, 5])
a = -1.1
b = 0.2
A = np.polyval(fpoli, a)
B = np.polyval(fpoli, b)
#----------------------------------------


'''
#--------------  Rolle exammple -----
#coefficients an, an-1,... a0
#for the example of Rolle
fpoli = np.poly1d([-1, 1, 1])
a = -1.5
A = np.polyval(fpoli, a)
fpoliA = 0 * fpoli
fpoliA[0] = A
ec = np.poly1d(fpoli - fpoliA)
listab = np.roots(ec)
print 'posible b', listab
b = listab[0]
if b == a:
    b = listab[1]
B = np.polyval(fpoli, b)
#----------------------------------------
'''

datasample(fpoli, a, b, A, B)
characteristicx = [0]
characteristicy = [0]
characteristicx.append(a)
characteristicx.append(b)


def writex(m, texto):
    plt.text(m, -0.5, texto,
             horizontalalignment='center',
             verticalalignment='top',
             fontsize=13, color='blue', weight='bold')


def writefx(m, M, texto):
    if M >= 0:
        posicion = 0.4 + M
        vertical = 'bottom'
    else:
        posicion = M - 0.4
        vertical = 'top'
    plt.text(m, posicion, texto,
             horizontalalignment='center',
             verticalalignment=vertical,
             fontsize=13, color='blue', weight='bold')

writefx(a, A, 'A')
writefx(b, B, 'B')
plt.plot(a, 0, 'yo')
plt.plot(b, 0, 'yo')
writex(a, 'a')
writex(b, 'b')
plt.plot(a, A, 'yo')
plt.plot(b, B, 'yo')
plt.plot([a, b], [A, B], 'k--', lw=1)
slope = (B - A) / (b - a)
print 'f', "'", '(c) = ', "%5.3f" % slope, ' = slope of the secant line AB'

#derivada
d1 = np.polyder(fpoli)
print 'P' + "'" + ': ' + str(d1)
print 'to find c we must find the roots of:'
d1[0] = d1[0] - slope
print d1

#raices de ec
raices1 = np.roots(d1)
for i in range(0, len(raices1)):
    if np.iscomplex(raices1[i]) is True:
        np.delete(raices1, i)
    else:
        if (raices1[i] < b) and (raices1[i] > a):
            c = raices1[i]
            C = np.polyval(fpoli, c)
            plt.plot(c, C, 'ko')
            plt.plot(c, 0, 'ko')
            writex(c, 'c')
            writefx(c, C, 'C')
            print ('c = ' + "%5.2f" % c +
                   '; C=f(c)= ' + "%5.2f" % C)
            characteristicx.append(c)
            i = len(raices1) + 2

xmax = 1.5 * np.max(characteristicx)
xmin = 1.5 * np.min(characteristicx)
if xmin == 0:
    xmin = -1
if xmax == 0:
    xmax = 1
ymax = 2 * max([0.5, A, B, C])
ymin = 2 * min([-0.5, A, B, C])
#y-y0 = m(x-x0) = slope(x-x0)
#y = C + slope(x-c)
print 'the tangent line at f(c) = (' + "%5.2f" % c + ', ' + "%5.2f" % C + ')'
print 'has the same slope that the secant AB'
plt.plot([xmin, xmax], [C + slope * (xmin - c),
         C + slope * (xmax - c)], 'b-', lw=1)
x = np.linspace(xmin, xmax, pointsnum)
y = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    y[i] = np.polyval(fpoli, x[i])
plt.plot(x, y, 'r-', lw=2)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylim(ymin, ymax)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
