# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8m.py
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

t1 = np.deg2rad(75)
print 't1 = 75º = ' + "%5.3f" % t1 + ' rad'


def f(t):
    fv = np.sinh(t)
    return fv


def g(t):
    gv = np.cosh(t)
    return gv

pointsnum = 90
tstart = 0
tfinal = pointsnum
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
t = tstart
while t < tfinal:
    radians = np.deg2rad(t)
    x[t] = np.cosh(radians)
    y[t] = np.sinh(radians)
    t += 1
plt.plot(x, y, 'r-', lw=2)
plt.plot(-x, y, 'r-', lw=2)
plt.plot(-x, -y, 'r-', lw=2)
plt.plot(x, -y, 'r-', lw=2)

plt.text(g(t1) + 0.1, f(t1) / 2, 'Sh(t)', horizontalalignment='left',
         fontsize=15, color='blue', weight='bold')
plt.text((1 + g(t1)) / 2, -0.5, 'Ch(t)', horizontalalignment='center',
         fontsize=15, color='blue', weight='bold')
plt.plot([g(t1), g(t1)], [f(t1), 0], 'k--', lw=1)
plt.plot([0, g(t1)], [0, f(t1)], 'k--', lw=1)
xmax = np.max(x)
ymax = np.max(y)
print xmax
plt.xlim(-xmax - 0.25, xmax + 0.25)
plt.ylim(-ymax - 0.25, ymax + 0.25)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
