# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8j.py
Calculates number pi using Leibniz series
"""

import matplotlib.pyplot as plt
import numpy as np

sign = 1.0
piaprox = 0
piseries = []
x = []
step = 0
for i in range(1, 5000, 2):
    piaprox += 4 * sign / i
    if step == 100:
        piseries.append(piaprox)
        x.append(i)
        piseries.append(piaprox - 4.0 / (i + 1))
        x.append(i + 1)
        step = 0
    print str(i) + "%15.8f" % (sign / i) + "%15.8f" % piaprox
    sign *= -1
    step += 1
#print piseries
plt.plot(x, piseries, 'bo', lw=1.0)
plt.plot([99, 5000], [np.pi, np.pi], 'r-', lw=1.5)
plt.xlim(99, 5000)
plt.xlabel('n')
plt.ylabel('S(n)')
plt.show()
