# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8c.py
Theorem of Cauchy
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

pi = np.pi
t1 = pi / 15
t2 = pi / 2.5
print 't1 = pi / 15 = ' + "%5.3f" % t1
print 't2 = pi / 2.5 = ' + "%5.3f" % t2


def f(t):
    fv = 2 * ((np.sin(t)) ** 3)
    return fv


def g(t):
    gv = 2 * ((np.cos(t)) ** 3)
    return gv

pointsnum = 360
tstart = 0
tend = pointsnum
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
t = tstart
while t < tend:
    radianes = np.deg2rad(t)
    x[t] = 2 * (np.cos(radianes) ** 3)
    y[t] = 2 * (np.sin(radianes) ** 3)
    t += 1
plt.plot(x, y, 'r-', lw=2)
plt.plot(g(t1), f(t1), 'bo')
plt.text(g(t1), f(t1) + 0.1, 'A', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')
plt.plot(g(t2), f(t2), 'bo')
plt.text(g(t2), f(t2) + 0.1, 'B', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')
plt.plot([g(t1), g(t2)], [f(t1), f(t2)], 'k--', lw=1.5)


def func_point(t, letra):
    print (letra + '(' + "%4.2f" % g(t) +
           ', ' + "%4.2f" % f(t) + ')')
func_point(t1, 'A')
func_point(t2, 'B')
slope = (f(t2) - f(t1)) / (g(t2) - g(t1))
print 'slope = ' + "%4.2f" % slope

tc = np.arctan(np.sqrt(-1 / slope))
print 'tc = ' + "%5.3f" % tc
func_point(tc, 'C')
plt.plot(g(tc), f(tc), 'bo')
plt.text(g(tc), f(tc) + 0.1, 'C', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')

plt.plot([-1.5, 2.5], [f(tc) - slope * (1.5 + g(tc)),
          f(tc) + slope * (2.5 - g(tc))], 'b-', lw=1.5)

plt.xlim(-2.25, 2.25)
plt.ylim(-2.25, 2.25)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
