# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8a.py
"""

import numpy as np

#f = 3 * x ** 2 - 5 * x + 1
f = np.poly1d([3, -5, 1])

x0 = -2.0
if abs(x0) > 0:
    deltax = abs(x0 / 2.0)
else:
    deltax = 0.1

print "    Δx          Δy/Δx"
while deltax >= 1e-6:
    deltay = np.polyval(f, (x0 + deltax)) - np.polyval(f, x0)
    c = deltay / deltax
    print "%10.6f" % deltax + "%12.6f" % c
    deltax = 0.1 * deltax
print
print 'x0 = ', x0
print 'f(x) = '
print f
Df = np.polyder(f, 1)
print 'Df(x): '
print Df
print 'Df(', x0, ') = ', np.polyval(Df, x0)
