# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8d.py
Taylor series: first four derivatives
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
import sympy as sy
from scipy.misc import factorial

x, y, z = sy.symbols('x y z')
sy.init_printing(use_unicode=True)

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

a = 60.0   # degrees
aradians = np.deg2rad(a)
fx = 3 * sy.sin(2 * x)
print 'f = ' + str(fx)
fa = fx.subs(x, aradians).evalf(6)
print 'f(a) = ' + str(fa)

derivative = [0, 0, 0, 0, 0]
derivative[0] = fx
p = [0, 0, 0, 0, 0]
p[0] = "%6.2f" % fa
strp = p[0]
for d in range(1, 5):
    derivative[d] = sy.diff(fx, x, d)
    print 'D' + str(d) + ' = ' + str(derivative[d])
    p[d] = str(derivative[d].subs(x, aradians).evalf(2))
    strp = strp + ' + (' + p[d] + '/' + str(factorial(d)) + ')(x-a)^' + str(d)
    print 'p' + str(d) + ' = ' + strp


def f(x):
    fv = 3 * np.sin(2 * x)
    return fv


def D1(x):
    D1v = 6 * np.cos(2 * x)
    return D1v


def D2(x):
    D2v = -12 * np.sin(2 * x)
    return D2v


def D3(x):
    D3v = -24 * np.cos(2 * x)
    return D3v


def D4(x):
    D4v = 48 * np.sin(2 * x)
    return D4v

pointsnum = 180
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
p1 = np.zeros(pointsnum, float)
p2 = np.zeros(pointsnum, float)
p3 = np.zeros(pointsnum, float)
p4 = np.zeros(pointsnum, float)
i = 0
while i < pointsnum:
    x[i] = i
    radians = np.deg2rad(x[i])
    increment = np.deg2rad(i - a)
    y[i] = f(radians)
    p1[i] = f(aradians) + D1(aradians) * increment
    p2[i] = p1[i] + (D2(aradians) / 2) * (increment ** 2)
    p3[i] = p2[i] + (D3(aradians) / 6) * (increment ** 3)
    p4[i] = p3[i] + (D4(aradians) / 24) * (increment ** 4)
    #print x[i], y[i], p1[i]
    i += 1
plt.plot(x, y, 'k-', lw=3)
plt.plot(x, p1, 'y--', lw=1)
plt.plot(x, p2, 'g--', lw=1.25)
plt.plot(x, p3, 'b--', lw=1.5)
plt.plot(x, p4, 'r-', lw=1.75)
plt.ylim(-4, 4)
plt.plot(a, f(aradians), 'bo')
plt.text(a, f(aradians) + 0.3, 'f(a)', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.plot(a, 0, 'bo')
plt.text(a, -0.3, 'a', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.legend(('f(x)', 'p1', 'p2', 'p3', 'p4'), loc='best')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
