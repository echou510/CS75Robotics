# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8l.py
Chx, Shx, Thx
"""

import numpy as np
import matplotlib.pyplot as plt

pointsnum = 100
fig = plt.figure(facecolor='white')
x = np.linspace(-3.5, 3.5, pointsnum)
y1 = np.zeros(pointsnum, float)
y2 = np.zeros(pointsnum, float)
y3 = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    y1[i] = (np.exp(x[i]) + np.exp(-x[i])) / 2
    y2[i] = (np.exp(x[i]) - np.exp(-x[i])) / 2
    y3[i] = y2[i] / y1[i]
ax = fig.add_subplot(1, 1, 1, aspect='equal')
p1, = plt.plot(x, y1, 'g', lw=2, label='$Chx$')
p2, = plt.plot(x, y2, 'r--', lw=2, label='$Shx$')
p3, = plt.plot(x, y3, 'b', lw=1.2, label='$Thx$')
#plt.legend(('$e^{x}$', '$e^{-x}$',), loc='best')
plt.legend(('$Chx$', '$Shx$', '$Thx$'), loc='best')
#ax.autoscale_view(tight=True)
plt.ylabel('y')
plt.xlabel('x')
ax.set_xlim(-3.6, 3.6)
ax.set_ylim(-5.1, 5.1)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()
