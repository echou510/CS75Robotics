# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p8h.py
"""

import sympy as sy

x, T = sy.symbols('x T')
sy.init_printing(use_unicode=True)

fx = x ** 3 * sy.exp(-x / T)
print 'f = ' + str(fx)
for d in range(1, 3):
    derivative = sy.diff(fx, x, d)
    print ('D' + str(d) + ' = ' + str(derivative))

#sy.simplify(6*x*sy.exp(-x/T) - 6*x**2*sy.exp(-x/T)/T + x**3*sy.exp(-x/T)/T**2)
print 'D2(3T) = '
print sy.simplify(6 * 3 * T * sy.exp(-3 * T / T) -
                  6 * (3 * T) ** 2 * sy.exp(-3 * T / T) / T +
                  (3 * T) ** 3 * sy.exp(-3 * T / T) / T ** 2)
