# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p1a.py
"""

import numpy as np

maximum = 1000
n = 30  # number of integers to calculate

num_a = np.random.randint(1, maximum)
den_ab = np.random.randint(1, maximum)
num_b = num_a + 1
print ('a = ' + str(num_a) + '/' + str(den_ab) +
       ' = ' + "%.6f" % (1.0 * num_a / den_ab))
print ('b = ' + str(num_b) + '/' + str(den_ab) +
       ' = ' + "%.6f" % (1.0 * num_b / den_ab))
print 'b-a = 1/', den_ab
print ('q = (' + str(num_a) + '*' + str(n + 1) +
       '+ i)/(' + str(den_ab) + '*' +
       str(n + 1) + ')')
print ('q = (' + str(num_a * (n + 1)) +
       '+ i)/' + str(den_ab * (n + 1)))


def qdense():
    for i in range(1, n + 1):
        num = num_a * (n + 1) + i
        den = den_ab * (n + 1)
        print ('(' + str(i) + ') ' + str(num) +
               '/' + str(den) + ' = ' +
               "%.8f" % (1.0 * num / den))

qdense()
