# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p1c.py
"""


def gcd_lcm(x, y):
    print 'numbers: ', x, ', ', y
    GCD = gcd(x, y)
    print 'GCD (greatest common divisor) = ' + str(GCD)
    if GCD > 1:
        lcm = x * y / GCD
    else:
        print str(x) + ' y ' + str(y), ' are relative primes'
        lcm = x * y
    s = 'lcm (least common multiple) = ' + str(lcm)
    return s


def gcd(a, b):  # x > y
    if b == 0:
        return 0
    else:
        r = a % b
        print 'remainder of ', a, '/', b, ' = ', r
        if r > 0:
            return gcd(b, r)
        else:
            return b

print gcd_lcm(256, 60)
print gcd_lcm(13, 8)
print gcd_lcm(1470, 1155)
