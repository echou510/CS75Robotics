# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming 
© www.pysamples.com
p1b.py
"""

import numpy as np

n = 100
print 'calculating for n< ' + str(n) + '. (about 2 seconds for n=50000).'
mylist = np.arange(1, n + 1, 2)
mylist[0] = 2
longitud = len(mylist)
root = np.floor(np.sqrt(n))


def f(x):
    return x != 0

for i in range(0, longitud):  # elimina multiplos de 3, 5
    if mylist[i] > 5:
        if (mylist[i] % 3 == 0):
            mylist[i] = 0
        elif (mylist[i] % 5 == 0):
            mylist[i] = 0


mylist = filter(f, mylist)
longitud = len(mylist)
print 'Checking', str(longitud), ' numbers less than ', str(n), ':'

i = 0
j = 1

while i <= root:
    if mylist[i] > 0:
        while j < (longitud):
            if mylist[j] != 0:
                resto = mylist[j] % mylist[i]
                if resto == 0:
                    mylist[j] = 0
            j += 1
        if (longitud >= 1000) and (i % 500 == 0):
            print 'calculating for ' + str(mylist[i])
    i += 1
    j = i + 1

primos = filter(f, mylist)
print 'list of prime numbers: ', primos
print 'There are ' + str(len(primos)) + ' prime numbers <= ' + str(n)
