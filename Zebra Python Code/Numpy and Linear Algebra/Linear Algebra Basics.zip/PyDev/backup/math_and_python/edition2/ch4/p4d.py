# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4d.py
difference between two successive terms is less than epsilon
"""

import numpy as np


def esequence2(epsilon):
    i = 1
    incremento = 1000
    while incremento > epsilon:
        y = np.power((1 + (1.0 / i)), i)
        y1 = np.power((1 + (1.0 / (i + 1))), (i + 1))
        incremento = abs(y1 - y)
        i += 1
    print 'required epsilon: ', epsilon
    print 'number of terms: N = ', i - 1
    y = np.power((1 + (1.0 / (i - 1))), (i - 1))
    y1 = np.power((1 + (1.0 / i)), i)
    print 'x[', i, '] - x[', i - 1, '] = '
    print "%30.27f" % y1, ' -', "%30.27f" % y, ' = '
    print ' = ', y1 - y

esequence2(1e-3)  # must be >1e-16
