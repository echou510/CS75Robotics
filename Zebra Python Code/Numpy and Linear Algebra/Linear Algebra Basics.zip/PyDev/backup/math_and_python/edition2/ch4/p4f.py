# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4f.py
"""

import numpy as np
import matplotlib.pyplot as plt

terms = 50
x = []
yerror = []
ycenter = []
ye = []


def nested(n):
    i = 1.0
    while i <= n:
        start = ((i + 1) ** i) / (i ** i)
        end = (i + 1) ** (i + 1) / (i ** (i + 1))
        print start, end
        x.append(i)
        yerror.append((end - start) / 2)
        ycenter.append(start + (end - start)/2)
        ye.append(np.e)
        i += 1


nested(terms)
print yerror
print ycenter

x0 = np.zeros(terms, float)
xerror = np.zeros(terms, float)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_ylim(1.9, 4.1)
ax.errorbar(x, ycenter, xerr=xerror, yerr=yerror)
ax.plot(x,ye, lw=1.0, color='r')
plt.xlabel('n')
#plt.ylabel('length of the intervals')
plt.ylabel('amplitud de los intervalos')
plt.show()
