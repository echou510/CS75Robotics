# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4a.py
"""

import numpy as np


def geometric(epsilon, a):
    print ('a = ' + str(a) +
           '; required epsilon =' +
           "%8.4g" % epsilon)
    n = (int(round(np.log10(epsilon) / np.log10(abs(a)))) + 1)
    x = np.zeros(n + 1, float)
    x[1] = a * 1.0
    print ('It is necessary to calculate ' + str(n) +
           ' terms of the sequence:')
    print "%3.0f" % 1.0, ': ', "%8.2g" % a
    for i in range(2, n + 1):
        x[i] = x[i - 1] * a
        print "%3.0f" % i, ': ', "%8.4g" % x[i]

geometric(1e-10, 0.15)  # geometric(epsilon, a)
