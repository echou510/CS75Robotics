# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4b.py
"""

import numpy as np


def root(n, A):
    print ('Calculate the square root of ' + "%3.1f" % A +
           ' with ' + str(n) + ' terms.')
    y = np.zeros(n + 1, float)
    y[1] = A / 2.0      # begin with A/2:
    for i in range(2, n + 1):
        y[i] = 0.5 * (y[i - 1] + (A / y[i - 1]))
        s = ('y[' + "%.0f" % i + '] = 0.5(' +
             "%12.8f" % y[i - 1] + '+(' + "%3.1f" % A +
             '/' + "%12.8f" % y[i - 1] + ')) = ' +
             "%12.8f" % y[i])
        print s
    print ('Direct calculation: sqrt(A) = sqrt(' +
           "%3.1f" % A + ') = ' +
           "%.15f" % np.sqrt(A))
#n: number of terms to calculate
#A: number whose root we want to calculate
root(10, 3000)  # root(n, A)
