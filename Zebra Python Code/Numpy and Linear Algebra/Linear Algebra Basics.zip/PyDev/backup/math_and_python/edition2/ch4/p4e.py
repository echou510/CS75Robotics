# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4e.py
"""

import fractions


def nested(n):
    i = 1
    while i <= n:
        anum = (i + 1) ** i
        bnum = anum * (i + 1)
        aden = i ** i
        bden = aden * i
        # fractions
        fraca = fractions.Fraction(anum, aden)
        fracb = fractions.Fraction(bnum, bden)
        print (str(i) + ': ' + '%s < e < %s' % (fraca, fracb))
#        print (str(i) + ': ' +
#               "%15.12f" % (1.0 * anum / aden) +
#               ' < e < ' + "%15.12f" % (1.0 * bnum / bden))
        i += 1

nested(100)  # must be <=140 to calculate in decimal format
