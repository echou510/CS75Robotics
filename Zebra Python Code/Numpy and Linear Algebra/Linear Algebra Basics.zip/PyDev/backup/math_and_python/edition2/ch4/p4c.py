# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p4c.py
"""

import numpy as np

n = 5000
y = np.zeros(n + 1, float)
y[1] = np.power((1 + (1.0 / 1)), 1)


def esequence(n):
    i = 2
    while i <= n:
        y[i] = np.power((1 + (1.0 / i)), i)
        i += 1

esequence(n)
print 'i          x[i]         x[i+1]-x[i]'
print '[  1]:', "%10.8f" % y[1], '   ; '
for i in range(2, n + 1):
    if i > 99:
        print ('[' + str(i) + ']: ' +
               "%10.8f" % y[i] + '    ; ' +
               "%10.4g" % (y[i] - y[i - 1]))
    elif i > 9:
        print ('[ ' + str(i) + ']: ' +
               "%10.8f" % y[i] + '    ; ' +
               "%10.4g" % (y[i] - y[i - 1]))
    else:
        print ('[  ' + str(i) + ']: ' +
               "%10.8f" % y[i] + '    ; ' +
               "%10.4g" % (y[i] - y[i - 1]))
