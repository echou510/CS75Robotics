# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5i.py
y = x**2
"""

import numpy as np
import matplotlib.pyplot as plt

numpoints = 50
x = np.linspace(-2.0, 2.0, numpoints)
y = np.zeros(numpoints, float)
for i in range(0, numpoints):
    y[i] = x[i] ** 2
plt.plot(x, y)
plt.ylabel('y')
plt.xlabel('x')
x = np.linspace(0.75, 1.25, 10)
y = np.zeros(10, float)
ceros = np.zeros(10, float)
for i in range(0, 10):
    y[i] = x[i] ** 2
plt.plot(x, y, 'ro')
plt.plot(x, ceros, 'ro')
plt.ylabel('y')
plt.xlabel('x')
# vertical line
plt.plot([x[0], x[0]], [ceros[0], y[0]], 'k--', lw=0.5)
plt.plot([x[9], x[9]], [ceros[9], y[9]], 'k--', lw=0.5)
plt.show()
