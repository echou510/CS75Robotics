# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5e.py
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 100
pi = np.pi
fig = plt.figure(facecolor='white')
x = np.linspace(0, 2 * pi, numpuntos)
ysin = np.zeros(numpuntos, float)
ycos = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    ysin[i] = np.sin(x[i])
    ycos[i] = np.cos(x[i])
ax = fig.add_subplot(1, 1, 1, aspect='equal')
p1, = plt.plot(x, ysin, 'b', lw=2, label='sin x')
p2, = plt.plot(x, ycos, 'r--', lw=2, label='cos x')
plt.legend(('sin x', 'cos x'), loc='best')
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')
ax.autoscale_view(tight=True)
ax.set_ylim(-1.25, 1.25)
ax.set_xlim((0, 2 * pi))
ax.set_xticks([0, pi / 2, pi, 3 * pi / 2, 2 * pi])
ax.set_xticklabels(['0', r'$\pi / 2$', r'$\pi$', r'$3 \pi / 2$', r'$2\pi$'])
ax.text(2 * np.pi + .1, -.2, r'$x$')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.show()
