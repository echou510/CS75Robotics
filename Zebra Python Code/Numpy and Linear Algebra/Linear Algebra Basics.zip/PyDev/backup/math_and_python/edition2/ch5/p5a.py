# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5a.py
"""

import numpy as np

x0 = 1
epsilon = 1e-3  # valor deseado de |f(x)-f(x0)|
delta = abs(epsilon / 2 * x0)
print 'x0 = ', x0, '; required epsilon: ', epsilon, ' delta = ', delta
print 'Points x which are at a distance from x0 less than ', delta
print 'meet |f(x)-f(x0)|<', delta, ' and are shown as #'
print
numpoints = 20
x = np.linspace(x0 - 1.5 * delta,
                x0 + 1.5 * delta,
                numpoints + 1)
print ('   x' + '        ' + '|x - x0|' +
       ' ' + ' |f(x) - f(x0)|')
print '_________________________________'
for i in range(0, numpoints + 1):
    difX = abs(x[i] - x0)
    difY = abs(x[i] ** 2 - x0 ** 2)
    if difY < epsilon:
        mark = '#'
    else:
        mark = ''
    print ("%8.5f" % x[i] + '    ' +
           "%8.5f" % difX + '    ' +
           "%8.5f" % difY + mark)
