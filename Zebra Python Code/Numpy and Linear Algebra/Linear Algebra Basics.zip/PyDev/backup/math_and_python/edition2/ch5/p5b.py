# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5b.py
"""

import matplotlib.pyplot as plt
import numpy as np

cpice = 2.072773; cpliquid = 4.187409; cpvapor = 1.836533
print 'cpice = ' + "%6.4f" % cpice
print 'cpliquid = ' + "%6.4f" % cpliquid
print 'cpvapor = ' + "%6.4f" % cpvapor
qmelting = 334  # J g-1
qvaporization = 2260  # J g-1
x = [-100, 0, 0, 100, 100, 200]
q = np.zeros(6, float)
q[0] = 0
q[1] = cpice * 100
q[2] = q[1] + qmelting
q[3] = q[2] + cpliquid * 100
q[4] = q[3] + qvaporization
q[5] = q[4] + cpvapor * 100
for i in range(0, 6):
    print str(x[i]) + "%6.0f" % q[i]
plt.plot([-100, 0], [0, q[1]], 'b', lw=1.5)
plt.plot([0, 100], [q[2], q[3]], 'b', lw=1.5)
plt.plot([100, 200], [q[4], q[5]], 'b', lw=1.5)
plt.ylabel('q')
plt.xlabel('t')
pointsX = [80, 85, 90, 95, 105, 110, 115, 120]
ceros = np.zeros(8, float)
pointsY = [
    q[2] + cpliquid * 80, q[2] + cpliquid * 85,
    q[2] + cpliquid * 90, q[2] + cpliquid * 95,
    q[4] + cpvapor * 5, q[4] + cpvapor * 10,
    q[4] + cpvapor * 15, q[4] + cpvapor * 20]
# lineas verticales discontinuas
plt.plot([0, 0], [q[1], q[2]], 'k--', lw=0.5)
plt.plot([100, 100], [q[3], q[4]], 'k--', lw=0.5)
#points
plt.plot(pointsX, ceros, 'ro')
plt.plot(pointsX, pointsY, 'ro')
plt.show()
