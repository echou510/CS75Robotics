# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5f.py
"""

import numpy as np
import matplotlib.pyplot as plt

numpoints = 300
x = np.linspace(-4.9, 4.9, numpoints)
y = np.zeros(numpoints, int)
#ceros = np.zeros(numpoints, int)
discontinuities = []
y[0] = np.trunc(x[0])
for i in range(1, numpoints):
    y[i] = np.trunc(x[i])
    if y[i] != y[i - 1]:
        discontinuities.append(i)
print y
print ('discontinuities:' + str(discontinuities))
j = 0
start = 0
end = 0
while (j < (numpoints - 1)):
    if (y[j + 1] != y[j]):
        end = j
        print ('from ' + str(start) + ' to ' + str(end) + ': y = ' + str(y[j]))
        plt.plot([x[start], x[end]], [y[j], y[j]], 'b', lw=2)
        start = j + 1
    j += 1
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()

