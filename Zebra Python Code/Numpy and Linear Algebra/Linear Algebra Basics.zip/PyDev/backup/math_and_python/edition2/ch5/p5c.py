# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5c.py
Second theorem of Bolzano-Cauchy, for any given C finds c such that f(c) = C
f(a) and f(b) must have opposite signs
"""

import scipy.optimize as optimize
import numpy as np

C = 1.0
#C = 0.0
a = 5
b = 8
print 'f(x) = x * sin(x) / 5'
print 'finds the point c in the interval [', a, ', ', b, ']'
print 'such that f(c) = ', C


def function(x):
    return (x * np.sin(x) / 5) - C
    #return x ** 2 - 25  # a=0 b=15
    #return np.cos(x) ** 2 + 6 - x

signo = np.sign(function(a)) * np.sign(function(b))
if signo < 0:
    c = optimize.bisect(function, a, b, xtol=1e-6)
    print 'c = ' + "%7.5f" % c
    print 'f(c) = ' + "%7.5f" % (function(c) + C)
else:
    print 'f(a) and f(b) must have opposite signs'
