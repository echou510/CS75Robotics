# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p5g.py
sin(x)/x
"""

import numpy as np
import matplotlib.pyplot as plt

numpoints = 100
x = np.linspace(0.001, 1.5, numpoints)
y = np.zeros(numpoints, float)
sin = np.zeros(numpoints, float)
for i in range(0, numpoints):
    sin[i] = np.sin(x[i])
    y[i] = sin[i] / x[i]
    #print x[i], y[i]
fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1, aspect='equal')
ax.autoscale_view(tight=True)
ax.set_ylim(0, 1.5)
ax.set_xlim((0, 1.5))
p1, = plt.plot(x, x, 'b--', lw=1, label='y = x')
p2, = plt.plot(x, sin, 'g', lw=1, label='y = sinx')
p3, = plt.plot(x, y, 'r', lw=3, label='y = sinx/x')
plt.legend(('y = x', 'y = sinx', 'y = sinx/x'), loc='best')
plt.ylabel('y')
plt.xlabel('x')
plt.show()
