# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p6e.py
Determines the type of hyperbola and plots it if the conic has A33<0
"""

import numpy as np
import matplotlib.pyplot as plt
#from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()

print 'A x² + By² + C = 0'
print 'write A, B y C separated by one blank space:'
strdata = raw_input()
data = map(float, strdata.split())
print data
signos = np.sign(data)

if signos[0] == -1:
    data = np.multiply(-1.0, data)
    print data
t1 = data[0]
t2 = data[1]
k = data[2]
D = t1 * t2
print 'A33 = ', D
if D < 0 and k != 0:
    t1 = data[0]
    t2 = data[1]
    k = data[2]
    print data
    a = np.sqrt(abs(k / t1))
    b = np.sqrt(abs(k / t2))
    c = np.sqrt(a ** 2 + b ** 2)
    print 'a = ', "%.3f" % a, '; b = ', "%.3f" % b, '; c = ', "%.3f" % c
    asymptote = b / a
    print 'asimptotes: '
    print 'y = ', "%.3f" % asymptote, 'x; y = ', "%.3f" % -asymptote, 'x'
    vertex = a
    print 'vertex: (', "%.3f" % (-1 * vertex), ', 0), (', "%.3f" % vertex, ', 0)'
    e = c / a
    print 'excentricity: ', "%.3f" % e
    y = np.zeros(200, float)
    vertex = a
    if e < 2:
        rank = 5 * vertex
    else:
        rank = 1.5 * vertex
    x = np.linspace(vertex, rank, 200)
    for i in range(0, 200):
        y[i] = asymptote * np.sqrt(x[i] ** 2 - a ** 2)
    plt.plot(-c, 0, 'ro')
    plt.plot(c, 0, 'ro')
        
    #graphic
    plt.plot(x, y, 'r-', lw=1.5)
    plt.plot(x, -y, 'r-', lw=1.5)
    plt.plot(-x, y, 'r-', lw=1.5)
    plt.plot(-x, -y, 'r-', lw=1.5)
    plt.plot([-rank, rank], [-rank * asymptote, rank * asymptote],
             color='grey', ls='--', lw=0.8)
    plt.plot([-rank, rank], [rank * asymptote, -rank * asymptote],
             color='grey', ls='--', lw=0.8)
    plt.axhline(color='black', lw=1)
    plt.axvline(color='black', lw=1)
    plt.axis('equal')
    plt.show()
else:
    print 'A33 >= 0 o k=0'
