# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p6a.py
"""

import numpy as np

# example
c20 = 0.25
c11 = 1
c02 = 1
c10 = -0.5
c01 = -1
c00 = -0.75


print c20, 'x^2 + ', c11, 'xy + ', c02, 'y^2 + ', c10, 'x + ', c01, ' y + ', c00, ' = 0'
A = 0.5 * np.array([[2 * c20, c11, c10],
                    [c11, 2 * c02, c01],
                    [c10, c01, 2 * c00]])
print A
disc = np.linalg.det(A)
print '|A| = ', "%.4f" % disc
rangoA = np.linalg.matrix_rank(A)
print 'rank(A) = ', rangoA
A33 = 0.5 * np.array([[2 * c20, c11], [c11, 2 * c02]])
print 'A33 = ', A33
det33 = np.linalg.det(A33)
print '|A33| = ', det33
rank33 = np.linalg.matrix_rank(A33)

# ------------- delta = 0 ----------------------------
if rangoA != 3:  # delta = 0
    if rank33 == 2:  # det33 != 0
        if det33 > 0:  # 4 -2 1 -14 2 13
            print 'the equation represents two complex conjugated straight lines'
        if det33 < 0:  # -3 -2 1 7 -1 -2
            print 'the equation represets two intersecting straight lines'
    if rank33 != 2:  # det33 = 0
        print 'the equation represents two parallel or coincident straight lines,'
        print 'which can be real or complex'
    m = np.roots([1, c11, c20])
    if (m[0] - m[1]) != 0:
        print 'slopes of the lines: ', m
        n2 = (c10 + m[1] * c01) / (m[0] - m[1])
        n1 = -(n2 + c01)
        print 'n1, n2 = ', n1, ', ', n2
        print 'the two straight lines are:'
        print 'y = ', m[0], 'x + ', n1
        print 'y = ', m[1], 'x + ', n2
else:
    print 'The discriminant is not null'
