# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p6f.py
Determines the parabola and plots it: discriminant != 0 and A33=0
"""

import numpy as np
import matplotlib.pyplot as plt

# ejemplo
#c20 = 1
#c11 = 2
#c02 = 1
#c10 = 1
#c01 = -2
#c00 = 1 

# escudos de Siracusa
c20 = 0.1
c11 = 0.4
c02 = 0.4
c10 = 10
c01 = 300
c00 = 100

print c20, 'x^2 + ', c11, 'xy + ', c02, 'y^2 + ', c10, 'x + ', c01, ' y + ', c00, ' = 0'
A = 0.5 * np.array([[2 * c20, c11, c10],
                    [c11, 2 * c02, c01],
                    [c10, c01, 2 * c00]])
print A
disc = np.linalg.det(A)
print '|A| = ', "%.4f" % disc
rankA = np.linalg.matrix_rank(A)
print 'rank(A) = ', rankA
A33 = 0.5 * np.array([[2 * c20, c11], [c11, 2 * c02]])
print 'A33 = ', A33
det33 = np.linalg.det(A33)
print '|A33| = ', det33
rank33 = np.linalg.matrix_rank(A33)

if rankA == 3:  # disc != 0
    if rank33 != 2: # det33 = 0
        print 'the equation represents a real parabola'
        I = c20 + c02
        p = np.sqrt(-disc / I ** 3)
        print 'y ** 2 = 2 * ', "%.3f" % p, 'x'
        print 'focus: (', "%.3f" % (p / 2), ', 0)'
        y = np.zeros(200, float)
        x = np.linspace(0, 5 * p, 200)
        for i in range(0, 200):
            y[i] = np.sqrt(2 * p *x[i])
        plt.plot(x, y, 'r-', lw=1.5)
        plt.plot(x, -y, 'r-', lw=1.5)
        plt.plot(p / 2, 0, 'ro')
    #    plt.plot(-x, y, 'r-', lw=1.5)
    #    plt.plot(-x, y, 'r-', lw=1.5)
        plt.axhline(color='black', lw=1)
        plt.axvline(color='black', lw=1)
        plt.xlim(-0.5, max(x))
        #plt.axis('equal')
        plt.show()
    else:
        print 'A33 is not null'
else:
    print 'Discriminant is not null'
