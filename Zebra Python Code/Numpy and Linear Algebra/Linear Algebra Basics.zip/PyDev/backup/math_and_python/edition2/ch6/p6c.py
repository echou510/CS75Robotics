# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming 
© www.pysamples.com
p6c.py
Sommerfeld atomic model orbits for n=4
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()

#orbits for level n=4, as a0 multiples [s p d f]
a4 = [16, 16, 16, 16]
b4 = [2, 6, 10, 14]
colors = ['k', 'b', 'g', 'r']

for i in range(0, 4):
    a = a4[i]
    b = b4[i]
    c = np.sqrt(a ** 2 - b ** 2)
    e = c / a
    f = [[-c, 0], [c, 0]]
    color = colors[i]
    elipse = Ellipse(xy=(c, 0), width=2 * a, height=2 * b,
                     edgecolor=color, fc='None', lw=2)
    ax.add_patch(elipse)

plt.plot(c, 0, 'ko')
plt.axis('equal')
plt.show()
