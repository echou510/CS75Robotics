# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python © www.pysamples.com
p6b.py
Moon elliptical orbit
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()

#Moon orbit (distances in thousands of kilometers)
a = 384.748
e = 0.0549
# e2 = (a2 - b2) / a; b= sqrt(a2 -ae2)
b = np.sqrt(a ** 2 - a * e ** 2)
c = a ** 2 - b ** 2
f = [[-c, 0], [c, 0]]
print 'a = ', "%.3f" % a
print 'b = ', "%.3f" % b
print 'c = ', "%.3f" % c
print 'e = ', "%.4f" % e
#graphic
elipse = Ellipse(xy=(0, 0), width=2 * a, height=2 * b,
                 edgecolor='r', fc='None', lw=2)
ax.add_patch(elipse)
circle = plt.Circle((-6.371, 0), radius=6.371, fc='b')
plt.gca().add_patch(circle)
plt.plot(f[0][0], f[0][1], 'ro')
plt.plot(f[1][0], f[1][1], 'ro')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.axis('equal')
plt.show()
