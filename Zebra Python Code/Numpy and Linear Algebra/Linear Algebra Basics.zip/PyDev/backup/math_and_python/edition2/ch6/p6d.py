# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p6d.py
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()
print 'A x² + By² + C = 0'
print 'write A, B y C separated by one blank space:'
strdata = raw_input()
data = map(float, strdata.split())
print data
signs = np.sign(data)
if signs[0] == -1 and signs[1] == -1:
    data = np.multiply(-1.0, data)
    print data
t1 = data[0]
t2 = data[1]
k = data[2]
D = t1 * t2
print 'A33 = ', D
if D > 0:
    if np.sign([k]) == -1:
        a = np.sqrt(-k / t1)
        b = np.sqrt(-k / t2)
        c = np.sqrt(abs(a ** 2 - b ** 2))
        e = c / max(a, b)
        print 'a = ', "%.3f" % a, '; b = ', "%.3f" % b, '; c = ', "%.3f" % c
        print 'excentricity: e = ', "%.4f" % e
        J = np.pi * (3 * (a + b)) - np.sqrt((3 * a + b) * (a + 3 * b))  # Ramanujan
        area = np.pi * a * b
        if a > b:
            f = [[-c, 0], [c, 0]]
            curve = 'horizontal ellipse'
            perimeter = J
        if a == b:
            f = [[0, 0], [0, 0]]
            curve = 'circumference or radius R = ' + "%.3f" % a
            perimeter = 2 * np.pi * a
        if a < b:
            f = [[0, -c], [0, c]]
            curve = 'vertical ellipse'
            perimeter = J
        print curve
        print 'perimeter: ', "%.3f" % perimeter
        print 'inside area: ', "%.3f" % area
        print 'x ** / ', "%.3f" % a ** 2, ') + (y ** 2 / ', "%.3f" % b ** 2, ') = 1'
        #graphic
        ellipse = Ellipse(xy=(0, 0), width=2 * a, height=2 * b, edgecolor='r', fc='None', lw=2)
        ax.add_patch(ellipse)
        plt.plot(f[0][0], f[0][1], 'ro')
        plt.plot(f[1][0], f[1][1], 'ro')
        plt.axhline(color='black', lw=1)
        plt.axvline(color='black', lw=1)
        plt.axis('equal')
        plt.show()
    if np.sign([k]) == 1:
        a = np.sqrt(k / t1)
        b = np.sqrt(k / t2)
        c = np.sqrt(abs(a ** 2 - b ** 2))
        print 'a, b, c: ', "%.3f" % a, "%.3f" % b, "%.3f" % c
        print 'imaginary ellipse'
    if np.sign([k]) == 0:
        print 'degenerated ellipse: one point'
else:
    print 'A33 <= 0'
