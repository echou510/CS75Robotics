# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10c.py
"""

import numpy as np


def mod(name, a):
    length = np.linalg.norm(a)
    print '|', name, '| = ', "%5.2f" % length
    return length


def normalizes(a):  # a is a vector
    length = mod('a', a)
    u = []
    u = a / length
    return u

a = np.array([3, -1, 5])
print 'a = ', a
u = normalizes(a)
print 'u = ', u
mod('u', u)
