# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10n.py
"""

import matplotlib
import numpy as np
import matplotlib.pyplot as plt

matplotlib.rcParams['xtick.direction'] = 'out'
matplotlib.rcParams['ytick.direction'] = 'out'

x = np.arange(-100, 100, 1.0)
y = np.arange(-100, 100, 1.0)
X, Y = np.meshgrid(x, y)
Z = 0.03 * (X ** 2 - Y ** 2)  # z = altitude
plt.figure()
CS = plt.contour(X, Y, Z, 12, colors='k', linewidth=1.0)

plt.clabel(CS, inline=1, fontsize=12, fmt='%4.0f')
px1 = [-90, -80, -70, -60]
py1 = []
for i in range(0, 4):
    py1.append(np.sqrt(px1[i] ** 2 - (100 / 0.03)))
    plt.arrow(px1[i], py1[i], 0.06 * px1[i], -0.06 * py1[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(px1[i], -py1[i], 0.06 * px1[i], 0.06 * py1[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(-px1[i], py1[i], -0.06 * px1[i], -0.06 * py1[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(-px1[i], -py1[i], -0.06 * px1[i], 0.06 * py1[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)

py2 = [-60, -65, -70, -75, -80]
px2 = []
for i in range(0, 5):
    px2.append(np.sqrt(py2[i] ** 2 + (-100 / 0.03)))
    plt.arrow(px2[i], py2[i], 0.06 * px2[i], -0.06 * py2[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(px2[i], -py2[i], 0.06 * px2[i], 0.06 * py2[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(-px2[i], py2[i], -0.06 * px2[i], -0.06 * py2[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)
    plt.arrow(-px2[i], -py2[i], -0.06 * px2[i], 0.06 * py2[i],
              width=0.1, fc='r', ec='none',
              length_includes_head=True, lw=0.5)

plt.title('Z = altitude')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
