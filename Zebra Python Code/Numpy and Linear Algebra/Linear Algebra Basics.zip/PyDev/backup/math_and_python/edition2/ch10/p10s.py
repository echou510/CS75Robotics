# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10s.py
"""

import numpy as np
from mayavi import mlab

x, y, z = np.mgrid[-5:5, -5:5, -5:5]
u = x
v = y
w = z
obj = mlab.flow(u, v, w)
mlab.show()
