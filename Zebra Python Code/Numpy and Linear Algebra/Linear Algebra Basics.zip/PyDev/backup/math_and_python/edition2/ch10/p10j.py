# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10j.py
"""

import matplotlib
import numpy as np
import matplotlib.pyplot as plt

matplotlib.rcParams['xtick.direction'] = 'out'
matplotlib.rcParams['ytick.direction'] = 'out'

x = np.arange(-100, 100, 1.0)
y = np.arange(-100, 100, 1.0)
X, Y = np.meshgrid(x, y)
#Z = 5 * 1e-4 * (X ** 2 - Y ** 2)
Z = 0.03 * (X ** 2 - Y ** 2)  # z = altitude

plt.figure()
CS = plt.contour(X, Y, Z, 12, colors='k', linewidth=1.0)
plt.clabel(CS, inline=1, fontsize=12, fmt='%1.0f')
plt.title('Z = altitud')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
