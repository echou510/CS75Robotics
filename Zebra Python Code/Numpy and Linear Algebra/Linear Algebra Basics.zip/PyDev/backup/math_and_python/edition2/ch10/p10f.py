# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10f.py
"""

import numpy as np
import matplotlib.pyplot as plt

print 'Problem type according to known data:'
print '1 - P0 and the normal vector'
print '2 - P0 and the direction vector'
print '3 - P0 and P1'
print
problem_type = int(raw_input('Input the type of problem: '))
print ('Write point P0 coordinates, separated by one blank space:')
sp0 = raw_input()
p0 = map(float, sp0.split())
print 'P0: ', p0
print
maxpoint = p0[0] + 1
minpoint = p0[0] - 1
oblique = False


def valid(director):  # continues if the line is oblique
    if r[0] == 0:
        oblique = False
        message = 'vertical line x = ' + str(p0[0])
    elif r[1] == 0:
        oblique = False
        message = 'horizontal line y = ' + str(p0[1])
    else:
        oblique = True
        message = 'oblique line'
    isoblique = {'oblique': oblique, 'message': message}
    return isoblique

if problem_type == 1:
    print ('Write the coordinates of the normal vector, separated by one blank space:')
    svn = raw_input()
    vn = map(float, svn.split())
    print
    if vn[0] == 0:
        oblique = False
        print 'horizontal line y = ' + str(p0[1])
    elif vn[1] == 0:
        oblique = False
        print 'vertical line x = ' + str(p0[0])
    else:
        oblique = True
        # a normal vector to r, choosing ry=1
        r = [-1.0 * vn[1] / vn[0], 1.0]
if problem_type == 2:
    print ('Write the coordinates of the direction vector, separated by one blank space:')
    sr = raw_input()
    r = map(float, sr.split())
    print
    sigue = valid(r)
    oblique = sigue.get('oblique')
    if oblique:
        # un vector normal a r, eligiendo B=1
        vn = [-1.0 * r[1] / r[0], 1.0]
    else:
        print sigue.get('message')
if problem_type == 3:
    print ('Write the coordinates of point P1, separated by one blank space:')
    sp1 = raw_input()
    p1 = map(float, sp1.split())
    print 'P1: ', p1
    if maxpoint < p1[0]:
        maxpoint = p1[0]
    if minpoint > p1[0]:
        minpoint = p1[0]
    r = [0, 0]
    r[0] = p1[0] - p0[0]
    r[1] = p1[1] - p0[1]
    sigue = valid(r)
    oblique = sigue.get('oblique')
    if oblique:
        vn = [-1.0 * r[1] / r[0], 1.0]  # a normal vector to r, choosing B=1
        maxpoint = max([p0[0], p1[0]]) + 1
        minpoint = min([p0[0], p1[0]]) - 1
    else:
        print sigue.get('message')


def geneq(vn, point):  # data: normal vector and one point in the line
    # vn and point are lineal arrays whose dimension is 2
    A = vn[0]
    B = vn[1]
    C = -A * point[0] - B * point[1]
    isoblique = {'A': A, 'B': B, 'C': C}
    return isoblique


def slopeq(ABC):  # data: la ecuacion general de la recta
    if ABC[1] != 0:
        m = -1.0 * ABC[0] / ABC[1]
        n = -1.0 * ABC[2] / ABC[1]
    else:
        m = 0
        n = 0
    isoblique = {'m': m, 'n': n}
    return isoblique


if oblique:
    parameter = unichr(0x3bb).encode('utf-8')
    print 'Direction vector: ', r
    #vn = [-1.0 * r[1] / r[0], 1.0]  # un vector normal a r, eligiendo B=1
    geneq = geneq(vn, p0)
    ABC = [geneq.get('A'), geneq.get('B'), geneq.get('C')]
    print 'Normal vector: ', vn
    print ('General form equation: ' +
           "%.3f" % ABC[0] + 'x + ' + str(ABC[1]) +
           ' y + ' + "%.3f" % ABC[2] + ' = 0')
    slopeq = slopeq(ABC)
    print ('Slope-intercept equation:  y = ' +
           "%.3f" % slopeq.get('m') +
           'x + ' + "%.3f" % slopeq.get('n'))
    print ('Vector equation: OP = ' +
           str(p0) + ' + ' + parameter + str(r))
    corteX = -1.0 * slopeq.get('n') / slopeq.get('m')
    corteY = slopeq.get('n')
    print 'Parametric equations:'
    print 'x = ', p0[0], ' + ', r[0], parameter
    print 'y = ', p0[1], ' + ', r[1], parameter
    print ('Cuts axis X at point [' + "%.3f" % corteX + ', 0]')
    print ('Cuts axis Y at point [0, ' + "%.3f" % corteY + ']')
    #graph

    def f(x):
        return slopeq.get('m') * x + slopeq.get('n')
    ur = [0, 0]
    modr = np.sqrt(r[0] ** 2 + r[1] ** 2)
    ur[0] = r[0] / modr
    ur[1] = r[1] / modr
    plt.arrow(0, 0, ur[0], ur[1], width=0.01, fc='r',
              ec='none', length_includes_head=True, ls='solid')
    uvn = [0, 0]
    modvn = np.sqrt(vn[0] ** 2 + vn[1] ** 2)
    uvn[0] = vn[0] / modvn
    uvn[1] = vn[1] / modvn
    plt.arrow(0, 0, uvn[0], uvn[1], width=0.01, fc='g',
              ec='none', length_includes_head=True, ls='solid')
    minimos = [-1.1 * corteX, 1.1 * corteX, ur[0] - 1,
               uvn[0] - 1, minpoint - 1]
    xmin = min(minimos)
    maximos = [-1.1 * corteX, 1.1 * corteX, ur[0] + 1,
               uvn[0] + 1, maxpoint + 1]
    xmax = max(maximos)

    plt.plot([xmin, xmax], [f(xmin), f(xmax)], 'b-', lw=1.5)
    plt.ylabel('y')
    plt.xlabel('x')
    plt.axhline(color='grey', lw=1)
    plt.axvline(color='grey', lw=1)
    plt.plot(p0[0], p0[1], 'ro')
    if problem_type == 3:
        plt.plot(p1[0], p1[1], 'ko')
    plt.xlim(xmin, xmax)
    plt.axis('equal')
    plt.show()
