# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.comm
p10m.py
"""

import sympy as sy

x, y, z, k = sy.symbols('x, y, z, k')
sy.init_printing(use_unicode=True)

k = 0.03
z = k * (x ** 2 - y ** 2)
print 'z = ', sy.simplify(z)


def gradient(a, dimension):  # a es una funcion escalar
    vectorgrad = []
    r = 0.0
    vectorgrad.append(sy.diff(a, x))
    if dimension == 2:
        vectorgrad.append(sy.diff(a, y))
    if dimension == 3:
        vectorgrad.append(sy.diff(a, z))
    for i in range(0, dimension):
        r += vectorgrad[i] ** 2
    length = sy.sqrt(r)
    result = {'vectorgrad': vectorgrad, 'length': length}
    return result

gradz = gradient(z, 2)
print 'grad z = ', gradz.get('vectorgrad')
modz = gradz.get('length')
print '|z| = ', modz
print '|z| = ', sy.simplify(modz)
