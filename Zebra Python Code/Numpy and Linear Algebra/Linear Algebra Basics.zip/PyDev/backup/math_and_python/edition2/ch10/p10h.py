# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10h.py
"""

import numpy as np
import matplotlib.pyplot as plt

t1 = 0.0
t2 = 2 * np.pi
print 't1 = ' + "%5.3f" % t1
print 't2 = ' + "%5.3f" % t2 + ' = 2 pi'


def r1(t):
    fv = t - np.sin(t)
    return fv


def r2(t):
    gv = 1 - np.cos(t)
    return gv

print 'a = ' + "%5.3f" % r1(t1)
print 'b = ' + "%5.3f" % r2(t2)
pointsnum = 360
starting_t = 0
final_t = pointsnum
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
t = starting_t
while t < final_t:
    radians = np.deg2rad(t)
    x[t] = r1(radians)
    y[t] = r2(radians)
    t += 1
plt.plot(x, y, 'b--', lw=1.5)


def dr1(t):
    d1 = 1 - np.cos(t)
    return d1


def dr2(t):
    d2 = np.sin(t)
    return d2

#values of t to represent the vector
points = [np.pi / 3, np.pi / 2, np.pi, 6 * np.pi / 5]
for i in range(0, 4):
    t = points[i]
    plt.arrow(0, 0, r1(t), r2(t), width=0.01, fc='k', ec='none', length_includes_head=True, lw=1.0)
    plt.arrow(r1(t), r2(t), dr1(t), dr2(t), width=0.01, fc='g', ec='none', length_includes_head=True, lw=0.5)

plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.axis('equal')
plt.xlim(-0.5, 6.5)
#plt.ylim(-0.5, 2.5)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
