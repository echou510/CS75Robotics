# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10q.py
"""

import matplotlib.pyplot as plt
import numpy as np


numpuntos = 15
x = np.linspace(0, 5, numpuntos)
y = np.linspace(0, 4, numpuntos)
X, Y = np.meshgrid(x, y, sparse=False)
U, V = -3 * Y, 0 * X

plt.quiver(X, Y, U, V, color='b')
plt.xlim(0, 5)
plt.ylim(0, 4.5)
plt.xlabel('x')
plt.ylabel('y')
plt.show()
