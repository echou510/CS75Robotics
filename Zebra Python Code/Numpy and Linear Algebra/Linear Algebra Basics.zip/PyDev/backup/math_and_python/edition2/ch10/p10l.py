# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10l.py
"""

import matplotlib.pyplot as plt
import numpy as np

r = np.linspace(0.2, 0.5, 200)
t = np.linspace(0, 2 * np.pi, 200)
r, t = np.meshgrid(r, t)

k = 9.0 * 1e9  # constant
q = 2.0 * 1e-9  # electric charge (Coulombs)
z = k * q / r  # electric potential

CS = plt.contour(r * np.cos(t), r * np.sin(t), z, 10, linewidths=2)
plt.plot(0, 0, 'o', color='grey')
plt.clabel(CS, inline=1, fmt='%5.0f', fontsize=10)
plt.title('Electric potential contour lines')
plt.axis('equal')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
