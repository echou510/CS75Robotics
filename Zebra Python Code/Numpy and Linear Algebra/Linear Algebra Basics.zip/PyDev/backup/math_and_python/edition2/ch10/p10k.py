# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10k.py
"""

#from mpl_toolkits.mplot3d import axes3d
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
x = np.arange(-100, 100, 1.0)
y = np.arange(-100, 100, 1.0)
X, Y = np.meshgrid(x, y)
#Z = 5 * 1e-4 * (X ** 2 - Y ** 2)
Z = 0.03 * (X ** 2 - Y ** 2)
#ax.plot_wireframe(X, Y, Z, rstride=10, cstride=10)
#ax.plot_surface(X, Y, Z,  rstride=10, cstride=10, color='b')
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
                linewidth=0, antialiased=False)
plt.xlabel('x')
plt.ylabel('y')
plt.show()
