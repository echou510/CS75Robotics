# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10f.py
"""

import numpy as np
import matplotlib.pyplot as plt

print 'Tipos de problema según los datos conocidos:'
print '1 - P0 y el vector normal'
print '2 - P0 y el vector director'
print '3 - P0 y P1'
print
problem_type = int(raw_input('Escribe el tipo de problema (1, 2 o 3): '))
print ('Escribe las coordenadas del punto P0 separadas por un espacio:')
sp0 = raw_input()
p0 = map(float, sp0.split())
print 'P0: ', p0
maxpoint = p0[0] + 1
minpoint = p0[0] - 1
oblique = False


def valid(director):  # continua si la linea es oblicua
    if r[0] == 0:
        oblique = False
        message = 'recta vertical x = ' + str(p0[0])
    elif r[1] == 0:
        oblique = False
        message = 'recta horizontal y = ' + str(p0[1])
    else:
        oblique = True
        message = 'recta oblicua'
    isoblique = {'oblique': oblique, 'message': message}
    return isoblique

if problem_type == 1:
    print ('Escribe las coordenadas del vector normal, separadas por un espacio:')
    svn = raw_input()
    vn = map(float, svn.split())
    if vn[0] == 0:
        oblique = False
        print 'recta horizontal y = ' + str(p0[1])
    elif vn[1] == 0:
        oblique = False
        print 'recta vertical x = ' + str(p0[0])
    else:
        oblique = True
        # un vector normal a r, eligiendo ry=1
        r = [-1.0 * vn[1] / vn[0], 1.0]
if problem_type == 2:
    print ('Escribe las coordenadas del vector director, separadas por un espacio:')
    sr = raw_input()
    r = map(float, sr.split())
    sigue = valid(r)
    oblique = sigue.get('oblique')
    if oblique:
        # un vector normal a r, eligiendo B=1
        vn = [-1.0 * r[1] / r[0], 1.0]
    else:
        print sigue.get('message')
if problem_type == 3:
    print ('Escribe las coordenadas del punto P1, separadas por un espacio:')
    sp1 = raw_input()
    p1 = map(float, sp1.split())
    print 'P1: ', p1
    if maxpoint < p1[0]:
        maxpoint = p1[0]
    if minpoint > p1[0]:
        minpoint = p1[0]
    r = [0, 0]
    r[0] = p1[0] - p0[0]
    r[1] = p1[1] - p0[1]
    sigue = valid(r)
    oblique = sigue.get('oblique')
    if oblique:
        vn = [-1.0 * r[1] / r[0], 1.0]  # un vector normal a r, eligiendo B=1
        maxpoint = max([p0[0], p1[0]]) + 1
        minpoint = min([p0[0], p1[0]]) - 1
    else:
        print sigue.get('message')


def geneq(vn, point):  # datos: vector normal y un punto de la recta
    # vn y el punto son arrays lineales de dimensión 2
    A = vn[0]
    B = vn[1]
    C = -A * point[0] - B * point[1]
    isoblique = {'A': A, 'B': B, 'C': C}
    return isoblique


def slopeq(ABC):  # datos: la ecuacion general de la recta
    if ABC[1] != 0:
        m = -1.0 * ABC[0] / ABC[1]
        n = -1.0 * ABC[2] / ABC[1]
    else:
        m = 0
        n = 0
    isoblique = {'m': m, 'n': n}
    return isoblique


if oblique:
    parameter = unichr(0x3bb).encode('utf-8')
    print 'Vector director: ', r
    #vn = [-1.0 * r[1] / r[0], 1.0]  # un vector normal a r, eligiendo B=1
    geneq = geneq(vn, p0)
    ABC = [geneq.get('A'), geneq.get('B'), geneq.get('C')]
    print 'Vector normal: ', vn
    print ('Ecuacion general de la recta: ' +
           "%.3f" % ABC[0] + 'x + ' + str(ABC[1]) +
           ' y + ' + "%.3f" % ABC[2] + ' = 0')
    slopeq = slopeq(ABC)
    print ('Ecuacion reducida de la recta:  y = ' +
           "%.3f" % slopeq.get('m') +
           'x + ' + "%.3f" % slopeq.get('n'))
    print ('Ecuacion vectorial de la recta: OP = ' +
           str(p0) + ' + ' + parameter + str(r))
    corteX = -1.0 * slopeq.get('n') / slopeq.get('m')
    corteY = slopeq.get('n')
    print 'Ecuaciones parametricas de la recta:'
    print 'x = ', p0[0], ' + ', r[0], parameter
    print 'y = ', p0[1], ' + ', r[1], parameter
    print ('Corte con el eje X en el punto [' + "%.3f" % corteX + ', 0]')
    print ('Corte con el eje Y en el punto 1[0, ' + "%.3f" % corteY + ']')
    #graph

    def f(x):
        return slopeq.get('m') * x + slopeq.get('n')
    ur = [0, 0]
    modr = np.sqrt(r[0] ** 2 + r[1] ** 2)
    ur[0] = r[0] / modr
    ur[1] = r[1] / modr
    plt.arrow(0, 0, ur[0], ur[1], width=0.01, fc='r',
              ec='none', length_includes_head=True, ls='solid')
    uvn = [0, 0]
    modvn = np.sqrt(vn[0] ** 2 + vn[1] ** 2)
    uvn[0] = vn[0] / modvn
    uvn[1] = vn[1] / modvn
    plt.arrow(0, 0, uvn[0], uvn[1], width=0.01, fc='g',
              ec='none', length_includes_head=True, ls='solid')
    minimos = [-1.1 * corteX, 1.1 * corteX, ur[0] - 1,
               uvn[0] - 1, minpoint - 1]
    xmin = min(minimos)
    maximos = [-1.1 * corteX, 1.1 * corteX, ur[0] + 1,
               uvn[0] + 1, maxpoint + 1]
    xmax = max(maximos)

    plt.plot([xmin, xmax], [f(xmin), f(xmax)], 'b-', lw=1.5)
    plt.ylabel('y')
    plt.xlabel('x')
    plt.axhline(color='grey', lw=1)
    plt.axvline(color='grey', lw=1)
    plt.plot(p0[0], p0[1], 'ro')
    if problem_type == 3:
        plt.plot(p1[0], p1[1], 'ko')
    plt.xlim(xmin, xmax)
    plt.axis('equal')
    plt.show()
