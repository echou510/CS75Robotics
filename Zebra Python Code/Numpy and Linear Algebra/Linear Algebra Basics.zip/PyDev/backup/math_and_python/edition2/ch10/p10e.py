# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10e.py
"""

import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

mpl.rcParams['legend.fontsize'] = 12

#==============================================================================
# #example 1
# va = np.array([[1.5], [-0.5], [0]])
# vb = np.array([[0.5], [0.5], [0]])
# print 'Represents Z coordinate scaled 1:10'
#==============================================================================

#example 2
va = np.array([[-2], [-1], [-1]])
vb = np.array([[1], [3], [1]])


vn = np.cross(va, vb, axis=0)
print 'a = ', np.transpose(va)
print 'b = ', np.transpose(vb)
print 'c = a X b = ', np.transpose(vn)
print '|c| = ', np.sqrt(vn[0] ** 2 + vn[1] ** 2 + vn[2] ** 2)
print 'Colors key: a(blue), b(green), c(red)'

fig = plt.figure()
ax = fig.gca(projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))

class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        FancyArrowPatch.draw(self, renderer)


#==============================================================================
# #example 1
# x = np.arange(-2, 2, 0.1)
# y = np.arange(-2, 2, 0.1)
#==============================================================================

#example 2
x = np.arange(-10, 10, 0.1)
y = np.arange(-10, 10, 0.1)

X, Y = np.meshgrid(x, y)

#plane containing point (0 0 0) and the end-points of the vectors a and b
zx = va[1] * vb[2] - va[2] * vb[1]
zy = va[2] * vb[0] - va[0] * vb[2]
zz = -1.0 * (va[0] * vb[1] - va[1] * vb[0])
Z = (zx * X + zy * Y) / zz


a = Arrow3D([0, va[0]], [0, va[1]], [0, va[2]], mutation_scale=20, lw=1.5,
            arrowstyle="-|>", color="b", linestyle='solid')
b = Arrow3D([0, vb[0]], [0, vb[1]], [0, vb[2]], mutation_scale=20, lw=1.5,
            arrowstyle="-|>", color="g", linestyle='solid')
            
#==============================================================================
# #example 1: represents Z coordinate scaled 1:10
# c = Arrow3D([0, vn[0]], [0, vn[1]], [0, 0.1 * vn[2]], mutation_scale=20, lw=1.5,
#             arrowstyle="-|>", color="r", linestyle='solid')  # ej. 1
#==============================================================================

#example 2
c = Arrow3D([0, vn[0]], [0, vn[1]], [0, vn[2]], mutation_scale=20, lw=1.5,
            arrowstyle="-|>", color="r", linestyle='solid')


ax.plot_wireframe(X, Y, Z, rstride=10, cstride=10, color='grey', lw='0.5')
ax.add_artist(c)
ax.add_artist(a)
ax.add_artist(b)
plt.xlabel('x')
plt.ylabel('y')
plt.show()
