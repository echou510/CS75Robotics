# -*- coding: utf-8 -*-
"""
Matematicas y Programacion en Python © www.pysamples.com
p10d.py
"""

import numpy as np

#ejemplo 1
#a = np.array([1, 2, 3])
#b = np.array([-1, 5 , 10])

#ejemplo 2: colineales
#b = 2 * a

#ejemplo ortogonales:
a = np.array([1, 0, 0])
b = np.array([0, 5, 0])

mod_a = np.linalg.norm(a)
mod_b = np.linalg.norm(b)

print 'a = ', a
print 'b = '
print b

radianes = np.arccos(np.dot(a,b) / (mod_a * mod_b))
dd = np.degrees(radianes)
print 'angulo = ' + str(radianes) + ' radianes = ' + str(dd) + ' grados decimales'


def decdeg_dms(dd):
   dd = abs(dd)
   minutos,segundos = divmod(dd*3600,60)
   grados,minutos = divmod(minutos,60)
   strgms = str(grados) + 'º ' + str(minutos) + "' " + "%5.2f" % segundos + "''"
   return strgms

print 'angulo{a,b} = ' + str(radianes/ np.pi) + ' pi radianes = ' + str(decdeg_dms(dd))