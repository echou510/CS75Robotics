# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10d.py
"""

import numpy as np

    
a = np.array([0, 1])
b = np.array([-1, -3])
#b =  2 * a.T # next example
#example orthogonals:
#a = np.array([[1, 0, 0]])
#b = np.array([0, 5, 0])

mod_a = np.linalg.norm(a)
mod_b = np.linalg.norm(b)

print 'a = ', a
print 'b = '
print b

radians = np.arccos(np.dot(a,b) / (mod_a * mod_b))
dd = np.degrees(radians)
print 'angle = ' + str(radians) + ' radians = ' + str(dd) + ' decimal degrees'


def decdeg_dms(dd):
   dd = abs(dd)
   minutes,seconds = divmod(dd*3600,60)
   degrees,minutes = divmod(minutes,60)
   strgms = str(degrees) + 'º ' + str(minutes) + "' " + "%5.2f" % seconds + "''"
   return strgms

print 'angle{a,b} = ' + str(radians/ np.pi) + ' pi radians = ' + str(decdeg_dms(dd))