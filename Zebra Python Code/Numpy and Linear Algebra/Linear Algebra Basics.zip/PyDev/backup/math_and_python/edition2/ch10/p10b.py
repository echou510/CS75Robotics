# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10b.py
"""

import numpy as np

for t in range(0, 101, 25):
    x = t
    y = t ** 2 / 2
    z = t ** 3 / 100
    longitud = np.sqrt(x ** 2 + y ** 2 + z ** 2)
    print '|r(', t, ')| = ', "%7.2f" % longitud
