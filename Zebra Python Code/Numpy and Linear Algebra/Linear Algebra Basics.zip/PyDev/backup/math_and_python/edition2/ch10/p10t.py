# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10t.py
"""

import matplotlib.pyplot as plt
import numpy as np

Y, X = np.mgrid[-5:5:200j, -5:5:200j]
U = -Y
V = X
#U = X
#V = Y
speed = np.sqrt(U * U + V * V)
lw = 0.2 + 2 * speed / speed.max()
plt.streamplot(X, Y, U, V, density=0.6, color='b', linewidth=lw, arrowsize=2, arrowstyle='-|>')
plt.xlabel('x')
plt.ylabel('y')
plt.show()