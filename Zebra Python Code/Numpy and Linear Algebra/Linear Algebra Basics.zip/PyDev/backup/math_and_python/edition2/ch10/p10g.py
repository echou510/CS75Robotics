# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10g.py
"""

import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

mpl.rcParams['legend.fontsize'] = 12


fig = plt.figure()
ax = fig.gca(projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))


class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        FancyArrowPatch.draw(self, renderer)


pointsnum = 111
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
z = np.zeros(pointsnum, float)
for t in range(20, pointsnum):
    x[t] = t
    y[t] = (t ** 2) / 2
    z[t] = (t ** 3) / 100
    if t % 10 == 0:
        a = Arrow3D([0, x[t]], [0, y[t]], [0, z[t]], mutation_scale=20, lw=0.75,
                    arrowstyle="-|>", color="k", linestyle='dotted')
        ax.add_artist(a)

ax.plot(x, y, z, label='vector function r(t)', lw=2)
ax.legend()
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
plt.show()
