# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10o.py
"""

import sympy as sy

x, y, z = sy.symbols('x, y, z')
sy.init_printing(use_unicode=True)

vector1 = sy.Matrix([[x + z, y + z, x ** 2 + z]])
vector2 = sy.Matrix([[x, y, z]])
#vector3 = sy.Matrix([[z, x, y]])
#vector3 = sy.Matrix([[-3 * y, 0, 0]])
#vector3 = sy.Matrix([[-y, x, 0]])
vector3 = sy.Matrix([[x, y, 0]])


def curl(v):
    rot = []
    rotx = sy.simplify(sy.diff(v[2], y) - sy.diff(v[1], z))
    roty = sy.simplify(sy.diff(v[0], z) - sy.diff(v[2], x))
    rotz = sy.simplify(sy.diff(v[1], x) - sy.diff(v[0], y))
    rot.append(rotx)
    rot.append(roty)
    rot.append(rotz)
    length = sy.sqrt(rotx ** 2 + roty ** 2 + rotz ** 2)
    result = {'curl': rot, 'length': length}
    return result

print 'v = ', vector1
rotv = curl(vector1)
print 'rot v = ', rotv.get('curl')
print '|rot v| = ', rotv.get('length')
print
print 'v = ', vector2
rotv = curl(vector2)
print 'rot v = ', rotv.get('curl')
print '|rot v| = ', rotv.get('length')
print
print 'v = ', vector3
rotv = curl(vector3)
print 'rot v = ', rotv.get('curl')
print '|rot v| = ', rotv.get('length')
