# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p10i.py
"""

import numpy as np
import matplotlib.pyplot as plt
#from matplotlib import rc
#
#rc('font', **{'family': 'serif', 'serif': ['Times']})
#rc('text', usetex=True)

#representa la curva utilizando ecuaciones de física
y0 = 0.0
v0 = 35.0
g = -9.81
angle = 50.0
#vy = v0y - g * t
#time en alcanzar el punto más alto: tfloor / 2
#vx = v0x
#x = v0x * t
#y = y0 + v0y*t + 0.5*g*t**2
#y = y0 + v0y*x/v0x + (0.5*g/v0x**2)*x**2
#ymax = y0 + v0y*tfloor/2 + 0.5*g*(tfloor/2)**2
maxrange = 0
maxheight = 0
print 'angle     ymax     throwrange    time'
#for j in range(0, 4):
alfa = np.deg2rad(angle)
v0y = v0 * np.sin(alfa)
tfloor = - 2 * v0y / g
v0x = v0 * np.cos(alfa)
throwrange = - (v0 ** 2) * np.sin(2 * alfa) / g
ymax = y0 + (v0y * tfloor / 2) + (0.5 * g * (tfloor / 2) ** 2)
if throwrange > maxrange:
    maxrange = throwrange
if ymax > maxheight:
    maxheight = ymax
print (str(angle) + "   %7.2f" % ymax + "      %7.2f" % throwrange + "    %7.2f" % tfloor)


def f(x, beta):
    v0x = v0 * np.cos(np.deg2rad(beta))
    #coefficients a0, a1,... an
    a = [y0, (np.tan(np.deg2rad(beta))), ((0.5 * g) / (v0x ** 2))]
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


numpoints = 300
x = np.linspace(0, np.ceil(maxrange), numpoints)
y = np.zeros(numpoints, float)
for i in range(0, numpoints):
    y[i] = f(x[i], angle)

plt.plot(x, y, 'b--', lw=2, label='$38$')
#plot r(t)
# values of t to represent the vector
points = [tfloor / 5, tfloor / 3, tfloor / 2,
          2 * tfloor / 3, 3 * tfloor / 4, 5 * tfloor / 6]


def xvector(time):
    return v0x * time

vx = v0x  # derivative of xvector is v0x
ax = 0.0  # derivative of vx es 0


def yvector(time):
    return y0 + v0y * time + 0.5 * g * time ** 2


def vy(time):
    return v0y + g * time

# derivative of de vy is g
ay = g

for i in range(0, 6):
    t = points[i]
    plt.arrow(0, 0, xvector(t), yvector(t), width=0.1, fc='k',
              ec='none', length_includes_head=True, lw=0.5)
    plt.arrow(xvector(t), yvector(t), vx, vy(t), width=0.1, fc='g',
              ec='none', length_includes_head=True, lw=0.5)
    plt.arrow(xvector(t), yvector(t), ax, ay, width=0.1, fc='r',
              ec='none', length_includes_head=True, lw=0.5)


plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
#plt.ylim(0, 1.05 * ymax)
#plt.legend(('$38\,^{\circ}$',), loc='best')
plt.axis('equal')
plt.xlim(-0.5, 1.05 * throwrange)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
