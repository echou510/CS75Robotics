# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9x.py
"""

import numpy as np
import matplotlib.pyplot as plt

pointsnum = 200
fig = plt.figure(facecolor='white')
x = np.linspace(0.01, 7.0, pointsnum)
y1 = np.zeros(pointsnum, float)
y2 = np.zeros(pointsnum, float)
y3 = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    y1[i] = np.log(x[i])
    y2[i] = np.log(x[i] ** (1.0 / 2.0))
    y3[i] = np.log(1 / x[i])
ax = fig.add_subplot(1, 1, 1, aspect='equal')
p1, = plt.plot(x, y1, 'b', lw=2, label='$\ln x$')
p2, = plt.plot(x, y2, 'r--', lw=1.5, label='$\ln x^{\frac{1}{2}}$')
p3, = plt.plot(x, y3, 'y-', lw=1.5, label='$\ln 1/x}$')
plt.ylabel('y')
plt.xlabel('x')
#ax.set_ylim(-4.5, 4.5)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.axis('equal')
plt.show()
