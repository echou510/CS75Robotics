# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9f.py
"""

import numpy as np
import matplotlib.pyplot as plt

pointsnum = 180
x = np.linspace(0, 180, pointsnum)
f = np.zeros(pointsnum, float)
g = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    f[i] = 1.0
    g[i] = np.sin(np.deg2rad(x[i]))
plt.plot(x, f, 'k--', lw=1.5)
plt.fill_between(x, f, 0, alpha=0.5, color='#BDD0D7')
plt.plot(x, g, 'k-', lw=2)
plt.fill_between(x, g, 0, alpha=1, color='#F5591E')
#plt.plot(x, f, 'k-', lw=2)
#plt.fill_between(x, f, 0, alpha=0.5, color='#F59D1E')
plt.ylabel('y')
plt.xlabel('x (degrees)')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylim(0, 1.25)
plt.legend(('f(x)=1', 'g(x)=sinx'), loc='best')
plt.show()
