# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9l.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy
x = sy.symbols('x')
sy.init_printing(use_unicode=True)

a = 0
b = 1
f = x ** 2
#f = sy.sqrt(x)
g = x ** 5
print 'f(x) = x ** 2'
area1 = sy.integrate(f, (x, a, b))
print 'g(x) = x ** 5'
area2 = sy.integrate(g, (x, a, b))

print 'A = Area(f) - Area(g) = ', area1, ' - ', area2, ' = ', area1 - area2

indefinitevolume = sy.integrate(sy.pi * (f ** 2 - g ** 2))
print 'V = [', indefinitevolume, '] from a to b'
print ('V = ' + str(sy.integrate(sy.pi * (f ** 2 - g ** 2), (x, b))) +
       ' - ' + str(sy.integrate(sy.pi * (f ** 2), (x, a))))
volume = sy.integrate(sy.pi * (f ** 2 - g ** 2), (x, a, b))
print 'V = ', volume

pointsnum = 200
x = np.linspace(a, b, pointsnum)
yf = x ** 2
yg = x ** 5
plt.plot(x, yf, color='r', lw=2.0)
plt.fill_between(x, yf, 0, alpha=1.0, color='#F8C31C')
plt.plot(x, yg, color='b', lw=2.0)
plt.fill_between(x, yg, 0, alpha=1.0, color='white')

plt.grid(True)
plt.axis('equal')
plt.ylabel('z')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
#plt.plot([a, a], [0, a ** 2], 'k-', lw=1.5)
plt.plot([b, b], [0, b], 'k--', lw=1.0)
#plt.xlim(0, 2.5)
#plt.ylim(0, 1.2)
plt.show()
