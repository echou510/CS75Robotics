# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9h.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

x = sy.symbols('x')
sy.init_printing(use_unicode=True)
a = -4.0
b = 2.0
#sympy
function = 10 * sy.exp(x / 2)
print 'f(x) = '
print function
I = sy.integrate(function)
print 'F(x) = '
print I
Fb = float(I.subs(x, b).evalf(3))
Fa = float(I.subs(x, a).evalf(3))
print 'F(b) = F(', b, ') = ', Fb
print 'F(a) = F(', a, ') = ', Fa
print 'F(b) - F(a) = ', Fb - Fa

#graph
pointsnum = 100
x = np.linspace(a, b, pointsnum)
f = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    f[i] = 10 * np.exp(x[i] / 2)
plt.plot(x, f, 'k-', lw=2.5)
plt.fill_between(x, f, 0, alpha=1, color='#BDD0D7')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=0.6)
plt.axvline(color='black', lw=0.6)
plt.xlim(a, b)
plt.show()
