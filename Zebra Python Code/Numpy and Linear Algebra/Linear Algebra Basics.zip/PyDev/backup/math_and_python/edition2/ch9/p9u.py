# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9u.py
numerical integration: trapezoids
"""

#import numpy as np
import matplotlib.pyplot as plt

#x = [-2.0, -1.0, 0.0, 1.0, 2.0, 3.0]
#y = [0.0, 2.646, 2.828, 3.0, 4.0, 5.916]

x = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5,
     1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
y = [0.0, 2.151, 2.646, 2.806, 2.828, 2.85,
     3.0, 3.373, 4.0, 4.861, 5.916, 7.133, 8.485]
print 'x = ', x
print 'y = ', y
n = len(x)
print n, ' points; ', n - 1, ' intervals'

#trapezoid
A4 = 0
y4 = []
for i in range(0, n - 1):
    delta = x[i + 1] - x[i]
    y4.append((y[i] + y[i + 1]) / 2.0)
    A4 += y4[i] * delta
print 'A (trapezoid) = ', "%8.3f" % A4

#graph
plt.plot(x, y, 'k-', lw=0.7)
plt.fill_between(x, y, 0, alpha=1, color='#3E9ECB')
for i in range(0, n - 1):
    plt.plot([x[i], x[i]], [0, y[i]], 'k-', lw=0.7)
plt.plot(x, y, 'ko')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)
plt.show()
