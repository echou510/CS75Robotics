# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9k.py
"""

import numpy as np
# create the data
dt, dv = np.pi / 180.0, np.pi / 180.0
k = 1.5
[t, v] = np.mgrid[0:2 * np.pi + dt * 1.5:dt, 0:2 * np.pi + dv * 1.5:dv]
x = k * (t - np.sin(t))
y = k * (1 - np.cos(t)) * np.cos(v)
z = k * (1 - np.cos(t)) * np.sin(v)

# represents using mayavi
from mayavi import mlab
s = mlab.mesh(x, y, z)
mlab.show()
