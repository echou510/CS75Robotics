# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9t.py
numerical integration: mid-point of each interval
"""

import numpy as np
import matplotlib.pyplot as plt

#x = [-2.0, -1.0, 0.0, 1.0, 2.0, 3.0]
#y = [0.0, 2.646, 2.828, 3.0, 4.0, 5.916]

x = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5,
     1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
y = [0.0, 2.151, 2.646, 2.806, 2.828, 2.85,
     3.0, 3.373, 4.0, 4.861, 5.916, 7.133, 8.485]
print 'x = ', x
print 'y = ', y
n = len(x)
print n, ' points; ', (n - 1) / 2, ' intervals'

#mid-point
A3 = 0
x3 = []
y3 = []
for i in range(0, n - 2, 2):
    #pmedio = x[i + 1]
    x3.append(x[i])
    y3.append(y[i + 1])
    delta = x[i + 2] - x[i]
    A3 += y[i + 1] * delta
print 'A (mid-point) = ', "%8.3f" % A3

#graph
heights = np.zeros(n, float)


def bars(h):
    heights = h
    #heights = np.append(heights, 0)
    plt.bar(x3, heights,
            width=delta, alpha=0.4, color='#3E9ECB')

for i in range(0, n - 1):
    plt.plot([x[i], x[i + 1]], [y[i], y[i + 1]], 'k--', lw=0.7)

heights = y3
bars(heights)
plt.plot(x, y, 'ko')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)
plt.show()
