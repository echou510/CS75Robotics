# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9s.py
numerical integration: right end of each interval
"""

import numpy as np
import matplotlib.pyplot as plt

#x = [-2.0, -1.0, 0.0, 1.0, 2.0, 3.0]
#y = [0.0, 2.646, 2.828, 3.0, 4.0, 5.916]

x = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5,
     1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
y = [0.0, 2.151, 2.646, 2.806, 2.828, 2.85,
     3.0, 3.373, 4.0, 4.861, 5.916, 7.133, 8.485]
print 'x = ', x
print 'y = ', y
n = len(x)
print n, ' points; ', n - 1, ' intervals'

#right end
A2 = 0
for i in range(0, n - 1):
    delta = x[i + 1] - x[i]
    A2 += y[i + 1] * delta
print 'A (right end) = ', "%8.3f" % A2

#graph
heights = np.zeros(n, float)


def bars(h):
    heights = h
    heights = np.append(heights, 0)
    plt.bar(x, heights,
            width=delta, alpha=0.4, color='#3E9ECB')

for i in range(0, n - 1):
    plt.plot([x[i], x[i + 1]], [y[i], y[i + 1]], 'k--', lw=0.7)

heights = np.delete(y, 0)
bars(heights)
plt.plot(x, y, 'ko')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)
plt.show()
