# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9m.py
"""

import numpy as np

# create data
dr, dtheta = 0.01, np.pi / 360
#[r,theta] = np.mgrid[1:2+dr:dr, 0:2*np.pi+dtheta*1.5:dtheta]
[r, theta] = np.mgrid[0:1 + dr:dr, 0:2 * np.pi + dtheta * 1.5:dtheta]
x = r * np.cos(theta)
y = r * np.sin(theta)
z2 = np.sqrt(r)
z5 = np.power(r, 0.2)
# represents with mayavi
from mayavi import mlab
s2 = mlab.mesh(x, y, z2)
s5 = mlab.mesh(x, y, z5)
mlab.show()

'''
Z = y
gira alrededor del eje y, es decir, alrededor del eje OZ
X ** 2 + Y ** 2 + Z ** 2 = R ** 2
Z = lambda
Z = X ** 2
Y = 0

despejando X en la tercera obtenemos X = np.sqrt(Z), y como Z=lambda
y la primera ecuacion queda: (np.sqrt(lambda)) ** 2 + lambda ** 2 = R ** 2
(np.sqrt(Z)) ** 2 + Z ** 2 = R ** 2
(np.sqrt(Z)) ** 2 + Z ** 2 = X ** 2 + Y ** 2 + Z ** 2
(np.sqrt(Z)) ** 2 = X ** 2 + Y ** 2
np.sqrt(Z) = np.sqrt(X ** 2 + Y ** 2)
Z = X ** 2 + Y ** 2
r = X ** 2 + Y ** 2
X = r * np.cos(theta)
Y = r * np.sin(theta)
para theta entre 0 y 2pi
'''
