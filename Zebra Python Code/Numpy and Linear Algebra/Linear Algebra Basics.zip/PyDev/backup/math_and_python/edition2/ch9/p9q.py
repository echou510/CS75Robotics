# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9q.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

x, k = sy.symbols('x, k')
sy.init_printing(use_unicode=True)

# SI units
Th = 373.0
Tc = 273.0
efficiency = 1 - (Tc / Th)
print 'Th, Tc, efficiency : ', Th, Tc, "%5.2f" % efficiency
P1 = 101325.0  # 1 atm
n = 0.5  # 0.5 moles
R = 8.314462  # J/K.mol

# isothermal expansion
# PV=nRT : V1 = nRT1/P1
V1 = n * R * Th / P1
print ('P1, V1, TH = ' + "%7.1f" % P1 +
       '; ' "%5.2f" % (1000 * V1) + 'liters; ' + str(Th))
V2 = 2.0 * V1
f1 = n * R * Th / x  # aqui x= V
print 'f1(x) =', f1
integral1 = sy.integrate(f1, x)
print 'W1 = ', integral1, ' entre ', "%7.1f" % V1, ' y ', "%7.4f" % V2
area1 = sy.integrate(f1, (x, V1, V2))
print 'W1 = ', "%7.3f" % area1
P2 = P1 * V1 / V2
print ('P2, V2, Th = ' + "%7.1f" % P2 +
       '; ' "%5.2f" % (1000 * V2) + 'liters; ' + str(Th))
print '----------------------------------------'


# adiabatic expansion
#a = V2
#b = V3
gamma = 1.66
print 'gamma = ', gamma
K = P2 * (V2 ** gamma)
print 'K = ', K
V3 = V2 * (Th / Tc) ** (1 / (gamma - 1))
P3 = K / (V3 ** gamma)
f2 = K * (x ** (-1 * gamma))
print 'f2(x) =', f2
integral2 = sy.integrate(f2, x)
print 'W2 = ', integral2, ' entre ', "%7.4f" % V2, ' y ', "%7.4f" % V3
area2 = sy.integrate(f2, (x, V2, V3))
print 'W2 = ', "%7.3f" % area2
print ('P3, V3, Tc = ' + "%7.1f" % P3 +
       '; ' "%5.2f" % (1000 * V3) + 'liters; ' + str(Tc))
print '----------------------------------------'


# isothermal compression
#P3 * V3 = P4 * V4 thus P4 = P3 * V3 / V4
#P4 V4 ** gamma = P1 V1 ** gamma = K1
K1 = P1 * V1 ** gamma
#P4 = K1 * V4 ** (-1 * gamma)
#V4 ** (1-gamma) = P3 * V3 / K1
V4 = (P3 * V3 / K1) ** (1 / (1 - gamma))
P4 = K1 * V4 ** (-1 * gamma)
f3 = n * R * Tc / x  # here  x= V
print 'f3(x) =', f3
integral3 = sy.integrate(f3, x)
print 'W3 = ', integral3, ' entre ', "%7.4f" % V3, ' y ', "%7.4f" % V4
area3 = sy.integrate(f3, (x, V3, V4))
print 'W3 = ', "%7.3f" % area3
print ('P4, V4, Tc = ' + "%7.1f" % P4 + '; ' "%5.2f" % (1000 * V4) + 'liters; ' + str(Tc))
print '---------------------------------------'


# adiabatic compression
#a = V4
#b = V1
#gamma = 1.66
print 'gamma = ', gamma
print 'K = ', K1
f4 = K1 * (x ** (-1 * gamma))
print 'f4(x) =', f4
integral4 = sy.integrate(f4, x)
print 'W4 = ', integral4, ' entre ', "%7.4f" % V4, ' y ', "%7.4f" % V1
area4 = sy.integrate(f4, (x, V4, V1))
print 'W4 = ', "%7.3f" % area4
print '----------------------------------------'

print 'W = W1 + W2 + W3 + W4 = ', "%7.3f" % (area1 + area2 + area3 + area4)
print 'checkings: '
print ('W = efficiency * Q12 = ' + "%7.3f" % (efficiency * area1))
print ('Q12 absorbed by the hot reservoir during isothermal expansion = ' +
       "%7.3f" % area1 + ' = ' "%7.3f" % (n * R * Th * np.log(V2 / V1)))
print ('Q34 taken by the cold reservoir during isothermal expansion = ' +
       "%7.3f" % area3 + ' = ' "%7.3f" % (n * R * Tc * np.log(V4 / V3)))
print '|Q34| / Q12 = Tc / Th :'
print "%7.5f" % (np.abs(area3) / area1), ' = ', "%7.5f" % (Tc / Th)

#graph
pointsnum = 100
equis1 = np.linspace(V1, V2, pointsnum)
y1 = np.zeros(pointsnum, float)
equis2 = np.linspace(V2, V3, pointsnum)
y2 = np.zeros(pointsnum, float)
equis3 = np.linspace(V3, V4, pointsnum)
y3 = np.zeros(pointsnum, float)
equis4 = np.linspace(V4, V1, pointsnum)
y4 = np.zeros(pointsnum, float)


def f1(z):  # isothermal expansion
    f1x = n * R * Th / z
    return f1x


def f2(z):  # adiabatic expansion
    f2x = K * (z ** (-1 * gamma))
    return f2x


def f3(z):  # isothermal compression
    f3x = n * R * Tc / z
    return f3x


def f4(z):  # adiabatic expansion
    f4x = K1 * (z ** (-1 * gamma))
    return f4x

for i in range(0, pointsnum):
    y1[i] = f1(equis1[i])
    y2[i] = f2(equis2[i])
    y3[i] = f3(equis3[i])
    y4[i] = f4(equis4[i])
'''
print equis1
print equis2
print equis3

print y1
print y2
print y3
'''
plt.plot(equis1, y1, color='k', lw=2)
plt.fill_between(equis1, y1, 0, alpha=1.0, color='#A1BCC3')
plt.plot(equis2, y2, color='k', lw=2)
plt.fill_between(equis2, y2, 0, alpha=1.0, color='#A1BCC3')
plt.plot(equis3, y3, color='k', lw=2)
plt.fill_between(equis3, y3, 0, alpha=1.0, color='#FFFFFF')
plt.plot(equis4, y4, color='k', lw=2)
plt.fill_between(equis4, y4, 0, alpha=1.0, color='#FFFFFF')
plt.text(V1, 1.02 * P1, '1', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.text(V2, 1.02 * P2, '2', horizontalalignment='left',
         fontsize=15, color='black', weight='bold')
plt.text(V3, 1.05 * P3, '3', horizontalalignment='left',
         fontsize=15, color='black', weight='bold')
plt.text(V4, 0.95 * P4, '4', horizontalalignment='center',
         verticalalignment='top',
         fontsize=15, color='black', weight='bold')
plt.ylabel('$P \quad (Nm^-2)$')
plt.xlabel('$V \quad (m^3)$')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
#plt.plot([a, a], [0, f(a)], 'k--', lw=1)
#plt.plot([b, b], [0, f(b)], 'k--', lw=1)
plt.xlim(0, 1.1 * np.max(equis2))
#plt.xlim(0, 1.1 * np.max(equis))
#plt.ylim(0, np.max(y))
plt.show()
