# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9w.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

z = sy.symbols('z')
sy.init_printing(use_unicode=True)
a = 1.0
b = np.e
#sympy
funcion = 1 / z
print 'f(x) = '
print funcion
I = sy.integrate(funcion)
print 'F(x) = '
print I
Area = sy.integrate(funcion, (z, a, b))
print 'Total area calculated using Sympy:'
print 'A = ', "%6.3f" % Area
print 'ln e = 1'
#graph
pointsnum = 100
x = np.linspace(a, b, pointsnum)
f = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    f[i] = 1.0 / x[i]
plt.plot(x, f, 'k-', lw=2)
plt.fill_between(x, f, 0, alpha=1, color='#BDD0D7')
plt.plot([a, a], [0, 1], 'k--', lw=2)
plt.plot([b, b], [0, 1 / b], 'k--', lw=2)
plt.text(a, -0.1, '1', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.text(b, -0.1, 'e', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.legend(('f(x)=1/x',), loc='best')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.xlim(-0.25, b + 0.25)
plt.ylim(-0.25, 1.25)
plt.show()
s