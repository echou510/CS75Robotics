# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9i.py
"""

import matplotlib
import numpy as np
import sympy as sy
from matplotlib.pyplot import figure, show, rc, grid

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

z, k = sy.symbols('z, k')
sy.init_printing(use_unicode=True)
a = 2 * sy.pi
b = 4 * sy.pi
#sympy
function = k * z
print 'f(x) = '
print function
f_to_integrate = sy.Pow(function, 2)
print 'F(x) = '
print sy.simplify((sy.integrate(f_to_integrate, (z))) / 2)
#print f_to_integrate
print
Area = (sy.integrate(f_to_integrate, (z, a, b))) / 2
print 'Area[', a, ', ', b, '] = ', Area


#graph
r = []
theta = []
x = []
y = []
r.append(0.0)
theta.append(0.0)

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  makes a square
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True, axisbg='#ffffff')
angulo = 0
grid(False)
while angulo <= 6 * np.pi:
    angulo += np.pi / 36
    theta.append(angulo)
    radio = 5.0 * angulo
    r.append(radio)
    x.append(radio * np.cos(angulo))
    y.append(radio * np.sin(angulo))
ax.plot(theta, r, color='#1821EE', lw=1.5)
show()
