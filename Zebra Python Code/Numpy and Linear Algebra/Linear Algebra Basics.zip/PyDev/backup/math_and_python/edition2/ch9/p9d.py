# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9d.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

x = sy.symbols('x')
sy.init_printing(use_unicode=True)


a = -5.0
b = 5.0
function = sy.simplify(x ** 3 - 13 * x + 12)  # polynomial
npfunction = [1, 0, -13, 12]  # polynomial coefficients



a = -1.25
b = 0.7
function = sy.simplify(x ** 5 + 2 * x ** 4 +
                      (x ** 3) / 4 - (3 * x ** 2) / 4)
npfunction = [1, 2, 0.25, -0.75, 0, 0]


#sympy
print 'f(x) = '
print function
I = sy.integrate(function)
print 'F(x) = '
print I
print

#numpy
roots = np.round(np.sort(np.roots(npfunction)), 2)
print 'axis X cuts: ', roots
ends = [a]
i = 0
while i < len(roots):
    #print roots[i], ends[i]
    if (roots[i] > ends[i] and roots[i] < b):
        ends.append(roots[i])
    else:
        ends.append(ends[i])
    #print ends
    i += 1
ends.append(b)
#print 'ends de los intervalos de integracion: ', ends
ends = np.unique(ends)
print 'ends of the integration intervals: ', ends
areas = np.zeros(len(ends) - 1, float)
for i in range(0, len(ends) - 1):
    areas[i] = sy.integrate(function, (x, ends[i],
                            ends[i + 1]))
print 'surfaces of the intervals: '
print areas
areas = np.absolute(areas)
print "absolute values of the surfaces of the intervals: "
print areas
print 'Total Area = ', np.sum(areas)

#grafica
pointsnum = 200
x = np.linspace(a, b, pointsnum)
f = np.zeros(pointsnum, float)
for i in range(0, pointsnum):
    f[i] = np.polyval(npfunction, x[i])
plt.plot(x, f, 'k-', lw=2)
plt.fill_between(x, f, 0, alpha=0.8, color='#BDD0D7')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.xlim(a, b)
plt.legend(('$f(x)$',), loc='best')
plt.show()
