# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9o.py
"""

import numpy as np

# create data
#constants:
k = 0.6  # fluid constant, for water k=0.6
g = 9.81  # gravity

#data:
seconds = 3600  # time to empty the clepsydra, in seconds
print 'time to empty: ', seconds, ' seconds'
H = 0.2  # height in meters
print 'clepsydra height: ', H * 1000, ' mm'
rs = 1.0  # radius of the hole, in mm

#calculations:
s = np.pi * (rs * 1e-3) ** 2  # area
print 'diameter of the hole: ', 2 * rs, 'mm'
a = H / seconds  # speed of the water level, in m/s
print ('the water level goes down at a constant speed = ' +
       str(np.round(a * 60 * 1000, 0)) + ' mm / minute')
c = (np.pi ** 2 * a ** 2) / (2 * g * k ** 2 * s ** 2)
#c = a ** 2 / ( 2 * g * (rs * 1e-3) ** 4)
print 'c = ', c
#h = c r ** 4
R = np.power(H / c, 0.25)
print 'clepsydra radius: ', 1000 * R, ' mm'
V = np.pi * H * R ** 2 - (np.pi * c * R ** 6) / 3
print ('clepsydra volume: ' + "%10.6f" % V + ' m3 = ' +
       "%6.3f" % (V * 1000) + ' litres')
'''
volumen por secciones:
area de una seccion = pi * r ** 2
y = c * r ** 4
area de una seccion = pi * (y / c) ** (2 / 4) = (pi / c ** (1 / 2)) * y ** (1 / 2)
integrando entre y=0 y h:
V = (pi / c ** (1 / 2)) * (2 / 3) * h ** (3 / 2)
'''
Vsec = (np.pi / c ** 0.5) * (2.0 / 3) * H ** (1.5)
print ('Volume calculate by sections: ' +
       "%10.6f" % Vsec + ' m3 = ' +
       "%6.3f" % (Vsec * 1000) + ' litres')
print
print ('Volume of a cone of same radius and height: ' +
       "%6.3f" % ((1000 * H * np.pi / 3.0) * R ** 2) + ' litres')
# pi c h(6/4) c(-6/4) / 3 = pi c(-1/2) h(3/2) / 3 para la clepsidra
# pi h h(2/4) c(-2/4) / 3 = pi c(-1/2) h(3/2) / 3 para el cono
print ('Volume of a cylinder of same radius and height: ' +
       "%6.3f" % (1000 * H * np.pi * R ** 2) + ' litres')
#print ('Area entre la curva y el eje Y = ', 0.8 * c * (h / c) ** 1.25)
print ('Area bounded by the curve and axis Y = ' +
       "%7.1f" % ((H * R - ((c * R ** 5) / 5)) * 1e4) + ' cm2')
print 'Relations among cone, clepsydra and cylinder:'
print 'V clepsydra= ', Vsec / ((H * np.pi / 3.0) * R ** 2), 'Vcone'
print 'V cylinder = ', 3.0, 'Vcono'

# matplotlib plotting
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
dr = 1e-3
dtheta = 0.01
[r, theta] = np.mgrid[0:R + dr:dr, 0:2 * np.pi + dtheta * 1.5:dtheta]
x = r * np.cos(theta)
y = r * np.sin(theta)
#clepsydra
z = c * ((x ** 2 + y ** 2)) ** 2
ax.plot_wireframe(x, y, z, rstride=15, cstride=15, color='blue')
ax.plot_wireframe(x, y, z, rstride=15, cstride=15, color='blue')
#cone
zcono = (H / R) * np.sqrt(x ** 2 + y ** 2)
ax.plot_wireframe(x, y, zcono, rstride=15, cstride=15, color='red')
#cylinder x**2 + y**2 = R ** 2
xcil = np.linspace(-R, R, 200)
zcil = np.linspace(0, H, 200)
X, Z = np.meshgrid(xcil, zcil)
Y = np.sqrt(R ** 2 - X ** 2)
ax.plot_wireframe(X, Y, Z, rstride=40, cstride=40, color='green')
ax.plot_wireframe(X, -Y, Z, rstride=40, cstride=40, color='green')

plt.xlabel('x')
plt.ylabel('y')
plt.show()


#trazado de la clepsidra con mayavi:
#dr = 1e-3
#dtheta = 0.01
#[r, theta] = np.mgrid[0:radiomax + dr:dr,
#                      0:2 * np.pi + dtheta * 1.5:dtheta]
#x = r * np.cos(theta)
#y = r * np.sin(theta)

# clepsydra plotting with mayavi
z = c * r ** 4
from mayavi import mlab
s = mlab.mesh(x, y, z)
mlab.show()
