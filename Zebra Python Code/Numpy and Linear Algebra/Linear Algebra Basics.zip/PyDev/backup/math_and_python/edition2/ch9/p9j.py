# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p9j.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

t1 = 0.0
t2 = 2 * np.pi
print 't1 = ' + "%5.3f" % t1
print 't2 = ' + "%5.3f" % t2 + ' = 2 pi'

k = 1.5  # for numpy, the constant is k, and for sympy it is c
print 'k = ', k

z, c = sy.symbols('z, c')
sy.init_printing(use_unicode=True)

print 'r = c^2 (1-cosz)^2 + (senz)^2 = '
r = sy.simplify((c ** 2) *
                        ((1 - sy.cos(z)) ** 2 + (sy.sin(z) ** 2)))
print ' = ', r
print ' = 2 * c**2 * (1-cos(z) = 4 * c**2 * [sin(z/2)] ** 2'
integral = sy.integrate(2 * c * sy.sin(z / 2), (z, 0, 2 * sy.pi))
print 'L = ', integral
print 'If c = ', k, ' then L = ', 8 * k


def f(t):
    fv = k * (t - np.sin(t))
    return fv


def g(t):
    gv = k * (1 - np.cos(t))
    return gv

print 'a = ' + "%5.3f" % f(t1)
print 'b = ' + "%5.3f" % f(t2)
pointsnum = 360
tinicial = 0
tfinal = pointsnum
x = np.zeros(pointsnum, float)
y = np.zeros(pointsnum, float)
t = tinicial
while t < tfinal:
    radians = np.deg2rad(t)
    x[t] = f(radians)
    y[t] = g(radians)
    t += 1
plt.plot(x, y, 'b-', lw=2)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.axis([-0.5, 10, -0.5, 10])
#plt.axis('equal')
plt.ylabel('y')
plt.xlabel('x')
plt.show()
