# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming © www.pysamples.com
p7f.py
"""

import matplotlib
import numpy as np
from matplotlib.pyplot import figure, show, rc, grid

pi = np.pi
z1 = [1.02, pi / 10]

pifraction = int(pi / z1[1])
r = []
theta = []
r.append(z1[0])
theta.append(z1[1])

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

# figura
width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  hace un cuadrado
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True, axisbg='#ffffff')

#potencias de z
for i in range(1, 4 * pifraction + 1):
    radius = np.power(r[0], i)
    r.append(radius)
    angle = theta[0] * i
    theta.append(angle)
    etiqueta = '$z^{' + str(i) + '}$'
    ax.annotate(etiqueta,
                xy=(angle, 1.1 * radius),  # theta, radius
                horizontalalignment='center',
                verticalalignment='middle',
                fontsize=14, color='#EE182E')

ax.plot(theta, r, color='#1821EE', lw=4)
ax.set_rmax(max(r) * 1.25)
grid(True)
#print r
#print theta
show()
