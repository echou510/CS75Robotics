# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p7e.py
"""

import matplotlib
import numpy as np
from matplotlib.pyplot import figure, show, rc, grid

pi = np.pi
z1 = [1.0, pi / 6]

pifraction = int(pi / z1[1])
r = []
theta = []
r.append(z1[0])
theta.append(z1[1])

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

# figure
width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  square
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8],
                  polar=True, axisbg='#ffffff')

#powers of z
for i in range(2, 2 * pifraction + 2):
    radius = np.power(r[0], i)
    r.append(radius)
    angle = theta[0] * i
    theta.append(angle)
    if i < 2 * pifraction + 1:
        label = '$z^{' + str(i) + '}$'
    else:
        label = '$z^{' + str(1) + '}$'
    if i <= pifraction:
        radiuslabel = 1.1 * radius
        hlabel = 'center'
        vlabel = 'middle'
    elif i <= 2 * pifraction:
        radiuslabel = 1.2 * radius
        hlabel = 'center'
        vlabel = 'bottom'
    else:
        radiuslabel = 1.1 * radius
        hlabel = 'center'
        vlabel = 'middle'
    ax.annotate(label,
                xy=(angle, radiuslabel),  # theta, radius
                horizontalalignment=hlabel,
                verticalalignment=vlabel,
                fontsize=18, color='#EE182E')

#print r
#print theta
ax.plot(theta, r, color='#1821EE', lw=4)
ax.set_rmax(max(r) * 1.5)
grid(True)
show()
