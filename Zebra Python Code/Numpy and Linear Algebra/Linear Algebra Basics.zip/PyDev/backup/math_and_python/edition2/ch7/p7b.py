# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p7b.py
crecimiento exponencial
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

#source: http://www.census.gov/population/www/censusdata/files/table-2.pdf
       #http://www.census.gov/main/www/cen2000.html
       #http://www.census.gov/2010census/popmap/
pob1 = {1790: 3929214, 1800: 5308483, 1810: 7239881, 1820: 9638453, 1830: 12866020,
         1840: 17069453, 1850: 23191876, 1860: 31443321, 1870: 38558371, 1880: 50189209,
         1890: 62979766, 1900: 76212168}
pob2 = {1900: 76212168, 1910: 92228496, 1920: 106021537, 
         1930: 123202624, 1940: 132164569, 1950: 151325798, 1960: 179323175,
         1970: 203302031, 1980: 226542199, 1990: 248709873, 2000: 281421906 , 2010: 308745538 }

xdata1 = np.sort(pob1.keys())
xdata2 = np.sort(pob2.keys())

ydata1 = np.sort(pob1.values())
ydata2 = np.sort(pob2.values())


fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1)
ax.set_xlim(1780, 2020)
#ax.set_ylim(10e6, 50e6)
plt.ylabel('y = population')

p1, = plt.plot(xdata1, ydata1, 'ko')
p2, = plt.plot(xdata2, ydata2, 'ko')

#least squares fit:'
lny1 = np.zeros(12, float)
for i in range(0, 12):
    lny1 = np.log(ydata1)
lny2 = np.zeros(12, float)
for i in range(0, 12):
    lny2 = np.log(ydata2)

slope, intercept, r_value, p_value, std_err = stats.linregress(xdata1, lny1)
print 'r^2: ', "%8.6f" % (r_value ** 2)
print ('line: y =  ' + "%6.4f" % slope +
       'x + ' + "%6.4f" % intercept)
print 'exponential y=Ae^bx:'
print ('y = ' + "%.4g" % np.exp(intercept) +
       ' e^(' + "%6.4f" % (slope) + 'x)')
ymc1 = np.zeros(12, float)
for i in range(0, 12):
    ymc1[i] = np.exp(intercept) * np.exp(slope * xdata1[i])
p3, = plt.plot(xdata1, ymc1, 'r', lw=2)

slope, intercept, r_value, p_value, std_err = stats.linregress(xdata2, lny2)
print 'r^2: ', "%8.6f" % (r_value ** 2)
print ('line: y =  ' + "%6.4f" % slope +
       'x + ' + "%6.4f" % intercept)
print 'exponential y=Ae^bx:'
print ('y = ' + "%.4g" % np.exp(intercept) +
       ' e^(' + "%6.4f" % (slope) + 'x)')
ymc2 = np.zeros(12, float)
for i in range(0, 12):
    ymc2[i] = np.exp(intercept) * np.exp(slope * xdata2[i])
p4, = plt.plot(xdata2, ymc2, 'b', lw=2)
plt.show()
