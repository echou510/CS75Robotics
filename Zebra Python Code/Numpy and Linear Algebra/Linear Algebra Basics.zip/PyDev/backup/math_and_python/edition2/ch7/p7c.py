# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p7c.py
"""

from matplotlib import rc
import matplotlib.pyplot as plt
import numpy as np

j = complex(0, 1)
pi = np.pi
z1 = [1.05, pi]
n = 5

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)
plt.figure()
plt.ylabel('Im')
plt.xlabel('Re')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.grid(b=None, which='major')
plt.ylim(-1, 2)
plt.xlim(-1.25, 1.25)


def flecha(z, text):
    dx = z.real
    dy = z.imag
    plt.arrow(0, 0, dx, dy, width=0.003, fc='b',
              ec='none', length_includes_head=True)
    if dx == 0:
        xtext = dx + 0.03
    else:
        xtext = np.sign(dx) * (abs(dx) * 1.05)
    if dy == 0:
        ytext = dy + 0.01
    else:
        ytext = np.sign(dy) * (abs(dy) * 1.05)
    plt.text(xtext, ytext, text,
             horizontalalignment='center',
             size='large', color='#EF0808',
             weight='bold')

for i in range(1, n + 2):
    r = np.power(z1[0], (1.0 / i))
    theta = z1[1] / i
    print (str(i) + ': ' + "%12.6f" % r +
           "%12.3f" % (theta / pi) + 'pi = ' +
           'pi/' + "%1.0f" % (pi / theta))
    a = r * np.cos(theta)
    b = r * np.sin(theta)
    z = complex(a, b)
    if i > 1:
        label = '$z^{1/' + str(i) + '}$'
    else:
        label = '$z$'
    flecha(z, label)

plt.show()
