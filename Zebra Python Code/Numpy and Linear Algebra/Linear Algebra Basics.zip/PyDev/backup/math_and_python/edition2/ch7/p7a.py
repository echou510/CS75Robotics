# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p7a.py
"""

from numpy import e


def fact(x):
    if x == 0:
        return 1
    else:
        return x * fact(x - 1)


def u(i):
    termino = 1.0 / fact(i)
    return termino

x = 1.0
n = 12  # number of terms to calculate
s = 0
for i in range(0, n + 1):
    s += u(i)
    print 'S(' + str(i) + ') = ' + "%20.18f" % s

print 'real value of e: ' + "%20.18f" % e
print 'error: ' + "%10.8g" % (e - s)
