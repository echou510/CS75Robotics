# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pj.py
'''

alist = ''
for i in range(0, 101, 5):
    alist = alist + str(i) + ','
print alist
