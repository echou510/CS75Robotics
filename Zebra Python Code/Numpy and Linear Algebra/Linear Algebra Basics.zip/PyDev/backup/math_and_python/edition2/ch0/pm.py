# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pm.py
'''

import numpy as np
import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
tt.speed('fastest')
a = 200
degrees = 0
while degrees <= 180:
    radians = np.deg2rad(degrees)
    r = a * np.sin(3 * radians)
    x = int(r * np.cos(radians))
    y = int(r * np.sin(radians))
    y2 = - y
    tt.goto(x, y)
    tt.pendown()
    tt.pencolor('blue')
    tt.dot(4)
    tt.penup()
    tt.goto(x, y2)
    tt.pendown()
    tt.pencolor('red')
    tt.dot(4)
    tt.penup()
    degrees += 0.5
tt.hideturtle()
