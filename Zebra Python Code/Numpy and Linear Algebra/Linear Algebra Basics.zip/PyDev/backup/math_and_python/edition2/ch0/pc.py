# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pc.py
'''

e1 = 23
e2 = -2
r1 = 0.01
r2 = 2.5e-3
print 'operations with integers:'
print 'e1 + e2 = ', e1 + e2
print 'e1 - e2 = ', e1 - e2
print '-e2 = ', -e2
print 'e1 * e2 = ', e1 * e2
print 'fifth power of e2 = ', e2 ** 5
print 'division of integers: e1/e2 = ', e1 / e2
print ('exact division of integers: e1/e2 = ' +
       str(1.0 * e1 / e2))
print 'operations with real numbers:'
print 'e1 * r1 = ', e1 * r1
print 'e1 / r1 = ', e1 / r1
print 'r1 / r2 = ', r1 / r2
print 'fourth power of r2 = ', r2 ** 4
print 'division: 7.5/2 = ', 7.5 / 2
print 'truncated division 7.5//2 = ', 7.5 // 2
print ('modulus: 7.5 % 2 = ' + str(7.5 // 2))
