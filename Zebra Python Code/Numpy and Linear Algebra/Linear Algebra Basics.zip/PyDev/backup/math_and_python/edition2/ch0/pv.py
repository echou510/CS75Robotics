# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
pv.py
"""

vocals = 'aeiouAEIOUÁÉÍÓÚáéíóúüÜ'
consonants = 'bBcCdDfFgGhHjJkKlLmMnNñÑpPqQrRsStTvVwWxXyYzZ'

dictvoc = {}
dictcons = {}

input = file('The Life and Adventures of Robinson Crusoe.txt')
#input = file('English We Speak.txt')
#input = file('The Tragedie of Hamlet.txt')
#input = file('Maxwell.txt')
#input = file('Adventures of Huckleberry Finn.txt')



#input = file('Kennedy Berlin speech.txt')
#input = file('Winston Churchill Iron Curtain Speech.txt')
#input = file('The Canterbury Tales and Other Poems.txt')
#input = file('1984.txt')
#input = file('The Old man and the Sea.txt')
#input = file('USA Independence Declaration.txt')
#input = file('dream-speech.txt')
#input = file('USMC manual.txt')
#input = file('english grammar.txt')
#input = file('The Crisis by Winston Churchill.txt')
#input = file('Americas Great Depression.txt')
#input = file('Shakespeare sonets.txt')
#input = file('Fairy and Folk Tales of the Irish Peasantry, by W.B. Yeats.txt')
#input = file('Ulysses, by James Joyce.txt')
#input = file('wellington.txt')

text = input.read()
utext = unicode(text, 'utf-8')

lentext = len(utext)
#print utext
print lentext

dictvoc['a'] = (utext.count('a') + utext.count('á') +
                utext.count('A') + utext.count('Á'))
dictvoc['e'] = (utext.count('e') + utext.count('é') +
                utext.count('E') + utext.count('É'))
dictvoc['i'] = (utext.count('i') + utext.count('í') +
                utext.count('I') + utext.count('Í'))
dictvoc['o'] = (utext.count('o') + utext.count('ó') +
                utext.count('O') + utext.count('Ó'))
dictvoc['u'] = (utext.count('u') + utext.count('ú') +
                utext.count('U') + utext.count('Ú') +
                utext.count('ü') + utext.count('Ü'))
'''print dictvoc
print dictvoc.keys()'''
nvocals = dictvoc.values()
number_vocals = 0
for i in nvocals:
    number_vocals += i
print 'vocals total: ', number_vocals
listvocals = dictvoc.items()
listvocals.sort()
print listvocals


def countcons(text, letra):
    recuento = (text.count(letra) +
                text.count(letra.upper()))
    return recuento
dictcons['b'] = countcons(utext, 'b')
dictcons['c'] = countcons(utext, 'c')
dictcons['cedilla'] = countcons(utext, 'ç')
dictcons['d'] = countcons(utext, 'd')
dictcons['f'] = countcons(utext, 'f')
dictcons['g'] = countcons(utext, 'g')
dictcons['h'] = countcons(utext, 'h')
dictcons['j'] = countcons(utext, 'j')
dictcons['k'] = countcons(utext, 'k')
dictcons['l'] = countcons(utext, 'l')
dictcons['m'] = countcons(utext, 'm')
dictcons['n'] = countcons(utext, 'n')
enemays = 'Ñ'.encode('utf-8')
nene = utext.count('ñ') + utext.count(enemays)
dictcons['ntilde'] = nene
dictcons['p'] = countcons(utext, 'p')
dictcons['q'] = countcons(utext, 'q')
dictcons['r'] = countcons(utext, 'r')
dictcons['s'] = countcons(utext, 's')
dictcons['t'] = countcons(utext, 't')
dictcons['v'] = countcons(utext, 'v')
dictcons['w'] = countcons(utext, 'w')
dictcons['x'] = countcons(utext, 'x')
dictcons['y'] = countcons(utext, 'y')
dictcons['z'] = countcons(utext, 'z')

'''print dictcons
print dictcons.values()'''
nconsonants = dictcons.values()
number_consonants = 0
for i in nconsonants:
    number_consonants += i
print 'consonants total: ', number_consonants
listcons = dictcons.items()
listcons.sort()
print listcons
#------------------------------------------------
array100vocals = [0.0, 0.0, 0.0, 0.0, 0.0]
for i in range(0, 5):
    array100vocals[i] = float("%7.3f" %
                             (100.0 * listvocals[i][1] /
                             (number_vocals + number_consonants)))
percentagevocals = 0
for i in array100vocals:
    percentagevocals += i
print array100vocals, ' = ', percentagevocals, '%'
#------------------------------------------------
array100cons = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0]
for i in range(0, 23):
    array100cons[i] = float("%7.3f" %
                            (100.0 * listcons[i][1] /
                            (number_vocals + number_consonants)))
percentagecons = 0
for i in array100cons:
    percentagecons += i
print array100cons, ' = ', percentagecons, '%'
