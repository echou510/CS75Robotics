# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
"""

print 'hola'
