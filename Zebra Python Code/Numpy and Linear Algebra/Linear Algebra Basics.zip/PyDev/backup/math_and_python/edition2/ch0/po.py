# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
po.py
endless while statement
'''

number = int(raw_input('Write a natural number: '))

result = str(number) + ' = '
PrimeFactor = 2
divisions = 0
print 'number: ', number
while PrimeFactor <= number:
    remainder = number % PrimeFactor
    print number, PrimeFactor, remainder
    divisions += 1
    if remainder == 0:
        result = result + str(PrimeFactor) + '.'
        #number = number / PrimeFactor
        divisions += 1
    else:
        if PrimeFactor > 2:
            PrimeFactor += 2
        else:
            PrimeFactor += 1
result = result.rstrip('.')
print result
print divisions, ' divisions made'
