# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
pu.py
"""

#from mpl_toolkits.mplot3d import axes3d
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
#from matplotlib import cm, rc
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
#fig = plt.figure(facecolor='white')


a = 3.592  # atm l2 mol-2
b = 0.0427  # l mol-1
R = 0.08206  # atl l K-1 mol-1
pointsnumber = 500
v = np.linspace(0.064, 0.15, pointsnumber)  # x = V
#p = np.linspace(0, 100.0, pointsnumber)
t = np.linspace(260, 320, pointsnumber)
#X, Y = np.meshgrid(v, p)
X, Y = np.meshgrid(v, t)
#Z = (Y + (a / X ** 2)) * (X - b) / R
Z = (R * Y / (X - b)) - (a / X ** 2)

ax.plot_wireframe(X, Y, Z, rstride=25, cstride=25, lw=0.5, color='b')
#ax.plot_surface(X, Y, Z,  rstride=10, cstride=10, color='c')
#ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
#                linewidth=0, antialiased=False)
#font = {'family': 'normal', 'size': 9}

#plt.rc('font', **font)
plt.xlabel('V')
#plt.ylabel('P')
plt.ylabel('T')
plt.show()
