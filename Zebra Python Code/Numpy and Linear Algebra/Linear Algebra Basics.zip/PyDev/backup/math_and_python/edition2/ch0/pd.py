# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pd.py
'''

import numpy as np

pi = np.pi
print pi
print str(pi)
print "%10.2f" % pi
print "%10.8f" % pi
print np.trunc(pi)
print "%20.18f" % pi
