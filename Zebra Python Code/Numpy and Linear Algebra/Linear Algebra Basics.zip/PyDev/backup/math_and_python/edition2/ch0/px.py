# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
px.py
"""

import numpy as np
import matplotlib.pyplot as plt

# data from English texts mentioned in the book:

vocals = [353824, 5795, 48352, 256568, 160562, 1229, 8825, 415116,
           175791, 38536, 2881, 2657, 92734, 183069, 276660, 245519,
           32740, 188099, 446497, 234732]
consonants = [578460, 9437, 73971, 408384, 267005, 1951, 13922, 685427,
               286981, 64981, 4703, 4480, 147707, 293164, 459023, 402004,
               56058, 309459, 751081, 379425]

nvocals = np.sum(vocals)
nconsonants = np.sum(consonants)
books = len(vocals)
print 'data from ' + str(books) + ' books'
print ('Sample of ' + str(nvocals + nconsonants) +
       ' letters, of which ' + str(nvocals) + ' are vocals.')
per1000 = np.zeros(books, float)
for i in range(0, books):  # vocals por cada mil letras
    per1000[i] = float("%8.2f" % (1000.0 * vocals[i] /
                      (vocals[i] + consonants[i])))
print 'data: '
print per1000
creciente = np.sort(per1000)
print 'Data arranged from lowest to highest: '
print creciente
#max, min, recorrido, numero de datos
maximo = float("%8.2f" % np.max(per1000))
print 'maximum: ', maximo
minimo = float("%8.2f" % np.min(per1000))
print 'minimum: ', minimo
recorrido = float("%8.2f" % (maximo - minimo))
print 'range: ', recorrido
n = len(per1000)
print 'n: ', n
suma = np.sum(per1000)
print 'sum: ', suma

nintervals = 11  # 10 + 1
amplitud = np.ceil((recorrido / (nintervals - 1)))  # 2
print 'width of an interval: ', amplitud

liminf = np.trunc(np.min(per1000)) - (amplitud / 2.0)
intervals = np.zeros(nintervals, int)
intervals[0] = liminf  # -1
classmarks = np.zeros(nintervals, float)
classmarks[0] = liminf + (amplitud / 2.0)
for i in range(1, nintervals):
    intervals[i] = intervals[i - 1] + amplitud
for i in range(1, nintervals - 1):
    classmarks[i] = float("%8.2f" %
                         (classmarks[i - 1] + amplitud))
print str(nintervals - 1) + ' intervals: ' + str(intervals)
print 'class marks: ' + str(classmarks)
fintervals = np.zeros(nintervals - 1, int)
for i in range(1, nintervals):
    for j in range(0, n):
        if ((creciente[j] < intervals[i]) and (creciente[j] >= intervals[i - 1])):
            fintervals[i - 1] += 1
print 'f of the intervals: ', fintervals
#print creciente

#medidas de tendencia central
arithmeticmean = float("%8.2f" % np.mean(per1000))
print 'arithmetic mean: ', arithmeticmean
median = float("%8.2f" % np.median(per1000))
print 'median: ', median
product = 1.0
for i in range(0, n):
    product = product * creciente[i]
geometric_mean = float("%8.2f" % product ** (1.0 / n))
print 'geometric mean: ', geometric_mean
print 'arithmetic mean must be greater than geometric mean:'
print arithmeticmean, ' > ', geometric_mean
#medidas de variabilidad
diferencias = np.zeros(25, float)
for i in range(0, n):
    diferencias[i] = float("%8.2f" %
                    (np.absolute(per1000[i] - arithmeticmean)))
print '|xi - mean|: ', diferencias
standard_deviation = float("%8.2f" % (np.sum(diferencias) / n))
print ('standard deviation of ungrouped data: ' +
        str(standard_deviation))
diferenciasAG = np.zeros(nintervals - 1, float)
for i in range(0, nintervals - 1):
    diferenciasAG[i] = float("%8.2f" % (fintervals[i] *
                        np.absolute(classmarks[i] - arithmeticmean)))
print 'fi |mark_i - mean|: ', diferenciasAG
standard_deviationAG = float("%8.2f" % (np.sum(diferenciasAG) / nintervals))
print 'standard deviation of grouped data: ', standard_deviationAG
standard_deviation = float("%8.2f" % np.std(per1000))
print 'standard deviation s: ', standard_deviation
variance = float("%8.2f" % np.var(per1000))
print 'variance s2: ', variance
print 'If the data follow the normal distribution, '
print 'the mean deviation should be approximately (4 * s / 5):'
print ('mean deviation: ' + str(standard_deviation) +
       '; 4s/5: ' + str(0.8 * standard_deviation))
if arithmeticmean != 0:
    variacionPearson = (100 * standard_deviation / arithmeticmean)
    print ('Pearson coefficient: C.V. =' +
            "%4.2f" % variacionPearson)
asimetriaPearson = float("%8.2f" %
     (3 * (arithmeticmean - median) / standard_deviation))
if asimetriaPearson == 0:
    phrase1 = 'arithmetic mean = median'
elif asimetriaPearson < 0:
    phrase1 = 'arithmetic mean < median'
else:
    phrase1 = 'arithmetic mean > median'
print 'Pearson asymmetry: ', asimetriaPearson, ': ', phrase1
m4 = 0
for i in range(0, n):
    m4 += diferencias[i] ** 4
m4 = float("%8.2f" % (m4 / n))
print 'm4 = ', m4
print ('a: C.V. =' +
            "%4.2f" % variacionPearson)
kurtosis = float("%8.2f" % (m4 / (variance ** 2)))
if kurtosis == 0:
    phrase2 = 'normal curve'
elif kurtosis < 0:
    phrase2 = 'platykurtic'
else:
    phrase2 = 'leptokurtic'
print 'kurtosis = ', kurtosis, ' : the curve is ', phrase2

#grafica
fig, ax = plt.subplots(1)
textstr = (
'$mean=%.2f$\n$\mathrm{median}=%.2f$\n$\sigma=%.2f$' %
            (arithmeticmean, median, standard_deviation)
            )
props = dict(boxstyle='round', facecolor='#FCE945', alpha=0.6)
ax.text(0.05, 0.95, textstr, transform=ax.transAxes,
        fontsize=14, verticalalignment='top', bbox=props)
binsx = np.linspace(intervals[0], intervals[nintervals - 1],
                    nintervals)
ax.hist(per1000, binsx, alpha=0.75, color='#F2AE04')

plt.plot([arithmeticmean, arithmeticmean],
         [0, np.max(fintervals) + 0.3], 'r', lw=2.5)
plt.text(arithmeticmean, np.max(fintervals) + 0.5,
         '$mean=%.2f$' % arithmeticmean,
         horizontalalignment='left', color='red')
plt.plot([median, median],
         [0, np.max(fintervals) + 0.1], 'g', lw=2.5)
plt.text(median, np.max(fintervals) + 0.2,
         '$median=%.2f$' % median,
         horizontalalignment='left', color='green')

plt.plot([np.min(intervals) - 1, classmarks[0]],
         [0, fintervals[0]], 'k--', lw=2)
for i in range(0, (len(fintervals) - 1)):
    plt.plot([classmarks[i], classmarks[i + 1]],
         [fintervals[i], fintervals[i + 1]], 'k--', lw=2)

plt.ylim(0, np.max(fintervals) + 1)
#plt.xlim(np.min(intervals) - 1, np.max(intervals) + 1)
plt.xlim(np.floor(np.min(intervals)), np.ceil(np.max(intervals)))
plt.grid(axis='y')
xticks = intervals
plt.xticks(xticks)
plt.show()
