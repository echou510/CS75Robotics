# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
pt.py
contour lines: z = temperature
"""

import matplotlib
import numpy as np
import matplotlib.pyplot as plt

matplotlib.rcParams['xtick.direction'] = 'out'
matplotlib.rcParams['ytick.direction'] = 'out'

a = 3.592  # atm l2 mol-2
b = 0.0427  # l mol-1
R = 0.08206  # atl l K-1 mol-1
#Tc = 31.1 ºC; Pc= 72.8 atm; Vc = 0.094 l mol-1
#Tc = 31.1
#Pc = 72.8
#Vc = 0.094
pointsnum = 1000
v = np.linspace(0.064, 0.18, pointsnum)  # x = V
p = np.linspace(0, 100.0, pointsnum)  # y = P
X, Y = np.meshgrid(v, p)
#Z = ((Y + (a / X ** 2)) * (X - b) / R) - 273.15
Z = ((Y + (a / X ** 2)) * (X - b) / R)
plt.figure()
CS = plt.contour(X, Y, Z, 25, linewidth=1.0, colors='k')
zc = CS.collections[0:8]
plt.setp(zc, linewidth=0.2, linestyle='dashed')
plt.clabel(CS, inline=1, fontsize=10, fmt='%4.0f')
#plt.title('Z = T (grados centigrados)')
plt.title('Z = T (Kelvin)')
plt.xlabel('V (litres)')
plt.ylabel('P (atm)')
plt.show()
