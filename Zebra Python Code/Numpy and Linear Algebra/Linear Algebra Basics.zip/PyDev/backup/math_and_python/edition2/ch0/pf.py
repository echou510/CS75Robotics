# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pf.py
'''

import numpy as np


def degreestogms(degrees):
    g = np.floor(degrees)
    m = np.floor((degrees - g) * 60)
    s = round((((degrees - g) * 60) - m) * 60)
    if s == 60:
        s = 0
        m += 1
    if m == 60:
        m = 0
        g += 1
    strgms = str(g) + 'º ' + str(m) + "' " + "%5.2f" % s + "''"
    return strgms

x = 6
y = 0.5
radian = 1
print radian, ' radian = ', np.rad2deg(radian), ' degrees'
print radian, ' radian = ' + degreestogms(np.rad2deg(radian))
degrees = 180
print degrees, ' degrees = ', np.deg2rad(degrees), ' radians'
print 'value of number e: ', np.e
print 'value of pi: ', np.pi
print 'e^x = ', np.power(np.e, x)
print 'x^y = ', np.power(x, y)
print 'log10(1024) = ' + "%8.5f" % np.log10(1024)
print 'ln(1024) = ' + "%8.5f" % np.log(1024)
print 'log2(1024) = ' + "%4.1f" % np.log2(1024)
print '6! = ', np.math.factorial(6)
alfaradianes = np.pi / 6
print ('alfa = ' + "%8.5f" % alfaradianes +
       ' radians = pi/' + str(x))
alfagrados = np.rad2deg(alfaradianes)
print ('sen(' + degreestogms(alfagrados) + ') = ' +
       "%8.5f" % np.sin(alfaradianes))
print ('cos(' + degreestogms(alfagrados) + ') = ' +
       "%8.5f" % np.cos(alfaradianes))
print ('tan(' + degreestogms(alfagrados) + ') = ' +
       "%8.5f" % np.tan(alfaradianes))
print ('asen(1) = ' + "%8.5f" % np.arcsin(1) +
       ' radians = ' + degreestogms(np.rad2deg(np.arcsin(1))))
print ('acos(1) = ' + "%8.5f" % np.arccos(1) +
       ' radians = ' + degreestogms(np.rad2deg(np.arccos(1))))
print ('atan(1) = ' + "%8.5f" % np.arctan(1) +
       ' radians = ' + degreestogms(np.rad2deg(np.arctan(1))))
print degreestogms(10.55)
