# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
ph.py
'''

letra = raw_input('Write a letter: ')
print letra

if (letra in 'aeiou'):
    print 'You wrote vowel: ', letra
elif letra in 'bcdfghjklmnñpqrstvwxyzBCDFGHJKLMNÑPQRSTVWXYZ':
    print 'You wrote consonant: ', letra
elif letra in '1234567890':
    print 'You wrote a number: ', letra
else:
    print letra, ' is not a letter nor a number'
