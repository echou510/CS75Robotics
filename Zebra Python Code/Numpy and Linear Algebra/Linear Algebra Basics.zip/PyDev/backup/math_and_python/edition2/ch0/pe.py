# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pe.py
'''

x = 1
z = 100 * x
print 'z = 100x = ', z
z += 2
print 'z increases by 2 units: z+=2 : ', z
z -= 52
print 'z decreases in 52 unidades: z-=2 : ', z
z *= 3
print 'z triples: z*=3 :', z
z /= 10
print 'z divided by 10: z/=10 : ', z
z %= 4
print 'remainder of dividing z by 4: z%=4 : ', z
