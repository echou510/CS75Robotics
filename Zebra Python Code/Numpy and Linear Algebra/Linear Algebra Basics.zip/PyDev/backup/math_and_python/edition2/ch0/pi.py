# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pi.py
'''

alist = ''
for i in range(1, 20):
    alist = alist + str(i) + ','
print alist
