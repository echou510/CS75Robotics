# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming © www.pysamples.com
pn.py
'''

import numpy as np

p1 = np.poly1d([1, 2, 3])
print 'p1 = '
print p1
print 'Value of the polynomial p1 for x=5:', np.polyval(p1, 5)
p2 = np.poly1d([1, -2, 1, 3, 2])
print 'p2 = '
print p2
print 'addition: '
print np.polyadd(p1, p2)
print 'subtraction p2-p1:'
print np.polysub(p2, p1)
print 'product: '
p = np.polymul(p1, p2)
print p
print 'polynomial division: p2/p1: '
quotient = np.polydiv(p2, p1)
print quotient
print 'quotient = '
print quotient[0]
print 'remainder = '
print quotient[1]
print 'p2 and its derivatives: '
for i in range(0, 6):
    print np.polyder(p2, m=i)
print 'integral of the first derivative of p2:'
#si no se especifica, la constante de integración es cero
p2int = np.polyint([4, -6, 2, 3])
print np.poly1d(p2int)
print 'binomials and product: '
polinomio = np.poly1d([0, 1])
for j in range(-2, 2):
    print np.poly1d([1, j])
    polinomio = np.polymul(polinomio, np.poly1d([1, j]))
print polinomio
print 'roots of the polynomial'
print np.sort(np.roots(polinomio))
