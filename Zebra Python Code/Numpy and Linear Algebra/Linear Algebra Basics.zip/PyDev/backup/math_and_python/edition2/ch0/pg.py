# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pg.py
'''

number = int(raw_input('Write an integer: '))

if (number % 2) == 0:
    print 'Number ', number, ' is even'
else:
    print 'Number ', number, ' is odd'
