# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
ps.py
'''

import csv
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np

d = []
gl = []
with open('densities.csv', 'rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
    i = 0
    for r in spamreader:
        if i > 0:
            d.append(int(r[0]))
            gl.append(int(r[1]))
        i += 1
print d
print gl

# linear interpolation
delta = 5  # distance between density data
density = 1068  # experimental value of density
i = 0
for datum in d:
    if datum < density:
        dant = datum
        j = i
    i += 1
print 'previous density: ', dant
glant = gl[j]
print 'previous sugars: ', glant
f = np.round(glant + ((density - dant) * (gl[j + 1] - gl[j]) / 5.0), 1)
print 'measured density: ', density
print 'linearly interpolated sugars: ', "%.1f" % f

#least squares adjust
print 'least squares adjust:'
slope, intercept, r_value, p_value, std_err = stats.linregress(d, gl)
print 'r^2: ', "%8.6f" % (r_value ** 2)
print ('straight line: y =  ' + "%6.2f" % slope + 'x + ' + "%6.2f" % intercept)
print 'measured density: ', density
f2 = np.round(slope * density + intercept, 1)
print ('sugars adjusted by least squares method: ' + "%.1f" % f2)

#graphic
f0 = slope * d[0] + intercept
fn = slope * d[-1] + intercept
plt.plot([d[0], d[-1]], [f0, fn], 'k-', lw=1.5)  # straight line adjust
plt.plot(d, gl, 'wo')
plt.xlim(1010, 1180)
plt.plot(density, f2, 'ro')
plt.plot([density, density], [0, f2], 'r--', lw=1.0)
plt.plot([1010, density], [f2, f2], 'r--', lw=1.0)
plt.xlabel('density (g/l)')
plt.ylabel('sugars (g/l)')
plt.show()
