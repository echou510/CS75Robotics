# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
pa.py
"""

import itertools

elements = ['a', 'e', 'i', 'o', 'u']
permutations = list(itertools.permutations(elements))
result = ''
for permutation in permutations:
    word = ''
    for i in range(0, 5):
        word += permutation[i]
    result += word + ', '
result = result[0:len(result) - 2]
print result
