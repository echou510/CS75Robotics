# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
pw.py
"""

import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
xticks = ['$a$', '$e$', '$i$', '$o$', '$u$',
          '$b$', '$c$', '$d$', '$f$', '$g$',
          '$h$', '$j$', '$k$', '$l$', '$m$',
          '$n$', '$p$', '$q$', '$r$', '$s$',
          '$t$', '$v$', '$w$', '$x$', '$y$', '$z$']
x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
     16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
defoe = [8.207, 12.293, 6.716, 7.945, 2.791, 1.546, 2.173, 4.647, 2.355,
         1.984, 6.728, 0.082, 0.68, 3.579, 2.773, 6.697, 1.537, 0.066,
         5.457, 5.777, 9.827, 1.096, 2.811, 0.115, 2.08, 0.038]
BBC_EWS = [7.314, 11.614, 7.228, 8.817, 3.072, 2.114, 2.718, 2.889, 2.055,
           2.679, 5.351, 0.184, 1.346, 4.202, 3.132, 6.565, 1.503, 0.02,
           5.633, 6.703, 8.692, 0.709, 2.436, 0.276, 2.731, 0.02]
hamlet = [7.381, 13.36, 6.492, 8.536, 3.759, 1.394, 1.933, 3.747, 2.034,
          1.83, 6.712, 0.001, 0.998, 4.458, 3.245, 6.222, 1.5, 0.159,
          5.844, 6.187, 8.875, 0.407, 2.363, 0.112, 2.411, 0.04]
maxwell = [7.232, 13.571, 7.944, 7.242, 2.595, 1.37, 4.537, 3.373, 3.349,
           1.287, 5.281, 0.136, 0.228, 3.713, 2.013, 6.813, 2.03, 0.37,
           5.755, 6.051, 10.61, 0.971, 1.496, 0.375, 1.513, 0.145]
finn = [8.409, 11.176, 6.439, 8.349, 3.181, 1.692, 1.844, 5.468, 1.778,
        2.457, 6.117, 0.27, 1.314, 4.012, 2.366, 7.505, 1.325, 0.043,
        4.537, 5.792, 9.663, 0.672, 3.076, 0.117, 2.356, 0.044]
print len(defoe), len(BBC_EWS), len(hamlet), len(maxwell), len(finn)
media = []
for i in range(0, 26):
    promedio = float("%7.3f" % ((defoe[i] + BBC_EWS[i] + hamlet[i] +
                     maxwell[i] + finn[i]) / 5))
    media.append(promedio)
print media

plt.plot(x, media, color='#F00707', lw=1.5)

p1, = plt.plot(x, defoe, 'yo')
p2, = plt.plot(x, BBC_EWS, 'k+')
p3, = plt.plot(x, hamlet, 'rD')
p4, = plt.plot(x, maxwell, 'b*')
p5, = plt.plot(x, finn, 'gs')
plt.ylabel('% of each letter')
plt.xlabel('letters')
plt.legend(('average', 'robinson', 'BBC', 'hamlet', 'maxwell', 'finn'),
           loc='upper center')
plt.grid(axis='x')
plt.xticks(x, xticks)
ax.set_xlim(-1, 26)
plt.show()
