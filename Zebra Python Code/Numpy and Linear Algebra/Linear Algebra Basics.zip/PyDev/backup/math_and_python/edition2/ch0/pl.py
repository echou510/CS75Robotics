# -*- coding: utf-8 -*-
'''
Mathematics and Python Programming
© www.pysamples.com
pl.py
'''
import numpy as np
import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
screen = tt.getscreen()
screen.colormode(255)
r = 221
g = 25
b = 127
tt.pencolor(r, g, b)
tt.speed('fastest')
degrees = 0
a = 5
tt.pensize(5)
for degrees in range(0, 360 * 5):
    radians = np.deg2rad(degrees)
    r = a * radians
    x = int(r * np.cos(radians))
    y = int(r * np.sin(radians))
    tt.setpos(x, y)
    tt.forward(r - 5)
    tt.pendown()
    tt.forward(5)
    tt.penup()
    tt.left(1)
tt.hideturtle()
