# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p3a.py
"""

import numpy as np


def arithmetical(x1, n, d):
    x = np.zeros(n + 1, int)
    x[1] = x1
    suma = x[1]
    sequence = str(x[1]) + ', '
    for i in range(2, n + 1):
        x[i] = x[i - 1] + d
        sequence = sequence + str(x[i]) + ', '
        suma = suma + x[i]
    sequence = sequence[0:len(sequence) - 2]
    print 'x1 =', x[1], '; d =', d, '; n =', n
    print ('The ' + str(n) + '  first terms of the sequence:')
    print sequence
    sn = (x[1] + x[n]) * n / 2
    print
    print ('S(' + str(n) + ') : (' + str(x[1]) +
           ' + ' + str(x[n]) + ')' + str(n) + '/ 2 = ' + str(sn))
    print 'S(', n, ')  added one by one:', suma
    print
    print ('Check: xm + xn = ' + 'xk+ xl si m+n = k+l: ')
    m = 1
    ene = np.random.random_integers(2, n)
    k = np.random.random_integers(2, ene)
    l = m + ene - k
    print 'm + n = k + l:'
    print m, ' + ', ene, ' = ', k, ' + ', l, ': '
    print (str(x[m]) + ' + ' + str(x[ene]) +
           ' = ' + str(x[k]) + ' + ' + str(x[l]))
    print x[m] + x[ene], ' = ', x[k] + x[l]

arithmetical(10, 100, -3)  # arithmetical(x1,n,d)
