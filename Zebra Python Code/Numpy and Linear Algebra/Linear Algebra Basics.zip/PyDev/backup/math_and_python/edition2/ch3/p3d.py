# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p3d.py
"""

import numpy as np

f = []
f.append(0)
f.append(1)
terminos = 10  # numero de terminos de Fibonacci, >0
i = 2
while i <= terminos:
    termino = f[i - 1] + f[i - 2]
    f.append(termino)
    i += 1
j = 1
while j <= terminos:
    print str(j) + ': ' + str(f[j]) + ' = ' + np.binary_repr(f[j])
    j += 1
