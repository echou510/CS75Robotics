# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p3b.py
"""

import numpy as np


def geometric(x1, n, r):
    x = np.zeros(n + 1, float)
    x[1] = x1
    suma = x[1]
    sequence = str(x[1]) + ', '
    #print str(x1)
    for i in range(2, n + 1):
        x[i] = x[i - 1] * r
        #print "%.4f" % x[i]
        sequence = sequence + "%.8f" % x[i] + ', '
        suma = suma + x[i]
    sequence = sequence[0:len(sequence) - 2]
    print ('x1 =' + str(x[1]) + '; r =' +
           "%.2f" % r + '; n =' + str(n))
    print ('The ' + str(n) + ' first terms of the sequence:')
    print sequence
    sn = x[1] * (1 - r ** n) / (1 - r)
    print
    strsuma = ('S(' + str(n) + ') : ' +
               str(x1) + '(1 -  ' + "%.2f" % r)
    strsuma = (strsuma + '^' + str(n) + ') / (1-' + "%.2f" % r)
    strsuma = strsuma + ') = ' + "%.8f" % sn
    print strsuma
    print ('S(' + str(n) + ') added one by one:' + "%.8f" % suma)

geometric(100.0, 20, 0.5)  # geometric(x1,n,r)
