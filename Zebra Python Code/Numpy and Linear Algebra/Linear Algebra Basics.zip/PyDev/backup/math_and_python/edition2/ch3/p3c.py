# -*- coding: utf-8 -*-
"""
Mathematics and Python Programming
© www.pysamples.com
p3c.py
"""

dictionaryiter = {1: 1, 2: 1}


def fibiter(n):
    i = 3
    while i <= n:
        dictionaryiter[i] = (dictionaryiter[i - 1] +
                              dictionaryiter[i - 2])
        i += 1

fibiter(100)


def comma(n):  # http://pp.com.mx/python/doc/ejemplos.html
    s = str(n)
    pos = len(s)
    while pos > 3:
        pos = pos - 3
        s = s[:pos] + ',' + s[pos:]
    return s

for i, value in dictionaryiter.iteritems():
    term = comma(value)
    print '%3d %28s' % (i, term)
