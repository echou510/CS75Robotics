# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9b.py
Calculo de primitivas
"""

import sympy as sy

x = sy.symbols('x')
sy.init_printing(use_unicode=True)

#R = 1.0
print 'f(x) = sin(x) ** 2'
#print 'f(x) = (6 - x) / ((x - 3) * (2 * x + 5))'
#print 'f(x) = 1 / (x * (log(x)) ** 3)'
#print 'f(x) = (x + 2) * sin(x ** 2 + 4 * x + 6)'
#print 'f(x) = (1.0 - x ** 2) ** (1 / 2)'
#print 'f(x) = x / sqrt(1 - 6 * x ** 4)'
#integral = sy.integrate(x / sy.sqrt(1 - 6 * x ** 4))
#integral = sy.integrate(sy.cos(x))
#integral = sy.integrate(sy.sqrt(1 - x ** 2), (x, 0, 1))
#integral = sy.integrate((x + 2) * sy.sin(x ** 2 + 4 * x + 6))
#integral = sy.integrate(1 / (x * (sy.log(x)) ** 3))
integral = sy.simplify(sy.integrate((sy.sin(x)) ** 2))
#integral = sy.integrate((6 - x) / ((x - 3) * (2 * x + 5)))
print 'F(x) = ', integral

'''
Fb = float(integral.subs(x, b).evalf(6))
Fa = float(integral.subs(x, a).evalf(6))
print ('I = ' + "%6.4f" % Fb + ' - ' +
        "%6.4f" % Fa + ' = ' + str(Fb - Fa))
'''
