# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9h.py
teorema fundamental del calculo integral
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

x = sy.symbols('x')
sy.init_printing(use_unicode=True)
a = -4.0
b = 2.0
#sympy
funcion = 10 * sy.exp(x / 2)
print 'f(x) = '
print funcion
I = sy.integrate(funcion)
print 'F(x) = '
print I
Fb = float(I.subs(x, b).evalf(3))
Fa = float(I.subs(x, a).evalf(3))
print 'F(b) = F(', b, ') = ', Fb
print 'F(a) = F(', a, ') = ', Fa
print 'F(b) - F(a) = ', Fb - Fa

#grafica
numpuntos = 100
x = np.linspace(a, b, numpuntos)
f = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    f[i] = 10 * np.exp(x[i] / 2)
plt.plot(x, f, 'k-', lw=2.5)
plt.fill_between(x, f, 0, alpha=1, color='#BDD0D7')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=0.6)
plt.axvline(color='black', lw=0.6)
plt.xlim(a, b)
plt.show()
