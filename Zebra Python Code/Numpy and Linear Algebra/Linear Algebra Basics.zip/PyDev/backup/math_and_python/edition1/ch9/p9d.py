# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9d.py
representa funcion y area
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

x = sy.symbols('x')
sy.init_printing(use_unicode=True)


a = -5.0
b = 5.0
funcion = sy.simplify(x ** 3 - 13 * x + 12)  # el polinomio a integrar
npfuncion = [1, 0, -13, 12]  # coeficientes del polinomio


'''
a = -1.25
b = 0.7
funcion = sy.simplify(x ** 5 + 2 * x ** 4 +
                      (x ** 3) / 4 - (3 * x ** 2) / 4)
npfuncion = [1, 2, 0.25, -0.75, 0, 0]
'''

#sympy
print 'f(x) = '
print funcion
I = sy.integrate(funcion)
print 'F(x) = '
print I
print

#numpy
raices = np.round(np.sort(np.roots(npfuncion)), 2)
print 'puntos de corte con el eje X: ', raices
extremos = [a]
i = 0
while i < len(raices):
    #print raices[i], extremos[i]
    if (raices[i] > extremos[i] and raices[i] < b):
        extremos.append(raices[i])
    else:
        extremos.append(extremos[i])
    #print extremos
    i += 1
extremos.append(b)
#print 'extremos de los intervalos de integracion: ', extremos
extremos = np.unique(extremos)
print 'extremos de los intervalos de integracion: ', extremos
areas = np.zeros(len(extremos) - 1, float)
for i in range(0, len(extremos) - 1):
    areas[i] = sy.integrate(funcion, (x, extremos[i],
                            extremos[i + 1]))
print 'areas de los intervalos: '
print areas
areas = np.absolute(areas)
print 'areas de los intervalos en valor absoluto: '
print areas
print 'Area total = ', np.sum(areas)

#grafica
numpuntos = 200
x = np.linspace(a, b, numpuntos)
f = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    f[i] = np.polyval(npfuncion, x[i])
plt.plot(x, f, 'k-', lw=2)
plt.fill_between(x, f, 0, alpha=0.8, color='#BDD0D7')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.xlim(a, b)
plt.legend(('$f(x)$',), loc='best')
plt.show()
