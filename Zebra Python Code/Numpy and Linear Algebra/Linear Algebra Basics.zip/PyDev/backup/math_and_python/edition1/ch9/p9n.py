# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9n.py
representa el area entre la curva de
la clepsidra y del eje Y
y calcula el volumen de revolucion
alrededor del eje Y
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

#z = sy.symbols('z')
sy.init_printing(use_unicode=True)

c, x, H = sy.symbols('c, x, H')
#y = c * x ** 4

integrando1 = 2 * sy.pi * ( x * H)
V1 = sy.integrate(integrando1, x)
integrando = 2 * sy.pi * ( x * c * x ** 4)
V2 = sy.integrate(integrando, x)
V = V1 - V2
#V = 2 * sy.pi * sy.integrate(x * sy.sin(x), x)  # prueba senx coquillat p285
print 'V = ', V

S = sy.integrate(H - c * x ** 4, x)
print 'Area entre la curva y el eje Y = ', S

numpuntos = 200
a = 0
b = 14.6266250136  # el radio máximo R de la clepsidra en cm
cte = 436.971875791 * (1.0 / 1e6)  # en cm-3
x = np.linspace(a, b, numpuntos)
y = cte * x ** 4
plt.plot(x, y, color='k', lw=2)
ymax = np.max(y)
plt.fill_between(x, ymax, 0, alpha=1.0, color='#F8C31C')
plt.fill_between(x, y, 0, alpha=1.0, color='white')
plt.axis('equal')
plt.ylabel('y')
plt.xlabel('x')
plt.grid(True)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.plot([a, b], [ymax, ymax], 'k--', lw=1.0)
#plt.plot([b, b], [0, b ** 2], 'k-', lw=1.5)
#plt.xlim(0, 2.5)
plt.ylim(0, 1.1 * ymax)
plt.show()
