# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9k.py
representa superficie de revolucion usando mayavi
"""

import numpy as np
# crea los datos
dt, dv = np.pi / 180.0, np.pi / 180.0
k = 1.5
[t, v] = np.mgrid[0:2 * np.pi + dt * 1.5:dt, 0:2 * np.pi + dv * 1.5:dv]
x = k * (t - np.sin(t))
y = k * (1 - np.cos(t)) * np.cos(v)
z = k * (1 - np.cos(t)) * np.sin(v)

# representa con mayavi
from mayavi import mlab
s = mlab.mesh(x, y, z)
mlab.show()
