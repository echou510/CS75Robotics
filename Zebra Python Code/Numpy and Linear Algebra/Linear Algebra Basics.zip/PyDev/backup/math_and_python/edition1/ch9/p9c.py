# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9c.py
representa funcion y area
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

z = sy.symbols('z')
sy.init_printing(use_unicode=True)

print 'f(z) = (1.0 - z ** 2) ** (1 / 2)'
integral = sy.integrate(sy.sqrt(1 - z ** 2), (z, 0, 1))
print 'F(z) = ', integral

numpuntos = 200
x = np.linspace(0.0, 1.0, numpuntos)
y = np.sqrt(1 - x ** 2)
plt.plot(x, y, color='k', lw=2.0)
plt.fill_between(x, y, 0, alpha=1.0, color='#BDD0D7')
plt.ylabel('y')
plt.xlabel('x')
plt.axis('equal')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.xlim(0, 1.05)
plt.ylim(0, 1.05)
plt.show()
