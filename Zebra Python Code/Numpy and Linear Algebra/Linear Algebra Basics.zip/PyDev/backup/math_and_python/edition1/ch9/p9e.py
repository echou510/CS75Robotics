# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9e.py
area entre dos curvas
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

z = sy.symbols('z')
sy.init_printing(use_unicode=True)
a = sy.atan(0.5)
b = sy.pi + a
#sympy
funcion = 2 * sy.sin(z) - sy.cos(z)
print 'f(x) = '
print funcion
I = sy.integrate(funcion)
print 'F(x) = '
print I

Area = sy.integrate(funcion, (z, a, b))
print 'Area entre las dos curvas:'
print 'A = ', "%6.3f" % Area

#grafica
numpuntos = 500
a = (180 * np.arctan(0.5) / np.pi)
b = a + 180
fa = 2 * np.sin(np.arctan(0.5))
fb = 2 * np.sin(np.pi + np.arctan(0.5))
print 'a = arctan(1/2) = ', "%6.3f" % np.arctan(0.5), ' rad = ', "%6.2f" % a
print 'b = a + 180 = ', "%6.2f" % b
Fb = -np.sin(np.deg2rad(b)) - 2 * np.cos(np.deg2rad(b))
Fa = -np.sin(np.deg2rad(a)) - 2 * np.cos(np.deg2rad(a))
print 'F(b) = ', "%6.3f" % Fb
print 'F(a) = ', "%6.3f" % Fa
print 'F(b) - F(a) = ', "%6.3f" % (Fb - Fa)
x = np.linspace(0, 270, numpuntos)
f = np.zeros(numpuntos, float)
g = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    f[i] = 2 * np.sin(np.deg2rad(x[i]))
    g[i] = np.cos(np.deg2rad(x[i]))

#grafica 1
plt.fill_between(x, f, g, where=(x >= a), color='#BDD0D7', alpha=0.5)
plt.fill_between(x, f, g, where=(x > b), color='#FFFFFF')
plt.plot(x, f, 'b-', lw=2)
plt.plot(x, g, 'r-', lw=2)

'''
#grafica 2
plt.fill_between(x, f, 0, where=(x >= a), color='blue', alpha=1.0)
plt.fill_between(x, f, 0, where=(x > b), color='#FFFFFF')
plt.fill_between(x, g, 0, where=(x >= a), color='#F8EF01', alpha=0.6)
plt.fill_between(x, g, 0, where=(x > b), color='#FFFFFF')
plt.plot(x, f, 'k-', lw=2)
plt.plot(x, g, 'k--', lw=2)
'''

plt.plot([a, a], [0, fa], 'k--', lw=1)
plt.plot([b, b], [0, fb], 'k--', lw=1)
plt.text(a, -0.2, 'a', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.text(b, 0.1, 'b', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.legend(('f(x)=2senx', 'g(x)=cosx',), loc='best')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.xlim(0, 270)
plt.ylim(-2, 2.5)
plt.show()
