# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9i.py
area de una curva en coordenadas polares
"""

import matplotlib
import numpy as np
import sympy as sy
from matplotlib.pyplot import figure, show, rc, grid

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

z, k = sy.symbols('z, k')
sy.init_printing(use_unicode=True)
a = 2 * sy.pi
b = 4 * sy.pi
#sympy
funcion = k * z
print 'f(x) = '
print funcion
integrando = sy.Pow(funcion, 2)
print 'F(x) = '
print sy.simplify((sy.integrate(integrando, (z))) / 2)
#print integrando
print
Area = (sy.integrate(integrando, (z, a, b))) / 2
print 'Area[', a, ', ', b, '] = ', Area


#grafica
r = []
theta = []
x = []
y = []
r.append(0.0)
theta.append(0.0)

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

# figura
width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  hace un cuadrado
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True, axisbg='#ffffff')
angulo = 0
grid(False)
while angulo <= 6 * np.pi:
    angulo += np.pi / 36
    theta.append(angulo)
    radio = 5.0 * angulo
    r.append(radio)
    x.append(radio * np.cos(angulo))
    y.append(radio * np.sin(angulo))
ax.plot(theta, r, color='#1821EE', lw=1.5)
show()
