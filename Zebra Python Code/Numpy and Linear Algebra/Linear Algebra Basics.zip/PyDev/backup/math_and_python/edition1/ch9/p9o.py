# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9o.py
representa superficie de revolucion de la clepsidra
"""

import numpy as np

# crea los datos
#constantes:
k = 0.6  # constante que depende del fluido, para el agua, 0.6
g = 9.81  # aceleracion de la gravedad

#datos:
#tiempo que debe tardar en vaciarse, en segundos
segundos = 3600
print 'tiempo en vaciarse: ', segundos, ' segundos'
#altura en metros
H = 0.2
print 'altura de la clepsidra: ', H * 1000, ' mm'
# radio del orificio de salida, en mm
rs = 1.0


#calculos:
s = np.pi * (rs * 1e-3) ** 2  # area del orificio de salida circular
print 'diámetro del orificio de salida: ', 2 * rs, 'mm'
a = H / segundos  # velocidad de descenso del nivel en m/s
print ('el nivel del agua desciende a velocidad constante de ' +
       str(np.round(a * 60 * 1000, 0)) + ' mm / minuto')
c = (np.pi ** 2 * a ** 2) / (2 * g * k ** 2 * s ** 2)
#c = a ** 2 / ( 2 * g * (rs * 1e-3) ** 4)
print 'c = ', c
#h = c r ** 4
R = np.power(H / c, 0.25)
print 'radio de la clepsidra: ', 1000 * R, ' mm'
V = np.pi * H * R ** 2 - (np.pi * c * R ** 6) / 3
print ('Volumen de la clepsidra: ' + "%10.6f" % V + ' m3 = ' +
       "%6.3f" % (V * 1000) + ' litros')
'''
volumen por secciones:
area de una seccion = pi * r ** 2
y = c * r ** 4
area de una seccion = pi * (y / c) ** (2 / 4) = (pi / c ** (1 / 2)) * y ** (1 / 2)
integrando entre y=0 y h:
V = (pi / c ** (1 / 2)) * (2 / 3) * h ** (3 / 2)
'''
Vsec = (np.pi / c ** 0.5) * (2.0 / 3) * H ** (1.5)
print ('Volumen calculado por secciones: ' +
       "%10.6f" % Vsec + ' m3 = ' +
       "%6.3f" % (Vsec * 1000) + ' litros')
print
print ('Volumen de un cono del mismo radio y altura: ' +
       "%6.3f" % ((1000 * H * np.pi / 3.0) * R ** 2) + ' litros')
# pi c h(6/4) c(-6/4) / 3 = pi c(-1/2) h(3/2) / 3 para la clepsidra
# pi h h(2/4) c(-2/4) / 3 = pi c(-1/2) h(3/2) / 3 para el cono
print ('Volumen del cilindro del mismo radio y altura: ' +
       "%6.3f" % (1000 * H * np.pi * R ** 2) + ' litros')
#print ('Area entre la curva y el eje Y = ', 0.8 * c * (h / c) ** 1.25)
print ('Area entre la curva y el eje Y = ' +
       "%7.1f" % ((H * R - ((c * R ** 5) / 5)) * 1e4) + ' cm2')
print 'Relación entre el cono, la clepsidra y el cilindro:'
print 'V clepsidra= ', Vsec / ((H * np.pi / 3.0) * R ** 2), 'Vcono'
print 'V cilindro = ', 3.0, 'Vcono'

#trazado con matplotlib
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
dr = 1e-3
dtheta = 0.01
[r, theta] = np.mgrid[0:R + dr:dr,
                      0:2 * np.pi + dtheta * 1.5:dtheta]
x = r * np.cos(theta)
y = r * np.sin(theta)
#clepsidra
z = c * ((x ** 2 + y ** 2)) ** 2
ax.plot_wireframe(x, y, z, rstride=15, cstride=15, color='blue')
ax.plot_wireframe(x, y, z, rstride=15, cstride=15, color='blue')
#cono
zcono = (H / R) * np.sqrt(x ** 2 + y ** 2)
ax.plot_wireframe(x, y, zcono, rstride=15, cstride=15, color='red')

#cilindro x**2 + y**2 = R ** 2
xcil = np.linspace(-R, R, 200)
zcil = np.linspace(0, H, 200)
X, Z = np.meshgrid(xcil, zcil)
Y = np.sqrt(R ** 2 - X ** 2)
ax.plot_wireframe(X, Y, Z, rstride=40, cstride=40, color='green')
ax.plot_wireframe(X, -Y, Z, rstride=40, cstride=40, color='green')

plt.xlabel('x')
plt.ylabel('y')
plt.show()


#trazado de la clepsidra con mayavi:
#dr = 1e-3
#dtheta = 0.01
#[r, theta] = np.mgrid[0:radiomax + dr:dr,
#                      0:2 * np.pi + dtheta * 1.5:dtheta]
#x = r * np.cos(theta)
#y = r * np.sin(theta)
z = c * r ** 4
from mayavi import mlab
s = mlab.mesh(x, y, z)
mlab.show()
