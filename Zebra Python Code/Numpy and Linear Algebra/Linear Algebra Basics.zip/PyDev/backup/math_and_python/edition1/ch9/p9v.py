# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9v.py
integracion numerica: parabolas
"""

import numpy as np
import matplotlib.pyplot as plt

x = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
y = [0.0, 2.151, 2.646, 2.806, 2.828, 2.85, 3.0, 3.373, 4.0, 4.861, 5.916, 7.133, 8.485]
print 'x = ', x
print 'y = ', y
n = len(x)
print n, ' puntos; ', (n - 1) / 2, ' intervalos'

#parabola
A5 = 0
for i in range(0, n - 2, 2):
    delta = x[i + 2] - x[i]
    A5 += (y[i] + 4 * y[i + 1] + y[i + 2]) * delta / 6
print 'A (parabola) = ', "%8.3f" % A5

#parabola entre cada dos puntos y que pasa por su punto medio


def trazaparabola(j):
    A = np.array([[x[j] ** 2, x[j], 1.0],
                  [x[j + 1] ** 2, x[j + 1], 1.0],
                  [x[j + 2] ** 2, x[j + 2], 1.0]])
    #print A
    detA = np.linalg.det(A)
    if detA == 0:
        #los tres puntos estan alineados: trazar trapecio'
        xrecta = [x[j], x[j + 2]]
        yrecta = [y[j], y[j + 2]]
        plt.plot(xrecta, yrecta, 'k-', lw=1.0)
        plt.fill_between(xrecta, yrecta, 0,
			 alpha=1, color='#BDD0D7')
    else:
        B = np.array([y[j], y[j + 1], y[j + 2]])
        abc = np.linalg.solve(A, B)
        #calcula 10 puntos de la parabola
        xintervalo = np.linspace(x[j], x[j + 2], 10)
        yintervalo = np.zeros(10, float)
        for k in range(0, 10):
            yintervalo[k] = (abc[0] * xintervalo[k] ** 2 +
                             abc[1] * xintervalo[k] + abc[2])
        plt.plot(xintervalo, yintervalo, 'k-', lw=1.0)
        plt.fill_between(xintervalo, yintervalo, 0, alpha=1, color='#BDD0D7')
        plt.plot([x[j], x[j]], [0, y[j]], 'k-', lw=0.7)

for intervalo in range(0, n - 2, 2):
    trazaparabola(intervalo)

for i in range(0, n - 1):
    plt.plot([x[i], x[i + 1]], [y[i], y[i + 1]], 'k--', lw=0.7)
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)
plt.show()
