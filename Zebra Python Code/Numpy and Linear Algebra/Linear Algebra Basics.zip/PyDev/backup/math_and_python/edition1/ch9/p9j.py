# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9j.py
longitud del arco de la cicloide
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

t1 = 0.0
t2 = 2 * np.pi
print 't1 = ' + "%5.3f" % t1
print 't2 = ' + "%5.3f" % t2 + ' = 2 pi'

k = 1.5  # la constante es k para numpy y c para sympy
print 'k = ', k

z, c = sy.symbols('z, c')
sy.init_printing(use_unicode=True)

print 'radicando = c^2 (1-cosz)^2 + (senz)^2 = '
radicando = sy.simplify((c ** 2) *
                        ((1 - sy.cos(z)) ** 2 + (sy.sin(z) ** 2)))
print ' = ', radicando
print ' = 2 * c**2 * (1-cos(z) = 4 * c**2 * [sen(z/2)] ** 2'
integral = sy.integrate(2 * c * sy.sin(z / 2), (z, 0, 2 * sy.pi))
print 'L = ', integral
print 'Si c = ', k, ' entonces L = ', 8 * k


def f(t):
    fv = k * (t - np.sin(t))
    return fv


def g(t):
    gv = k * (1 - np.cos(t))
    return gv

print 'a = ' + "%5.3f" % f(t1)
print 'b = ' + "%5.3f" % f(t2)
numpuntos = 360
tinicial = 0
tfinal = numpuntos
x = np.zeros(numpuntos, float)
y = np.zeros(numpuntos, float)
t = tinicial
while t < tfinal:
    radianes = np.deg2rad(t)
    x[t] = f(radianes)
    y[t] = g(radianes)
    t += 1
plt.plot(x, y, 'b-', lw=2)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.axis([-0.5, 10, -0.5, 10])
#plt.axis('equal')
plt.ylabel('y')
plt.xlabel('x')
plt.show()
