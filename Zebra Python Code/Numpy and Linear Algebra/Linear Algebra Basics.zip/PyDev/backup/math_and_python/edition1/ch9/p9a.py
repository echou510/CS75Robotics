# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9a.py
suma de Riemann
"""

import numpy as np
import sympy as sy
import matplotlib.pyplot as plt

x = sy.symbols('x')
sy.init_printing(use_unicode=True)

a = 2.0
b = 10.0
#delta = 2.5
delta = 1.0
#delta = 0.25
z = [a]

print 'f(x) = 3 * x ** 2 + 1'
print 'Integral: '
integral = sy.integrate(3 * x ** 2 + 1)
Fb = float(integral.subs(x, b).evalf(6))
Fa = float(integral.subs(x, a).evalf(6))
print integral
print ('I = ' + "%6.4f" % Fb + ' - ' +
       "%6.4f" % Fa + ' = ' + str(Fb - Fa))
print

j = 1
i = a
ancho = []
while i < b:
    amplitud = np.random.rand() * delta
    z.append(z[j - 1] + amplitud)
    if z[j] > b:
        z[j] = b
    ancho.append(z[j] - z[j - 1])
    i = z[j]
    j += 1
z = np.around(z, 6)
n = len(z) - 1
print '[a, b] = [', a, ', ', b, ']'
print 'delta = ', delta
print 'numero de intervalos: ', n
ancho.append(0)
ancho = np.around(ancho, 6)
norma = np.max(ancho)
print 'norma de la partición = ', norma


def f(t):
    fx = (3 * t ** 2 + 1)
    return fx


print 'Suma de Riemann:'
xi = np.zeros(n + 1, float)
y = np.zeros(n + 1, float)
suma = 0
for i in range(1, n + 1):
    xi[i] = z[i - 1] + np.random.rand() * (z[i] - z[i - 1])
    #print i, z[i - 1], z[i], 'anchura:' , z[i] - z[i-1], xi[i]
    '''if xi[i] > b:
        xi[i] = b'''
    y[i] = f(xi[i])
    suma += (z[i] - z[i - 1]) * y[i]
print 'extremos de los intervalos:'
print z
print 'amplitud de los intervalos:'
print ancho[0: -1]
print 'amplitud total: ', ancho.sum()
print 'valores de xi dentro de cada intervalo:'
print xi[1: len(xi)]
#print y
print 'I = ', suma


#grafica
alturas = np.zeros(n, float)
alturas = np.delete(y, 0)
alturas = np.append(alturas, 0)
#print alturas
fig = plt.figure()
ax = plt.subplot(111)
ax.bar(z, alturas,
       width=ancho, alpha=0.4, color='#3E9ECB')
for k in range(1, len(xi)):
    ax.plot(xi[k], 0, 'yo')
#dibuja la funcion
puntosgrafica = 200
funcion = np.zeros(puntosgrafica + 1, float)
equis = np.zeros(puntosgrafica + 1, float)
incremento = (b - a) / puntosgrafica
for i in range(0, puntosgrafica + 1):
    equis[i] = a + i * incremento
    funcion[i] = f(equis[i])
plt.plot(equis, funcion, 'r-', lw=3)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
