# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p9p.py
representa funcion y area = trabajo
"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sy

x, k = sy.symbols('x, k')
sy.init_printing(use_unicode=True)

# unidades en SI
'''
# fuerza constante f=k
a = 1
b = 2
k = 10
f = k
# muelle F=-kx
a = 15e-2  # 10 cm
b = 2e-2  # 2 cm
k = 400
f = -k * x
# expansion isoterma
a = 1.0e-3  # 1 litro
b = 5.0e-3  # 5 litros
n = 0.01  # 0.01 mol
R = 8.314  # J/K.mol
T = 298.0
f = n * R * T / x  # aqui x= V
'''
# expansion adiabatica
a = 1.0e-3  # 1 litro = V1
b = 5.0e-3  # 5 litros
P1 = 0.25 * 1.013 * 1e5  # 0.25 atmosferas
gamma = 1.66
K = P1 * (a ** gamma)
f = K * (x ** (-1 * gamma))

print 'f(x) =', f
integral = sy.integrate(f, x)
print 'W = ', integral, ' entre ', a, ' y ', b
#print 'W = (', sy.N(integral, b), ') - (', sy.N(integral, a), ')'
area = sy.integrate(f, (x, a, b))
print 'W = ', "%7.3f" % area

#grafica
numpuntos = 200
equis = np.linspace(a, b, numpuntos)
y = np.zeros(numpuntos, float)


def f(z):
    # fuerza constante f=k
    #fx = k
    # muelle F=-kx
    #fx = -k * z
    # expansion isoterma
    #fx = n * R * T / z
    #expansion adiabatica
    fx = K * (z ** (-1 * gamma))
    return fx
for i in range(0, numpuntos):
    y[i] = f(equis[i])

plt.plot(equis, y, color='k', lw=2)
plt.fill_between(equis, y, 0, alpha=1.0, color='#A1BCC3')
#plt.axis('equal')
plt.ylabel('$P \quad (Nm^-2)$')
plt.xlabel('$V \quad (m^3)$')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.plot([a, a], [0, f(a)], 'k--', lw=1)
plt.plot([b, b], [0, f(b)], 'k--', lw=1)
#plt.xlim(0.9 * np.min(equis), 1.1 * np.max(equis))
plt.xlim(0, 1.1 * np.max(equis))
plt.ylim(0, np.max(y))
plt.show()
