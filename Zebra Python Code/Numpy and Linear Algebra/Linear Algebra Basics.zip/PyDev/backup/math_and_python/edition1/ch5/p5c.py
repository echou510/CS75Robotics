# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5c.py
2º teorema de Bolzano-Cauchy
para un C dado halla c tal que f(c) = C
f(a) y f(b) deben tener signos diferentes
"""

import scipy.optimize as optimize
import numpy as np

C = 1.0
#C = 0.0
a = 5
b = 8
print 'f(x) = x * sin(x) / 5'
print 'halla el punto c en el intervalo [', a, ', ', b, ']'
print 'tal que f(c) = ', C


def funcion(x):
    return (x * np.sin(x) / 5) - C
    #return x ** 2 - 25  # a=0 b=15
    #return np.cos(x) ** 2 + 6 - x

signo = np.sign(funcion(a)) * np.sign(funcion(b))
if signo < 0:
    c = optimize.bisect(funcion, a, b, xtol=1e-6)
    print 'c = ' + "%7.5f" % c
    print 'f(c) = ' + "%7.5f" % (funcion(c) + C)
else:
    print 'f(a) y f(b) deben tener signos diferentes'
