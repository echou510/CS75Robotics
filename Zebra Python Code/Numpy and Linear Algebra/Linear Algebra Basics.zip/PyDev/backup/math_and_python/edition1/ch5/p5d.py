# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5d.py
y = (x^2-9)/(x-1)
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 100
asintota = 1
epsilon = 0.1
x1 = np.linspace(-6, asintota - epsilon, numpuntos)
y1 = np.zeros(numpuntos, float)
x2 = np.linspace(asintota + epsilon, 6, numpuntos)
y2 = np.zeros(numpuntos, float)
#f(x) = (x^2-9)/(x-1)
# asintotas: y=1; y=x+1
y1[0] = (x1[0] ** 2 - 9) / (x1[0] - 1)
y2[0] = (x2[0] ** 2 - 9) / (x2[0] - 1)
for i in range(1, numpuntos):
    y1[i] = (x1[i] ** 2 - 9) / (x1[i] - 1)
    y2[i] = (x2[i] ** 2 - 9) / (x2[i] - 1)
plt.plot(x1, y1, 'b', lw=2)
plt.plot(x2, y2, 'b', lw=2)
plt.plot([1, 1], [-80, 80], 'k--', lw=0.5)
plt.plot([-6, 6], [-5, 7], 'k--', lw=0.5)
plt.text(3, 40, 'y = (x^2-9)/(x-1)', horizontalalignment='center')
plt.text(-0.25, 10, '3', horizontalalignment='center')
plt.text(0.75, -10, '1', horizontalalignment='center')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()
