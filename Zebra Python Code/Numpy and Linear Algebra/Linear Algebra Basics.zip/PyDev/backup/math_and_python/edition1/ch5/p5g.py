# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5g.py
sen(x)/x
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 100
x = np.linspace(0.001, 1.5, numpuntos)
y = np.zeros(numpuntos, float)
sen = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    sen[i] = np.sin(x[i])
    y[i] = sen[i] / x[i]
    #print x[i], y[i]
fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1, aspect='equal')
ax.autoscale_view(tight=True)
ax.set_ylim(0, 1.5)
ax.set_xlim((0, 1.5))
p1, = plt.plot(x, x, 'b--', lw=1,
               label='y = x')
p2, = plt.plot(x, sen, 'g', lw=1,
               label='y = senx')
p3, = plt.plot(x, y, 'r', lw=3,
               label='y = senx/x')
plt.legend(('y = x', 'y = senx',
            'y = senx/x'), loc='best')
plt.ylabel('y')
plt.xlabel('x')
plt.show()
