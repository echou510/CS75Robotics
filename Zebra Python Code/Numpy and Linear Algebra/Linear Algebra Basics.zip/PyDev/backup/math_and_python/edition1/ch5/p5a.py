# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5a.py
continuidad
"""

import numpy as np

x0 = 1
epsilon = 1e-3  # valor deseado de |f(x)-f(x0)|
delta = abs(epsilon / 2 * x0)
print 'x0 = ', x0, '; epsilon deseado: ', epsilon, ' delta = ', delta
print 'Los puntos x que están a una distancia de x0 menor que ', delta
print 'cumplen que |f(x)-f(x0)|<', delta, ' y aparecen marcados con #'
print
numpuntos = 20
x = np.linspace(x0 - 1.5 * delta,
                x0 + 1.5 * delta,
                numpuntos + 1)
print ('   x' + '        ' + '|x - x0|' +
       ' ' + ' |f(x) - f(x0)|')
print '_________________________________'
for i in range(0, numpuntos + 1):
    difX = abs(x[i] - x0)
    difY = abs(x[i] ** 2 - x0 ** 2)
    if difY < epsilon:
        marca = '#'
    else:
        marca = ''
    print ("%8.5f" % x[i] + '    ' +
           "%8.5f" % difX + '    ' +
           "%8.5f" % difY + marca)
