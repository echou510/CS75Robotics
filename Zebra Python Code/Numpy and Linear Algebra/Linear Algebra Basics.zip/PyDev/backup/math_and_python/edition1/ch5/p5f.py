# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5f.py
función continua a trozos y = ent(x)
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 300
x = np.linspace(-4.9, 4.9, numpuntos)
y = np.zeros(numpuntos, int)
#ceros = np.zeros(numpuntos, int)
discontinuidades = []
y[0] = np.trunc(x[0])
for i in range(1, numpuntos):
    y[i] = np.trunc(x[i])
    if y[i] != y[i - 1]:
        discontinuidades.append(i)
print y
print ('discontinuidades:' + str(discontinuidades))
j = 0
inicial = 0
final = 0
while (j < (numpuntos - 1)):
    if (y[j + 1] != y[j]):
        final = j
        print ('de ' + str(inicial) + ' a ' + str(final) + ': y = ' + str(y[j]))
        plt.plot([x[inicial], x[final]], [y[j], y[j]], 'b', lw=2)
        inicial = j + 1
    j += 1
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()

