# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5b.py
función discontinua
"""

import matplotlib.pyplot as plt
import numpy as np

cphielo = 2.072773
cpliquida = 4.187409
cpvapor = 1.836533
print 'cphielo = ' + "%6.4f" % cphielo
print 'cpliquida = ' + "%6.4f" % cpliquida
print 'cpvapor = ' + "%6.4f" % cpvapor
qfusion = 334  # J g-1
qvaporizacion = 2260  # J g-1
x = [-100, 0, 0, 100, 100, 200]
q = np.zeros(6, float)
q[0] = 0
q[1] = cphielo * 100
q[2] = q[1] + qfusion
q[3] = q[2] + cpliquida * 100
q[4] = q[3] + qvaporizacion
q[5] = q[4] + cpvapor * 100
for i in range(0, 6):
    print str(x[i]) + "%6.0f" % q[i]
plt.plot([-100, 0], [0, q[1]], 'b', lw=1.5)
plt.plot([0, 100], [q[2], q[3]], 'b', lw=1.5)
plt.plot([100, 200], [q[4], q[5]], 'b', lw=1.5)
plt.ylabel('q')
plt.xlabel('t')
puntosX = [80, 85, 90, 95, 105, 110, 115, 120]
ceros = np.zeros(8, float)
puntosY = [
    q[2] + cpliquida * 80, q[2] + cpliquida * 85,
    q[2] + cpliquida * 90, q[2] + cpliquida * 95,
    q[4] + cpvapor * 5, q[4] + cpvapor * 10,
    q[4] + cpvapor * 15, q[4] + cpvapor * 20]
# lineas verticales discontinuas
plt.plot([0, 0], [q[1], q[2]], 'k--', lw=0.5)
plt.plot([100, 100], [q[3], q[4]], 'k--', lw=0.5)
#puntos
plt.plot(puntosX, ceros, 'ro')
plt.plot(puntosX, puntosY, 'ro')
plt.show()
