# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p5h.py
x * sen(x)/ 5
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 360
b = 10  # radianes
x = np.linspace(0, b, numpuntos)
y = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y[i] = x[i] * np.sin(x[i]) / 5
fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1, aspect='equal')
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')
plt.axhline(color='black', lw=1)
'''ax.set_xticks([0, pi, 2 * pi, 3 * pi, 4 * pi,
               5 * pi, 6 * pi, 7 * pi,
               8 * pi, 9 * pi, 10 * pi])
ax.set_xticklabels(['0', r'$\pi$', r'$2\pi$',
                    r'$3\pi$', r'$4\pi$',
                    r'$5\pi$', r'$6\pi$',
                    r'$7\pi$', r'$8\pi$',
                    r'$9\pi$', r'$10\pi$'])'''
p1, = plt.plot(x, y, 'b', lw=2,
               label='y = (x senx)/5')
plt.plot([0, b], [0, b / 5], 'k--', lw=0.5)
plt.plot([0, b], [0, -b / 5], 'k--', lw=0.5)
plt.ylabel('y')
plt.xlabel('x (radianes)')
plt.show()
