# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4e.py
intervalos encajados número e
"""

import fractions


def encajados(n):
    i = 1
    while i <= n:
        anum = (i + 1) ** i
        bnum = anum * (i + 1)
        aden = i ** i
        bden = aden * i
        # fracciones
        fraca = fractions.Fraction(anum, aden)
        fracb = fractions.Fraction(bnum, bden)
        print (str(i) + ': ' + '%s < e < %s' % (fraca, fracb))
#        print (str(i) + ': ' +
#               "%15.12f" % (1.0 * anum / aden) +
#               ' < e < ' + "%15.12f" % (1.0 * bnum / bden))
        i += 1

encajados(10)  # ha de ser <=140 para el calculo con decimales
