# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4b.py
raiz cuadrada
"""

import numpy as np


def raiz(n, A):
    print ('Cálculo de raiz de ' + "%3.1f" % A +
           ' mediante ' + str(n) + ' términos.')
    y = np.zeros(n + 1, float)
    y[1] = A / 2.0      # comenzamos por A/2:
    for i in range(2, n + 1):
        y[i] = 0.5 * (y[i - 1] + (A / y[i - 1]))
        s = ('y[' + "%.0f" % i + '] = 0.5(' +
             "%12.8f" % y[i - 1] + '+(' + "%3.1f" % A +
             '/' + "%12.8f" % y[i - 1] + ')) = ' +
             "%12.8f" % y[i])
        print s
    print ('Cálculo directo: raiz(A) = raiz(' +
           "%3.1f" % A + ') = ' +
           "%.15f" % np.sqrt(A))
#n: número de términos que vamos a calcular
#A: número cuya raíz queremos calcular
raiz(10, 3000)  # raiz(n, A)
