# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4a.py
sucesion a ** n, con |a|<1
"""

import numpy as np


def geometrica301(epsilon, a):
    print ('a = ' + str(a) +
           '; epsilon requerido =' +
           "%8.4g" % epsilon)
    n = (int(round(np.log10(epsilon) / np.log10(abs(a)))) + 1)
    x = np.zeros(n + 1, float)
    x[1] = a * 1.0
    print ('Es necesario calcular ' + str(n) +
           ' términos de la sucesión:')
    print "%3.0f" % 1.0, ': ', "%8.2g" % a
    for i in range(2, n + 1):
        x[i] = x[i - 1] * a
        print "%3.0f" % i, ': ', "%8.4g" % x[i]

geometrica301(1e-10, 0.15)  # geometrica301(epsilon, a)
