# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4f.py
representa intervalos encajados
"""

import numpy as np
import matplotlib.pyplot as plt

terminos = 25
x = []
yerror = []


def encajados(n):
    i = 1.0
    while i <= n:
        inicio = ((i + 1) ** i) / (i ** i)
        final = (i + 1) ** (i + 1) / (i ** (i + 1))
        x.append(i)
        yerror.append(final - inicio)
        i += 1

encajados(terminos)
y = np.zeros(terminos, float)
for i in range(0, len(x)):
    y[i] = np.e

xerror = np.zeros(terminos, float)
plt.errorbar(x, y, xerr=xerror, yerr=yerror)
plt.xlabel('n')
plt.ylabel('amplitud de los intervalos')
plt.show()
