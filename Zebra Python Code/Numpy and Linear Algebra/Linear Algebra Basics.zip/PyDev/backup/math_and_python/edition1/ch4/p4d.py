# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4d.py
sucesión número e
diferencia entre terminos consecutivos < epsilon
"""

import numpy as np


def sucesione2(epsilon):
    i = 1
    incremento = 1000
    while incremento > epsilon:
        #j = i + 1
        y = np.power((1 + (1.0 / i)), i)
        y1 = np.power((1 + (1.0 / (i + 1))), (i + 1))
        incremento = abs(y1 - y)
        i += 1
    print 'epsilon requerido: ', epsilon
    print 'número de terminos: N = ', i - 1
#    j = i
#    i = i - 1
    y = np.power((1 + (1.0 / (i - 1))), (i - 1))
    y1 = np.power((1 + (1.0 / i)), i)
    print 'x[', i, '] - x[', i - 1, '] = '
    print "%30.27f" % y1, ' -', "%30.27f" % y, ' = '
    print ' = ', y1 - y

sucesione2(1e-3)  # ha de ser >1e-16
