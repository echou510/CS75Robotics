# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p4g.py
a^n/n!
"""

import numpy as np
import matplotlib.pyplot as plt


def fact(x):
    if x == 0:
        return 1
    else:
        return x * fact(x - 1)

a = 3.5
k = int(np.trunc(a))
gamma = a / (k + 1)
b = np.power(a, k) / (fact(k) * (np.power(gamma, k)))
n = 10 * k
sucesion = np.zeros(n + 1, float)
mayorante = np.zeros(n + 1, float)
puntos = np.zeros(n + 1, float)
for i in range(0, n + 1):
    sucesion[i] = np.power(a, i) / fact(i)
    mayorante[i] = b * np.power(gamma, i)
    puntos[i] = i
p1, = plt.plot(puntos, mayorante, 'k+')
p2, = plt.plot(puntos, sucesion, 'bo')
plt.ylabel('terminos de la sucesion')
plt.xlabel('n')
plt.legend(('b$\gamma ^{n}$', '$ a^n /n!$'), loc='best')
print 'a = ' + str(a) + '; k = ' + str(k)
print 'gamma = ' + "%8.6f" % gamma
print 'b = ' + "%8.6f" % b + '; n = ' + str(n)
for i in range(0, n + 1):
    print (str(i) + ': ' + "%9.4g" % sucesion[i] +
           "%12.6f" % mayorante[i])
plt.show()
