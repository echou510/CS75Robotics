# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8j.py
Calcula el numero pi
mediante la serie de Leibniz
"""

import matplotlib.pyplot as plt
import numpy as np

signo = 1.0
piaprox = 0
seriepi = []
x = []
paso = 0
for i in range(1, 5000, 2):
    piaprox += 4 * signo / i
    if paso == 100:
        seriepi.append(piaprox)
        x.append(i)
        seriepi.append(piaprox - 4.0 / (i + 1))
        x.append(i + 1)
        paso = 0
    print str(i) + "%15.8f" % (signo / i) + "%15.8f" % piaprox
    signo *= -1
    paso += 1
#print seriepi
plt.plot(x, seriepi, 'bo', lw=1.0)
plt.plot([99, 5000], [np.pi, np.pi], 'r-', lw=1.5)
plt.xlim(99, 5000)
plt.xlabel('n')
plt.ylabel('S(n)')
plt.show()
