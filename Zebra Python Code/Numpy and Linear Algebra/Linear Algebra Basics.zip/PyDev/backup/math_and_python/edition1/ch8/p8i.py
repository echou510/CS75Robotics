# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8i.py
representa radiación del cuerpo negro aproximando como f = x**3*exp(-x/T)
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 500
fig = plt.figure(facecolor='white')
x = np.linspace(0, 1e4, numpuntos)
y1 = np.zeros(numpuntos, float)
y2 = np.zeros(numpuntos, float)
y3 = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y1[i] = x[i] ** 3 * np.exp(-x[i] / 273.0)
    y2[i] = x[i] ** 3 * np.exp(-x[i] / 400.0)
    y3[i] = x[i] ** 3 * np.exp(-x[i] / 600.0)
p1, = plt.plot(x, y1, 'g-', lw=1.5, label='$T=273$')
p2, = plt.plot(x, y2, 'r-', lw=2.5, label='$T=400$')
p3, = plt.plot(x, y3, 'b--', lw=2.5, label='$T=600$')
plt.legend(('$T=273$', '$T=400$', '$T=600$'), loc='best')
plt.ylabel('y')
plt.xlabel('x')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()
