# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8c.py
representa el teorema de Cauchy
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

pi = np.pi
t1 = pi / 15
t2 = pi / 2.5
print 't1 = pi / 15 = ' + "%5.3f" % t1
print 't2 = pi / 2.5 = ' + "%5.3f" % t2


def f(t):
    fv = 2 * ((np.sin(t)) ** 3)
    return fv


def g(t):
    gv = 2 * ((np.cos(t)) ** 3)
    return gv

numpuntos = 360
tinicial = 0
tfinal = numpuntos
x = np.zeros(numpuntos, float)
y = np.zeros(numpuntos, float)
t = tinicial
while t < tfinal:
    radianes = np.deg2rad(t)
    x[t] = 2 * (np.cos(radianes) ** 3)
    y[t] = 2 * (np.sin(radianes) ** 3)
    t += 1
plt.plot(x, y, 'r-', lw=2)
plt.plot(g(t1), f(t1), 'bo')
plt.text(g(t1), f(t1) + 0.1, 'A', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')
plt.plot(g(t2), f(t2), 'bo')
plt.text(g(t2), f(t2) + 0.1, 'B', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')
plt.plot([g(t1), g(t2)], [f(t1), f(t2)], 'k--', lw=1.5)


def punto(t, letra):
    print (letra + '(' + "%4.2f" % g(t) +
           ', ' + "%4.2f" % f(t) + ')')
punto(t1, 'A')
punto(t2, 'B')
pendiente = (f(t2) - f(t1)) / (g(t2) - g(t1))
print 'pendiente = ' + "%4.2f" % pendiente

'''
df = 6 * (np.cos(t)) ** 2
dg = -6 * (np.sin(t)) ** 2
df/dg = -1 / (np.tan(t)) ** 2 = pendiente
t = np.arctan(np.sqrt(-1 / pendiente))
'''

tc = np.arctan(np.sqrt(-1 / pendiente))
print 'tc = ' + "%5.3f" % tc
punto(tc, 'C')
plt.plot(g(tc), f(tc), 'bo')
plt.text(g(tc), f(tc) + 0.1, 'C', horizontalalignment='left',
         fontsize=12, color='black', weight='bold')
'''
recta tangente: y-f(tc)=pendiente * (x - g(tc))
ytangente = f(tc) + pendiente * (x - g(tc))
ytangente(-1) = f(tc) - pendiente * (1 + g(tc))
ytangente(2.5) = f(tc) + pendiente * (2.5 - g(tc))
'''

plt.plot([-1.5, 2.5],
         [f(tc) - pendiente * (1.5 + g(tc)),
          f(tc) + pendiente * (2.5 - g(tc))],
         'b-', lw=1.5)

plt.xlim(-2.25, 2.25)
plt.ylim(-2.25, 2.25)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
