# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8g.py
representa tiro parabolico y parabola de seguridad
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

y0 = 0.0
#v0 = 263e3 / 3600.0  # pelota tenis
#v0 = 920  # fusil HK http://en.wikipedia.org/wiki/Heckler_%26_Koch_G36
v0 = 31.08
print 'v0 = ' + "%.2f" % v0 + ' m/s'
g = -9.81
H = (v0 ** 2) / (-2 * g)  # altura máxima alcanzable
print 'altura máxima = ', "%.1f" % H, ' m'
alcancemaximo = 2 * H
print 'alcance máximo = ', "%.1f" % alcancemaximo, ' m'
lista_angulos = [15.0, 30.0, 45.0, 60.0, 85.0]
#vy = v0y - g * t
#tiempo en alcanzar el punto más alto: tsuelo / 2
#vx = v0x
#x = v0x * t
#y = y0 + v0y*t + 0.5*g*t**2
#y = y0 + v0y*x/v0x + (0.5*g/v0x**2)*x**2
#ymax = y0 + v0y*tsuelo/2 + 0.5*g*(tsuelo/2)**2

print 'angulo     ymax     alcance    tiempo'
for j in range(0, 5):
    alfa = np.deg2rad(lista_angulos[j])
    v0y = v0 * np.sin(alfa)
    tsuelo = - 2 * v0y / g
    v0x = v0 * np.cos(alfa)
    alcance = - (v0 ** 2) * np.sin(2 * alfa) / g
    ymax = y0 + (v0y * tsuelo / 2) + (0.5 * g * (tsuelo / 2) ** 2)
    print (str(lista_angulos[j]) + "%11.1f" % ymax +
           "%11.1f" % alcance + "%11.2f" % tsuelo)


def f(x, beta):
    v0x = v0 * np.cos(np.deg2rad(beta))
    #coeficientes a0, a1,... an
    a = [y0, (np.tan(np.deg2rad(beta))), ((0.5 * g) / (v0x ** 2))]
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


numpuntos = 300
x = np.linspace(0, np.ceil(alcancemaximo), numpuntos)

y15 = np.zeros(numpuntos, float)
y30 = np.zeros(numpuntos, float)
y45 = np.zeros(numpuntos, float)
y60 = np.zeros(numpuntos, float)
y85 = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y15[i] = f(x[i], 15.0)
    y30[i] = f(x[i], 30.0)
    y45[i] = f(x[i], 45.0)
    y60[i] = f(x[i], 60.0)
    y85[i] = f(x[i], 85.0)

plt.plot(x, y15, 'k:', lw=2, label='$15$')
plt.plot(x, y30, 'k-.', lw=2, label='$30$')
plt.plot(x, y45, 'r-', lw=2.5, label='$45$')
plt.plot(x, y60, 'k--', lw=2, label='$60$')
plt.plot(x, y85, 'k:', lw=2, label='$85$')

plt.plot(-x, y15, 'k:', lw=2, label='$15$')
plt.plot(-x, y30, 'k-.', lw=2, label='$30$')
plt.plot(-x, y45, 'r-', lw=2.5, label='$45$')
plt.plot(-x, y60, 'k--', lw=2, label='$60$')
plt.plot(-x, y85, 'k:', lw=2, label='$85$')
plt.axhline(color='grey', lw=1)
plt.axvline(color='grey', lw=1)

plt.legend(('$15\,^{\circ}$', '$30\,^{\circ}$',
            '$45\,^{\circ}$', '$60\,^{\circ}$',
            '$85\,^{\circ}$'), loc='best')
plt.ylabel('y')
plt.xlabel('x')

#parabola de seguridad
print 'parábola de seguridad: Ax^2 + Bx + C = 0'
A = -H / (alcancemaximo ** 2)
print 'A = -H / v0^2 = ', A
print 'B = 0'
print 'C = H = ', H
print ('y = ' + "%.6f" % A + 'x^2 + ' + "%.6f" % H)
#calcula 100 puntos de la parabola
xrango = np.linspace(-alcancemaximo, alcancemaximo, 100)
yrango = np.zeros(100, float)

for k in range(0, 100):
    yrango[k] = A * xrango[k] ** 2 + H
plt.plot(xrango, yrango, 'k-', lw=1.0)
plt.fill_between(xrango, yrango, 0, alpha=0.2, color='#BDD0D7')
plt.ylim(0, 1.1 * (v0 ** 2) / (-2 * g))
#plt.ylim(0, alcancemaximo)
#plt.axis('equal')
plt.show()
