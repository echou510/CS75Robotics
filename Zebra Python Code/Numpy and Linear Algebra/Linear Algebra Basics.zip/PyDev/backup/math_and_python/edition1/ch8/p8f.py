# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8f.py
representa polinomios, con M, m, cortes y P.I.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

#coeficientes a0, a1,... an

a = [-1, 0, 0, -4, 0, 2]

'''
fis_y0 = 0.0
fis_v0 = 50.0
fis_g = -9.81
a = [fis_y0, fis_v0, 0.5 * fis_g]
'''

caracteristicosx = [0]
caracteristicosy = [0]


def latexpolinomio(p):
    if p[0] > 0:
        polinomio = '+' + str(p[0])
    elif p[0] < 0:
        polinomio = str(p[0])
    else:
        polinomio = ''
    n = 1
    while n <= (len(p) - 1):
        if p[n] == 0:
            n += 1
        else:
            signo = ''
            if p[n] < 0:
                signo = ' '
            elif p[n] > 0:
                signo = '+'
            if n > 0:
                polinomio = ' ' + str(p[n]) + 'x^{' + str(n) + '} ' + polinomio
            else:
                polinomio = ' ' + str(p[n]) + polinomio
            polinomio = signo + polinomio
            n += 1
    if (polinomio[0]) == '+':
        polinomio = polinomio[1:len(polinomio)]
    return polinomio


def derivada(p):
    d = np.zeros(len(p), float)
    i = len(p) - 1
    while i > 0:
        d[i - 1] = p[i] * i
        i -= 1
    return d


def f(x):
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


print 'polinomio P: ' + str(a) + ' = ' + latexpolinomio(a)
#corte con el eje Y
print 'Corte con el eje Y: (0,', f(0), ')'
plt.plot(0, f(0), 'yo')
cadena = '$' + "%3.1f" % f(0) + '$'
plt.text(0.1, f(0), cadena, horizontalalignment='left',
         fontsize=12, color='black', weight='bold')

#cortes con el eje X
corteX = np.roots(a[::-1])
cortaalejeX = False
corteXreal = []
for corte in corteX:
    if np.iscomplex(corte) == False:
        corte = float(np.real(corte))
        print 'Corte con el eje X: (' + "%6.3f" % corte + ', 0)'
        corteXreal.append(corte)
        cortaalejeX = True
        plt.plot(corte, f(corte), 'yo')
        cadena = '$' + "%3.1f" % corte + '$'
        plt.text(corte, -0.2, cadena,
                 horizontalalignment='center',
                 verticalalignment='top',
                 fontsize=12, color='black', weight='bold')
        caracteristicosx.append(corte)
        caracteristicosy.append(corte)
if cortaalejeX == False:
    print 'la función no corta al eje X'

#derivadas
d1 = np.zeros(len(a), float)
d2 = np.zeros(len(a), float)
d1 = derivada(a)
d2 = derivada(d1)
print 'P' + "'" + ': ' + str(d1) + ' = ' + latexpolinomio(d1)
print 'P' + "''" + ': ' + str(d2) + ' = ' + latexpolinomio(d2)

#raices de la derivada d1
lista1 = d1[::-1]
raices1 = np.roots(lista1)
#print raices1
for i in range(0, len(raices1)):
    if np.iscomplex(raices1[i]) is True:
        np.delete(raices1, i)
    else:
        plt.plot(raices1[i], f(raices1[i]), 'k+')
        print 'derivada se anula para x= ' + "%5.2f" % raices1[i]
        caracteristicosx.append(raices1[i])
        caracteristicosy.append(f(raices1[i]))

for r in raices1:
    if np.iscomplex(r) == False:
        valor = d2[0]
        for i in range(1, len(d2)):
            valor = valor + d2[i] * r ** [i]
            posicion = '(' + "%4.1f" % r + ', ' + "%4.1f" % f(r) + ')'
            if valor < 0:
                extremo = 'Máximo: ' + posicion
                letra = 'M'
            elif valor > 0:
                extremo = 'mínimo: ' + posicion
                letra = 'm'
            else:
                extremo = 'punto de inflexión: ' + posicion
                letra = 'In'
        print 'd2(' + str(r) + ') = ' + str(valor) + ': ' + extremo
        plt.text(r, 0.3 + f(r), letra,
                 horizontalalignment='center',
                 verticalalignment='bottom',
                 fontsize=13, color='blue', weight='bold')

numpuntos = 300
#print 'caracteristicos x: ', caracteristicosx
if len(a) < 3:
    xmax = 2 * np.max(caracteristicosx)
    xmin = 2 * np.min(caracteristicosx)
else:
    xmax = 1.2 * np.max(caracteristicosx)
    xmin = 1.2 * np.min(caracteristicosx)
if xmin == 0:
    xmin = -1
if xmax == 0:
    xmax = 1
caracteristicosy.append(f(xmax))
caracteristicosy.append(f(xmin))
#print 'caracteristicos y: ', caracteristicosy
ymax = 1.15 * np.max(caracteristicosy)
ymin = 1.15 * np.min(caracteristicosy)
if ymin == 0:
    ymin = -1
if ymax == 0:
    ymax = 1

x = np.linspace(xmin, xmax, numpuntos)
y = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y[i] = f(x[i])
plt.xlim(xmin, xmax)
plt.ylim(ymin, ymax)
plt.plot(x, y, 'r-', lw=1.5)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
