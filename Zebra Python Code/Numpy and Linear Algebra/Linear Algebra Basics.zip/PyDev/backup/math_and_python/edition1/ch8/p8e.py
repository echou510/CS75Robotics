# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8e.py
serie de Mc Laurin
"""

import sympy as sy

x, y, z = sy.symbols('x y z')
sy.init_printing(use_unicode=True)
j = complex(0, 1)


#fx = sy.sin(x)
#fx = sy.cos(x)
#fx = sy.exp(x)
#fx = sy.cos(j * x)
#fx = sy.sin(j * x) / j
fx = sy.atan(x)
f0 = fx.subs(x, 0).evalf(3)
maclaurin = str(f0) + ' + '
print 'f(x) = ' + str(fx)
for d in range(1, 11):
    #print maclaurin
    derivada = sy.diff(fx, x, d)
    derivada0 = derivada.subs(x, 0).evalf(3)
    sd = str(derivada0)
    print ('D' + str(d) + ' = ' + sd + '; D' + str(d) + '(0) = ' + sd)
    if sd != '0':
        maclaurin += '[' + sd + ' * (x**' + str(d) + ') / ' + str(d) + '!] + '
print
print maclaurin + '...'
serie = fx.series(x, 0, 11)  # desarrollo en serie con sympy
print serie
