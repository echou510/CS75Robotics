# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8k.py
y = 1+x^2
y' = 2x
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)


def f(equis):
    fx = 1 + equis ** 2
    return fx


def df(equis):
    dfx = 2 * equis
    return dfx

x0 = 0.75
dx = 1
numpuntos = 50
x = np.linspace(0, 2.0, numpuntos)
y = np.zeros(numpuntos, float)
m = df(x0)
y0 = f(x0)
for i in range(0, numpuntos):
    y[i] = f(x[i])
fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1, aspect='equal')
p1, = plt.plot(x, y, color='#F76429', lw=2.5,)
#plt.plot(x, y)
plt.ylabel('y')
plt.xlabel('x')
x = np.linspace(0.75, 1.25, 10)
y = np.zeros(10, float)
ceros = np.zeros(10, float)
plt.ylabel('y')
plt.xlabel('x')
ax.set_ylim(0, 4.5)
ax.set_xlim(0, 2.5)
#derivada en x0
#y'(x0) = 1.75; y'(0.5)=1; y'(2)=4
#recta tangente: y-y0 = m(x-x0) = 2x0*x - 2x0^2
#recta tangente: y = y0 + mx - mx0
# vertical line
plt.plot([0, 2.5], [y0 - m * x0, y0 + m * (2.5 - x0)], 'b', lw=1)
plt.plot([x0, x0], [0, m], 'k--', lw=0.5)
plt.plot([x0 + dx, x0 + dx], [0, f(x0 + dx)], 'k--', lw=0.5)
plt.plot([0, x0 + dx], [y0, y0], 'k--', lw=0.5)
plt.plot([0, x0 + dx], [f(x0 + dx), f(x0 + dx)], 'k--', lw=0.5)
#ax.set_frame_on(False)
#plt.axis('off')
plt.text(0.05, y0, '$f(x_0)$', horizontalalignment='left',
         size='large', color='black', weight='bold')
plt.text(0.05, f(x0 + dx), '$f(x_0 + \Delta x)$',
         horizontalalignment='left',
         size='large', color='black', weight='bold')
plt.text(0.05, 0.5 * (y0 + f(x0 + dx)), '$\Delta y$',
         horizontalalignment='left',
         size='large', color='black', weight='bold')
plt.text(x0, 0.05, '$x_0$', horizontalalignment='left',
         size='large', color='black', weight='bold')
plt.text(x0 + dx, 0.05, '$x_0 + \Delta x$', horizontalalignment='center',
         size='large', color='black', weight='bold')
plt.text(x0 + 0.5 * dx, y0 - 0.1, '$\Delta x$',
         horizontalalignment='center',
         size='large', color='black', weight='bold')
plt.text(x0 + dx - 0.1, y0 + 0.5, '$dy$',
         horizontalalignment='center',
         size='large', color='black', weight='bold')
plt.show()
