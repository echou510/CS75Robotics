# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p8d.py
serie de Taylor hasta la cuarta derivada
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
import sympy as sy
from scipy.misc import factorial

x, y, z = sy.symbols('x y z')
sy.init_printing(use_unicode=True)

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

a = 60.0   # grados
aradianes = np.deg2rad(a)
fx = 3 * sy.sin(2 * x)
print 'f = ' + str(fx)
fa = fx.subs(x, aradianes).evalf(6)
print 'f(a) = ' + str(fa)

derivada = [0, 0, 0, 0, 0]
derivada[0] = fx
p = [0, 0, 0, 0, 0]
p[0] = "%6.2f" % fa
strp = p[0]
for d in range(1, 5):
    derivada[d] = sy.diff(fx, x, d)
    print 'D' + str(d) + ' = ' + str(derivada[d])
    p[d] = str(derivada[d].subs(x, aradianes).evalf(2))
    strp = strp + ' + (' + p[d] + '/' + str(factorial(d)) + ')(x-a)^' + str(d)
    print 'p' + str(d) + ' = ' + strp


def f(x):
    fv = 3 * np.sin(2 * x)
    return fv


def D1(x):
    D1v = 6 * np.cos(2 * x)
    return D1v


def D2(x):
    D2v = -12 * np.sin(2 * x)
    return D2v


def D3(x):
    D3v = -24 * np.cos(2 * x)
    return D3v


def D4(x):
    D4v = 48 * np.sin(2 * x)
    return D4v

numpuntos = 180
x = np.zeros(numpuntos, float)
y = np.zeros(numpuntos, float)
p1 = np.zeros(numpuntos, float)
p2 = np.zeros(numpuntos, float)
p3 = np.zeros(numpuntos, float)
p4 = np.zeros(numpuntos, float)
i = 0
while i < numpuntos:
    x[i] = i
    radianes = np.deg2rad(x[i])
    incremento = np.deg2rad(i - a)
    y[i] = f(radianes)
    p1[i] = f(aradianes) + D1(aradianes) * incremento
    p2[i] = p1[i] + (D2(aradianes) / 2) * (incremento ** 2)
    p3[i] = p2[i] + (D3(aradianes) / 6) * (incremento ** 3)
    p4[i] = p3[i] + (D4(aradianes) / 24) * (incremento ** 4)
    #print x[i], y[i], p1[i]
    i += 1
plt.plot(x, y, 'k-', lw=3)
plt.plot(x, p1, 'y--', lw=1)
plt.plot(x, p2, 'g--', lw=1.25)
plt.plot(x, p3, 'b--', lw=1.5)
plt.plot(x, p4, 'r-', lw=1.75)
plt.ylim(-4, 4)
plt.plot(a, f(aradianes), 'bo')
plt.text(a, f(aradianes) + 0.3, 'f(a)', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.plot(a, 0, 'bo')
plt.text(a, -0.3, 'a', horizontalalignment='center',
         fontsize=15, color='black', weight='bold')
plt.legend(('f(x)', 'p1', 'p2', 'p3', 'p4'), loc='best')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
