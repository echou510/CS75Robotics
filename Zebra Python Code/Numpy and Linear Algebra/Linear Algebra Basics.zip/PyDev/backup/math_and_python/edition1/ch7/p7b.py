# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p7b.py
crecimiento exponencial
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

#fuente: INE: http://www.ine.es/inebaseweb/libros.do?tntp=71807
#poblacion de derecho a 31 de diciembre de cada año 1900-1960
#poblacion total desde 1970
pob = {1900: 18855668, 1910: 20898687, 1920: 22125480,
       1930: 24027237, 1940: 26388311, 1950: 28420922,
       1960: 31071747, 1970: 34037849, 1981: 37683362,
       1991: 38872268, 2001: 40847371, 2011: 46815916}

xdata = np.sort(pob.keys())
print xdata
ydata = np.sort(pob.values())
print ydata
incpob = max(ydata) - min(ydata)
inctiempo = max(xdata) - min(xdata)
print incpob
print inctiempo
incmedioanual = incpob / inctiempo
print incmedioanual
fig = plt.figure(facecolor='white')
ax = fig.add_subplot(1, 1, 1)
ax.set_xlim(1890, 2020)
ax.set_ylim(10e6, 50e6)
plt.ylabel('y = millones de personas')
ax.set_yticks([15e6, 20e6, 25e6, 30e6, 35e6, 40e6, 45e6, 50e6])
ax.set_yticklabels(['15', '20', '25', '30', '35', '40', '45', '50'])
p1, = plt.plot(xdata, ydata, 'ko')
#ajuste por minimos cuadrados
print 'ajuste por mínimos cuadrados:'
lny = np.zeros(12, float)
for i in range(0, 12):
    lny = np.log(ydata)
#p2, = plt.plot(xdata, lny, 'ro') #ajuste a una recta
slope, intercept, r_value, p_value, std_err = stats.linregress(xdata, lny)
print 'r^2: ', "%8.6f" % (r_value ** 2)
print ('recta: y =  ' + "%6.4f" % slope +
       'x + ' + "%6.4f" % intercept)
print 'exponencial y=Ae^bx:'
print ('y = ' + "%6.4f" % (np.exp(intercept)) +
       ' e^(' + "%6.4f" % (slope) + 'x)')
ymc = np.zeros(12, float)
for i in range(0, 12):
    ymc[i] = np.exp(intercept) * np.exp(slope * xdata[i])
p3, = plt.plot(xdata, ymc, 'r', lw=2)
plt.show()
