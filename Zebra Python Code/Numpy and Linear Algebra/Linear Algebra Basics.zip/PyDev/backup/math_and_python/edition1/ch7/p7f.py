# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p7f.py
representa z^n en forma polar
"""

import matplotlib
import numpy as np
from matplotlib.pyplot import figure, show, rc, grid

pi = np.pi
z1 = [1.02, pi / 10]

fraccionpi = int(pi / z1[1])
r = []
theta = []
r.append(z1[0])
theta.append(z1[1])

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

# figura
width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  hace un cuadrado
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True, axisbg='#ffffff')

#potencias de z
for i in range(1, 4 * fraccionpi + 1):
    radio = np.power(r[0], i)
    r.append(radio)
    angulo = theta[0] * i
    theta.append(angulo)
    etiqueta = '$z^{' + str(i) + '}$'
    ax.annotate(etiqueta,
                xy=(angulo, 1.1 * radio),  # theta, radio
                horizontalalignment='center',
                verticalalignment='middle',
                fontsize=14, color='#EE182E')

ax.plot(theta, r, color='#1821EE', lw=4)
ax.set_rmax(max(r) * 1.25)
grid(True)
#print r
#print theta
show()
