# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p7a.py
funcion exp(x)
"""

from numpy import e


def fact(x):
    if x == 0:
        return 1
    else:
        return x * fact(x - 1)


def u(i):
    termino = 1.0 / fact(i)
    return termino

x = 1.0
n = 12  # numero de terminos a calcular
suma = 0
for i in range(0, n + 1):
    suma += u(i)
    print 'S(' + str(i) + ') = ' + "%20.18f" % suma

print 'valor real de e: ' + "%20.18f" % e
print 'error: ' + "%10.8g" % (e - suma)
