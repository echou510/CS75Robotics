# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p7d.py
representa y = e^x; y = e^-x; y=e^-(x^2)
"""

import numpy as np
import matplotlib.pyplot as plt

numpuntos = 100
fig = plt.figure(facecolor='white')
x = np.linspace(-2.5, 2.5, numpuntos)
y1 = np.zeros(numpuntos, float)
y2 = np.zeros(numpuntos, float)
y3 = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y1[i] = np.exp(x[i])
    y2[i] = np.exp(-x[i])
    y3[i] = np.exp(-(x[i] ** 2))
ax = fig.add_subplot(1, 1, 1, aspect='equal')
p1, = plt.plot(x, y1, 'g', lw=2, label='$e^{x}$')
p2, = plt.plot(x, y2, 'r--', lw=2, label='$e^{-x}$')
#p3, = plt.plot(x, y3, 'b-', lw=2, label='$e^{-x^2}$')
plt.legend(('$e^{x}$', '$e^{-x}$',), loc='best')
#plt.legend(('$e^{-x^2}$',), loc='best')
ax.autoscale_view(tight=True)
plt.ylabel('y')
plt.xlabel('x')
ax.set_xlim(-2.1, 2.1)
ax.set_ylim(0, 12.5)
#ax.set_ylim(0, 1.1)
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.show()
