# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p7e.py
representa z^n en forma polar
"""

import matplotlib
import numpy as np
from matplotlib.pyplot import figure, show, rc, grid

pi = np.pi
z1 = [1.0, pi / 6]

fraccionpi = int(pi / z1[1])
r = []
theta = []
r.append(z1[0])
theta.append(z1[1])

# radar
rc('grid', color='#CACBD3', linewidth=1, linestyle='-')
rc('xtick', labelsize=10)
rc('ytick', labelsize=10)

# figura
width, height = matplotlib.rcParams['figure.figsize']
size = min(width, height)
#  hace un cuadrado
fig = figure(figsize=(size, size))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8],
                  polar=True, axisbg='#ffffff')

#potencias de z
for i in range(2, 2 * fraccionpi + 2):
    radio = np.power(r[0], i)
    r.append(radio)
    angulo = theta[0] * i
    theta.append(angulo)
    if i < 2 * fraccionpi + 1:
        etiqueta = '$z^{' + str(i) + '}$'
    else:
        etiqueta = '$z^{' + str(1) + '}$'
    if i <= fraccionpi:
        radioetiqueta = 1.1 * radio
        hetiqueta = 'center'
        vetiqueta = 'middle'
    elif i <= 2 * fraccionpi:
        radioetiqueta = 1.2 * radio
        hetiqueta = 'center'
        vetiqueta = 'bottom'
    else:
        radioetiqueta = 1.1 * radio
        hetiqueta = 'center'
        vetiqueta = 'middle'
    ax.annotate(etiqueta,
                xy=(angulo, radioetiqueta),  # theta, radio
                horizontalalignment=hetiqueta,
                verticalalignment=vetiqueta,
                fontsize=18, color='#EE182E')

#print r
#print theta
ax.plot(theta, r, color='#1821EE', lw=4)
ax.set_rmax(max(r) * 1.5)
grid(True)
show()
