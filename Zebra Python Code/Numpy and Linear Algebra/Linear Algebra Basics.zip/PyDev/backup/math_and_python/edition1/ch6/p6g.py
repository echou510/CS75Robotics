# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p6f.py
calcula y representa parabola: discriminante != 0 y A33=0
"""

import numpy as np
import matplotlib.pyplot as plt

# ejemplo
#c20 = 1
#c11 = 2
#c02 = 1
#c10 = 1
#c01 = -2
#c00 = 1 

# escudos de Siracusa
c20 = 0.1
c02 = 0.5
c11 = np.sqrt(c20 * c02)
rango33 = 1
c10 = 5
c01 = 20
c00 = 30

print c20, 'x^2 + ', c11, 'xy + ', c02, 'y^2 + ', c10, 'x + ', c01, ' y + ', c00, ' = 0'
A = 0.5 * np.array([[2 * c20, c11, c10],
                    [c11, 2 * c02, c01],
                    [c10, c01, 2 * c00]])
print A
disc = np.linalg.det(A)
print '|A| = ', "%.4f" % disc
rangoA = np.linalg.matrix_rank(A)
print 'rango(A) = ', rangoA
#A33 = 0.5 * np.array([[2 * c20, c11], [c11, 2 * c02]])
#print 'A33 = ', A33
#det33 = np.linalg.det(A33)
#print '|A33| = ', det33
#rango33 = np.linalg.matrix_rank(A33)

if rangoA == 3:  # disc != 0
    if rango33 != 2: # det33 = 0
        print 'la ecuación representa una parábola real'
        I = c20 + c02
        p = np.sqrt(-disc / I ** 3)
        print 'y ** 2 = 2 * ', "%.3f" % p, 'x'
        print 'foco: (', "%.3f" % (p / 2), ', 0)'
        y = np.zeros(200, float)
        x = np.linspace(0, 0.15, 200)
        for i in range(0, 200):
            y[i] = np.sqrt(2 * p *x[i])
        plt.plot(x, y, 'r-', lw=5)
        plt.plot(x, -y, 'r-', lw=5)
        plt.plot(p / 2, 0, 'ro')
    #    plt.plot(-x, y, 'r-', lw=1.5)
    #    plt.plot(-x, y, 'r-', lw=1.5)
        plt.axhline(color='black', lw=1)
        plt.axvline(color='black', lw=1)
        plt.xlim(-10, 1.05 * p)
        plt.axis('equal')
        plt.show()
    else:
        print 'A33 no es nulo'
else:
    print 'El discriminante es nulo'
