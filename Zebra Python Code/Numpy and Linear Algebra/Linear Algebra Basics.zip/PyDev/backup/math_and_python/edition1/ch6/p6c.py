# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p6c.py
orbitas del modelo atomico de Sommerfeld para n=4
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()

#orbitas para el nivel n=4, en múltiplos de a0 [s p d f]
a4 = [16, 16, 16, 16]
b4 = [2, 6, 10, 14]
colores = ['k', 'b', 'g', 'r']

for i in range(0, 4):
    a = a4[i]
    b = b4[i]
    c = np.sqrt(a ** 2 - b ** 2)
    e = c / a
    f = [[-c, 0], [c, 0]]
    color = colores[i]
    elipse = Ellipse(xy=(c, 0), width=2 * a, height=2 * b,
                     edgecolor=color, fc='None', lw=2)
    ax.add_patch(elipse)

plt.plot(c, 0, 'ko')
plt.axis('equal')
plt.show()
