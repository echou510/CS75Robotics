# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p6a.py
determina el tipo de cónica si el discriminante = 0
"""

import numpy as np

# ejemplo
c20 = 0.25
c11 = 1
c02 = 1
c10 = -0.5
c01 = -1
c00 = -0.75


print c20, 'x^2 + ', c11, 'xy + ', c02, 'y^2 + ', c10, 'x + ', c01, ' y + ', c00, ' = 0'
A = 0.5 * np.array([[2 * c20, c11, c10],
                    [c11, 2 * c02, c01],
                    [c10, c01, 2 * c00]])
print A
disc = np.linalg.det(A)
print '|A| = ', "%.4f" % disc
rangoA = np.linalg.matrix_rank(A)
print 'rango(A) = ', rangoA
A33 = 0.5 * np.array([[2 * c20, c11], [c11, 2 * c02]])
print 'A33 = ', A33
det33 = np.linalg.det(A33)
print '|A33| = ', det33
rango33 = np.linalg.matrix_rank(A33)

# ------------- caso de disc = 0 ----------------------------
if rangoA != 3:  # disc = 0
    if rango33 == 2:  # det33 != 0
        if det33 > 0:  # 4 -2 1 -14 2 13
            print 'la ecuación representa dos rectas imaginarias conjugadas'
        if det33 < 0:  # -3 -2 1 7 -1 -2
            print 'la ecuación representa dos rectas que se cortan'
    if rango33 != 2:  # det33 = 0
        print 'la ecuación representa dos rectas paralelas o superpuestas,'
        print 'que pueden ser reales o imaginarias'
    m = np.roots([1, c11, c20])
    if (m[0] - m[1]) != 0:
        print 'pendientes de las rectas: ', m
        n2 = (c10 + m[1] * c01) / (m[0] - m[1])
        n1 = -(n2 + c01)
        print 'n1, n2 = ', n1, ', ', n2
        print 'las dos rectas son:'
        print 'y = ', m[0], 'x + ', n1
        print 'y = ', m[1], 'x + ', n2
else:
    print 'El discriminante no es nulo'
