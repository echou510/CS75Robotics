# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p6e.py
Representa y determina el tipo de hipérbola si la cónica tiene A33<0
"""

import numpy as np
import matplotlib.pyplot as plt
#from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()

print 'A x² + By² + C = 0'
print 'escribe A, B y C separados por un espacio:'
strdatos = raw_input()
datos = map(float, strdatos.split())
print datos
signos = np.sign(datos)

if signos[0] == -1:
    datos = np.multiply(-1.0, datos)
    print datos
t1 = datos[0]
t2 = datos[1]
k = datos[2]
D = t1 * t2
print 'A33 = ', D
if D < 0 and k != 0:
    t1 = datos[0]
    t2 = datos[1]
    k = datos[2]
    print datos
    a = np.sqrt(abs(k / t1))
    b = np.sqrt(abs(k / t2))
    c = np.sqrt(a ** 2 + b ** 2)
    print 'a = ', "%.3f" % a, '; b = ', "%.3f" % b, '; c = ', "%.3f" % c
    #print 'hipérbola horizontal'
    asintota = b / a
    print 'asíntotas: '
    print 'y = ', "%.3f" % asintota, 'x; y = ', "%.3f" % -asintota, 'x'
    vertice = a
    print 'vertices: (', "%.3f" % (-1 * vertice), ', 0), (', "%.3f" % vertice, ', 0)'
    e = c / a
    print 'excentricidad: ', "%.3f" % e
    y = np.zeros(200, float)
    vertice = a
    if e < 2:
        rango = 5 * vertice
    else:
        rango = 1.5 * vertice
    x = np.linspace(vertice, rango, 200)
    for i in range(0, 200):
        y[i] = asintota * np.sqrt(x[i] ** 2 - a ** 2)
    plt.plot(-c, 0, 'ro')
    plt.plot(c, 0, 'ro')
        
    #grafica
    plt.plot(x, y, 'r-', lw=1.5)
    plt.plot(x, -y, 'r-', lw=1.5)
    plt.plot(-x, y, 'r-', lw=1.5)
    plt.plot(-x, -y, 'r-', lw=1.5)
    plt.plot([-rango, rango], [-rango * asintota, rango * asintota],
             color='grey', ls='--', lw=0.8)
    plt.plot([-rango, rango], [rango * asintota, -rango * asintota],
             color='grey', ls='--', lw=0.8)
    plt.axhline(color='black', lw=1)
    plt.axvline(color='black', lw=1)
    plt.axis('equal')
    plt.show()
else:
    print 'A33 >= 0 o k=0'
