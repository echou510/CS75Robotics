# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p6d.py
Representa y determina el tipo de elipse si la cónica tiene A33>0
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

fig = plt.figure()
ax = plt.gca()
print 'A x² + By² + C = 0'
print 'escribe A, B y C separados por un espacio:'
strdatos = raw_input()
datos = map(float, strdatos.split())
print datos
signos = np.sign(datos)
if signos[0] == -1 and signos[1] == -1:
    datos = np.multiply(-1.0, datos)
    print datos
t1 = datos[0]
t2 = datos[1]
k = datos[2]
D = t1 * t2
print 'A33 = ', D
if D > 0:
    if np.sign([k]) == -1:
        a = np.sqrt(-k / t1)
        b = np.sqrt(-k / t2)
        c = np.sqrt(abs(a ** 2 - b ** 2))
        e = c / max(a, b)
        print 'a = ', "%.3f" % a, '; b = ', "%.3f" % b, '; c = ', "%.3f" % c
        print 'excentricidad: e = ', "%.4f" % e
        J = np.pi * (3 * (a + b)) - np.sqrt((3 * a + b) * (a + 3 * b))  # Ramanujan
        area = np.pi * a * b
        if a > b:
            f = [[-c, 0], [c, 0]]
            curva = 'elipse horizontal'
            perimetro = J
        if a == b:
            f = [[0, 0], [0, 0]]
            curva = 'circunferencia de radio R = ' + "%.3f" % a
            perimetro = 2 * np.pi * a
        if a < b:
            f = [[0, -c], [0, c]]
            curva = 'elipse vertical'
            perimetro = J
        print curva
        print 'perímetro: ', "%.3f" % perimetro
        print 'área interior: ', "%.3f" % area
        print 'x ** / ', "%.3f" % a ** 2, ') + (y ** 2 / ', "%.3f" % b ** 2, ') = 1'
        #grafica
        ellipse = Ellipse(xy=(0, 0), width=2 * a, height=2 * b, edgecolor='r', fc='None', lw=2)
        ax.add_patch(ellipse)
        plt.plot(f[0][0], f[0][1], 'ro')
        plt.plot(f[1][0], f[1][1], 'ro')
        plt.axhline(color='black', lw=1)
        plt.axvline(color='black', lw=1)
        plt.axis('equal')
        plt.show()
    if np.sign([k]) == 1:
        a = np.sqrt(k / t1)
        b = np.sqrt(k / t2)
        c = np.sqrt(abs(a ** 2 - b ** 2))
        print 'a, b, c: ', "%.3f" % a, "%.3f" % b, "%.3f" % c
        print 'elipse imaginaria'
    if np.sign([k]) == 0:
        print 'elipse degenerada: un punto'
else:
    print 'A33 <= 0'
