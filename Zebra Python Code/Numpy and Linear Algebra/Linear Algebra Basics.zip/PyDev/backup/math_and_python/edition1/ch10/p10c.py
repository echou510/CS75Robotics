# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10c.py
normaliza un vector
"""

import numpy as np


def modulo(nombre, a):
    radicando = 0.0
    dimension = len(a)
    for i in range(0, dimension):
        radicando = radicando + a[i] ** 2
    longitud = np.sqrt(radicando)
    print '|', nombre, '| = sqrt(', radicando, ') = ', "%5.2f" % longitud
    return longitud


def normaliza(a):  # a es un vector
    longitud = modulo('a', a)
    u = []
    u = a / longitud
    return u

a = np.array([3, -1, 5])
print 'a = ', a
u = normaliza(a)
print 'u = ', u
modulo('u', u)
