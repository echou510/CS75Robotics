# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10r.py
calcula la divergencia de un vector
"""

import sympy as sy

x, y, z = sy.symbols('x, y, z')
sy.init_printing(use_unicode=True)

#vector1 = sy.Matrix([[x + z, y + z, x ** 2 + z]])
#vector1 = sy.Matrix([[x ** 2 + y, y ** 2 + z, z ** 2 + x]])
vector1 = sy.Matrix([[x, y, z]])
vector2 = sy.Matrix([[-x, -y, -z]])
#vector3 = sy.Matrix([[z, x, y]])
#vector3 = sy.Matrix([[1, 2, 3]])
#vector3 = sy.Matrix([[-y, x, 0]])
vector3 = sy.Matrix([[x, y, 0]])


def divergencia(v):
    return sy.diff(v[0], x) + sy.diff(v[1], y) + sy.diff(v[2], z)

print 'v = ', vector1
print 'div v = ', divergencia(vector1)
print
print 'v = ', vector2
print 'div v = ', divergencia(vector2)
print
print 'v = ', vector3
print 'div v = ', divergencia(vector3)
