# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10m.py
gradiente de un vector
"""

import sympy as sy

x, y, z, k = sy.symbols('x, y, z, k')
sy.init_printing(use_unicode=True)

k = 0.03
z = k * (x ** 2 - y ** 2)
print 'z = ', sy.simplify(z)


def gradiente(a, dimension):  # a es una funcion escalar
    vectorgrad = []
    radicando = 0.0
    vectorgrad.append(sy.diff(a, x))
    if dimension == 2:
        vectorgrad.append(sy.diff(a, y))
    if dimension == 3:
        vectorgrad.append(sy.diff(a, z))
    for i in range(0, dimension):
        radicando += vectorgrad[i] ** 2
    modulo = sy.sqrt(radicando)
    resultado = {'vectorgrad': vectorgrad, 'modulo': modulo}
    return resultado

gradz = gradiente(z, 2)
print 'grad z = ', gradz.get('vectorgrad')
modz = gradz.get('modulo')
print '|z| = ', modz
print '|z| = ', sy.simplify(modz)
