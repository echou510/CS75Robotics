# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10l.py
lineas de nivel: z = potencial electrico
"""

import matplotlib.pyplot as plt
import numpy as np

r = np.linspace(0.2, 0.5, 200)
t = np.linspace(0, 2 * np.pi, 200)
r, t = np.meshgrid(r, t)

k = 9.0 * 1e9  # constante electrostatica
q = 2.0 * 1e-9  # carga puntual en culombios
z = k * q / r

CS = plt.contour(r * np.cos(t), r * np.sin(t), z, 10, linewidths=2)
plt.plot(0, 0, 'o', color='grey')
plt.clabel(CS, inline=1, fmt='%5.0f', fontsize=10)
plt.title('Lineas de potencial')
plt.axis('equal')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
