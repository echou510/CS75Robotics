# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10f.py
"""

import numpy as np
import matplotlib.pyplot as plt

print 'Tipos de datos de partida:'
print '1 - P0 y el vector normal a la recta'
print '2 - P0 y el vector director de la recta'
print '3 - P0 y P1'
print
tipo = int(raw_input('Escribe el tipo de problema: '))
print ('Escribe las coordenadas del punto P0, ',
       'separadas por un espacio:')
sp0 = raw_input()
p0 = map(float, sp0.split())
print 'P0: ', p0
print
puntomax = p0[0] + 1
puntomin = p0[0] - 1
oblicua = False


def seguir(director):  # sigue si la recta es oblicua
    if r[0] == 0:
        oblicua = False
        mensaje = 'recta vertical x = ' + str(p0[0])
    elif r[1] == 0:
        oblicua = False
        mensaje = 'recta horizontal y = ' + str(p0[1])
    else:
        oblicua = True
        mensaje = 'recta oblicua'
    resultado = {'oblicua': oblicua, 'mensaje': mensaje}
    return resultado

if tipo == 1:
    print ('Escribe las coordenadas del vector normal, ',
           'separadas por un espacio:')
    svn = raw_input()
    vn = map(float, svn.split())
    print
    if vn[0] == 0:
        oblicua = False
        print 'recta horizontal y = ' + str(p0[1])
    elif vn[1] == 0:
        oblicua = False
        print 'recta vertical x = ' + str(p0[0])
    else:
        oblicua = True
        # un vector normal a r, eligiendo ry=1
        r = [-1.0 * vn[1] / vn[0], 1.0]
if tipo == 2:
    print ('Escribe las coordenadas del vector director, ',
           'separadas por un espacio:')
    sr = raw_input()
    r = map(float, sr.split())
    print
    sigue = seguir(r)
    oblicua = sigue.get('oblicua')
    if oblicua:
        # un vector normal a r, eligiendo B=1
        vn = [-1.0 * r[1] / r[0], 1.0]
    else:
        print sigue.get('mensaje')
if tipo == 3:
    print ('Escribe las coordenadas del punto P1, ',
           'separadas por un espacio:')
    sp1 = raw_input()
    p1 = map(float, sp1.split())
    print 'P1: ', p1
    print
    if puntomax < p1[0]:
        puntomax = p1[0]
    if puntomin > p1[0]:
        puntomin = p1[0]
    r = [0, 0]
    r[0] = p1[0] - p0[0]
    r[1] = p1[1] - p0[1]
    sigue = seguir(r)
    oblicua = sigue.get('oblicua')
    if oblicua:
        vn = [-1.0 * r[1] / r[0], 1.0]  # un vector normal a r, eligiendo B=1
        puntomax = max([p0[0], p1[0]]) + 1
        puntomin = min([p0[0], p1[0]]) - 1
    else:
        print sigue.get('mensaje')


def ecgeneral(vn, punto):  # datos: vector normal y un punto de la recta
    # vn y punto son arrays lineales de dimension 2
    A = vn[0]
    B = vn[1]
    C = -A * punto[0] - B * punto[1]
    resultado = {'A': A, 'B': B, 'C': C}
    return resultado


def ecreducida(ABC):  # datos: la ecuacion general de la recta
    if ABC[1] != 0:
        m = -1.0 * ABC[0] / ABC[1]
        n = -1.0 * ABC[2] / ABC[1]
    else:
        m = 0
        n = 0
    resultado = {'m': m, 'n': n}
    return resultado


if oblicua:
    parametro = unichr(0x3bb).encode('utf-8')
    print 'Vector director de la recta: ', r
    #vn = [-1.0 * r[1] / r[0], 1.0]  # un vector normal a r, eligiendo B=1
    ecgen = ecgeneral(vn, p0)
    ABC = [ecgen.get('A'), ecgen.get('B'), ecgen.get('C')]
    print 'Vector normal a la recta: ', vn
    print ('Ecuacion general de la recta: ' +
           "%.3f" % ABC[0] + 'x + ' + str(ABC[1]) +
           ' y + ' + "%.3f" % ABC[2] + ' = 0')
    ecred = ecreducida(ABC)
    print ('Ecuación reducida de la recta:  y = ' +
           "%.3f" % ecred.get('m') +
           'x + ' + "%.3f" % ecred.get('n'))
    print ('Ecuación vectorial de la recta: OP = ' +
           str(p0) + ' + ' + parametro + str(r))
    corteX = -1.0 * ecred.get('n') / ecred.get('m')
    corteY = ecred.get('n')
    print 'Ecuaciones paramétricas de la recta:'
    print 'x = ', p0[0], ' + ', r[0], parametro
    print 'y = ', p0[1], ' + ', r[1], parametro
    print
    print ('Corte con el eje X en el punto [',
           "%.3f" % corteX, ', 0]')
    print ('Corte con el eje Y en el punto [0, ',
           "%.3f" % corteY, ']')
    #grafica

    def f(x):
        return ecred.get('m') * x + ecred.get('n')
    ur = [0, 0]
    modr = np.sqrt(r[0] ** 2 + r[1] ** 2)
    ur[0] = r[0] / modr
    ur[1] = r[1] / modr
    plt.arrow(0, 0, ur[0], ur[1], width=0.02, fc='r',
              ec='none', length_includes_head=True, ls='solid')
    uvn = [0, 0]
    modvn = np.sqrt(vn[0] ** 2 + vn[1] ** 2)
    uvn[0] = vn[0] / modvn
    uvn[1] = vn[1] / modvn
    plt.arrow(0, 0, uvn[0], uvn[1], width=0.02, fc='g',
              ec='none', length_includes_head=True, ls='solid')
    minimos = [-1.1 * corteX, 1.1 * corteX, ur[0] - 1,
               uvn[0] - 1, puntomin - 1]
    xmin = min(minimos)
    maximos = [-1.1 * corteX, 1.1 * corteX, ur[0] + 1,
               uvn[0] + 1, puntomax + 1]
    xmax = max(maximos)

    plt.plot([xmin, xmax], [f(xmin), f(xmax)], 'b-', lw=1.5)
    plt.ylabel('y')
    plt.xlabel('x')
    plt.axhline(color='grey', lw=1)
    plt.axvline(color='grey', lw=1)
    plt.plot(p0[0], p0[1], 'ro')
    if tipo == 3:
        plt.plot(p1[0], p1[1], 'ko')
    plt.xlim(xmin, xmax)
    plt.axis('equal')
    plt.show()
