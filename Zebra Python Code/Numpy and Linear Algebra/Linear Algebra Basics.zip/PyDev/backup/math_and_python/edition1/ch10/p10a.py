# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10a.py
producto escalar de vectores
"""

import sympy as sy

a1, a2, a3, b1, b2, b3 = sy.symbols('a1, a2, a3, b1, b2, b3')
sy.init_printing(use_unicode=True)

vectorfila = sy.Matrix([[1, 2, 3]])
vectorcolumna = sy.Matrix([-1, 5, 10])
print 'a = ', vectorfila
print 'b = '
print vectorcolumna
print 'a·b = ', vectorfila * vectorcolumna
print
a = sy.Matrix([[a1, a2, a3]])
b = sy.Matrix([b1, b2, b3])
print 'a = ', a
print 'b = '
print b
print 'a·b = ', a * b
