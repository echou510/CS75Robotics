# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10i.py
representa tiro parabolico: r, v, a
"""

import numpy as np
import matplotlib.pyplot as plt
#from matplotlib import rc
#
#rc('font', **{'family': 'serif', 'serif': ['Times']})
#rc('text', usetex=True)

#representa la curva utilizando ecuaciones de física
y0 = 0.0
v0 = 35.0
g = -9.81
angulo = 50.0
#vy = v0y - g * t
#tiempo en alcanzar el punto más alto: tsuelo / 2
#vx = v0x
#x = v0x * t
#y = y0 + v0y*t + 0.5*g*t**2
#y = y0 + v0y*x/v0x + (0.5*g/v0x**2)*x**2
#ymax = y0 + v0y*tsuelo/2 + 0.5*g*(tsuelo/2)**2
alcancemaximo = 0
alturamaxima = 0
print 'angulo     ymax     alcance    tiempo'
#for j in range(0, 4):
alfa = np.deg2rad(angulo)
v0y = v0 * np.sin(alfa)
tsuelo = - 2 * v0y / g
v0x = v0 * np.cos(alfa)
alcance = - (v0 ** 2) * np.sin(2 * alfa) / g
ymax = y0 + (v0y * tsuelo / 2) + (0.5 * g * (tsuelo / 2) ** 2)
if alcance > alcancemaximo:
    alcancemaximo = alcance
if ymax > alturamaxima:
    alturamaxima = ymax
print (angulo, "%7.2f" % ymax,
       "%7.2f" % alcance, "%7.2f" % tsuelo)


def f(x, beta):
    v0x = v0 * np.cos(np.deg2rad(beta))
    #coeficientes a0, a1,... an
    a = [y0, (np.tan(np.deg2rad(beta))), ((0.5 * g) / (v0x ** 2))]
    y = a[0]
    i = 1
    while i < len(a):
        y = y + a[i] * x ** i
        i += 1
    return y


numpuntos = 300
x = np.linspace(0, np.ceil(alcancemaximo), numpuntos)
y = np.zeros(numpuntos, float)
for i in range(0, numpuntos):
    y[i] = f(x[i], angulo)

plt.plot(x, y, 'b--', lw=2, label='$38$')
#traza r(t)
#valores de t para los que se va a representar el vector
puntos = [tsuelo / 5, tsuelo / 3, tsuelo / 2,
          2 * tsuelo / 3, 3 * tsuelo / 4, 5 * tsuelo / 6]


def xvector(tiempo):
    return v0x * tiempo

# la derivada de xvector es v0x
vx = v0x
# la derivada de vx es 0
ax = 0.0


def yvector(tiempo):
    return y0 + v0y * tiempo + 0.5 * g * tiempo ** 2


def vy(tiempo):
    return v0y + g * tiempo

# la derivada de vy es g
ay = g

for i in range(0, 6):
    t = puntos[i]
    plt.arrow(0, 0, xvector(t), yvector(t), width=0.5, fc='k',
              ec='none', length_includes_head=True, lw=0.5)
    plt.arrow(xvector(t), yvector(t), vx, vy(t), width=0.5, fc='g',
              ec='none', length_includes_head=True, lw=0.5)
    plt.arrow(xvector(t), yvector(t), ax, ay, width=0.5, fc='r',
              ec='none', length_includes_head=True, lw=0.5)


plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
#plt.ylim(0, 1.05 * ymax)
#plt.legend(('$38\,^{\circ}$',), loc='best')
plt.axis('equal')
plt.xlim(-0.5, 1.05 * alcance)
plt.ylabel('y')
plt.xlabel('x')
plt.show()
