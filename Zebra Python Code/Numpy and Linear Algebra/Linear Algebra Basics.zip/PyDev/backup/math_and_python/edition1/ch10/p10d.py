# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p10d.py
angulo de dos vectores
"""

import sympy as sy
import numpy as np


def radicando(a):
    radicando = 0.0
    dimension = len(a)
    for i in range(0, dimension):
        radicando = radicando + a[i] ** 2
    return radicando

#a = sy.Matrix([[1, 2, 3]])
#b = sy.Matrix([-1, 5, 10])
#b = 2 * sy.Transpose(a)  # siguiente ejemplo

a = sy.Matrix([[1, 0, 0]])
b = sy.Matrix([0, 5, 0])

print 'a = ', a
print 'b = '
print b
print ('coseno{a,b} = ' + str(a * b) + ' / (sqrt(' + str(radicando(a)) +
       ')sqrt(' + str(radicando(b)) + '))')
coseno = (a * b) / (sy.sqrt(radicando(a)) * sy.sqrt(radicando(b)))
print 'coseno{a,b} = ', float(coseno[0])
radianes = sy.acos(sy.N(coseno[0]))


def gradosagms(grados):
    if np.abs(grados - np.trunc(grados)) > 0:
        g = np.floor(grados)
    else:
        g = grados
    m = np.floor((grados - g) * 60)
    s = round((((grados - g) * 60) - m) * 60)
    if s == 60:
        s = 0
        m += 1
    if m == 60:
        m = 0
        g += 1
    strgms = str(g) + 'º ' + str(m) + "' " + "%5.2f" % s + "''"
    return strgms

grados = float(sy.N(sy.mpmath.degrees(radianes)))
print 'angulo{a,b} = ', radianes, 'radianes = ', gradosagms(grados)
