# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
ph.py
'''

letra = raw_input('Escribe una letra: ')
print letra

if (letra in 'aeiou'):
    print 'Has escrito la vocal: ', letra
elif letra in 'bcdfghjklmnñpqrstvwxyzBCDFGHJKLMNÑPQRSTVWXYZ':
    print 'Has escrito una consonante: ', letra
elif letra in '1234567890':
    print 'Has escrito un número: ', letra
else:
    print letra, ' no es una letra ni un número'
