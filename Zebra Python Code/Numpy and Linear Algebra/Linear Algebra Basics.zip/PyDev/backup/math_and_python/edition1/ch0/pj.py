# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pj.py
'''

lista = ''
for i in range(0, 101, 5):
    lista = lista + str(i) + ','
print lista
