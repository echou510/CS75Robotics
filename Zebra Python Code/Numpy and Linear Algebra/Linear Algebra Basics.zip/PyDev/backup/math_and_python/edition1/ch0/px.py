# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
px.py
Calcula estadisticos a partir de una lista de datos
"""

import numpy as np
import matplotlib.pyplot as plt

''' textos de: Cantar de Mío Cid, El Libro del Buen Amor,
Don Quijote de la Mancha, Artículos de Larra, El Árbol de la Ciencia,
Comedias de Lope de Vega, Trafalgar, textos de Valle-Inclán,
La Regenta, La Barraca, textos de Espronceda, El Buscón de Quevedo,
España Invertebrada, El Hombre y la Gente,
Constitución de 1812, Constitución de 1978, Viaje a la Alcarria,
textos de Miguel Delibes, Revista Legión, Alonso de Contreras,
Novelas Ejemplares de Cervantes, La Araucana, Selección de Sonetos,
Selección de canciones, transcripción de programas de radio.'''

vocales = [58469, 15337, 761836, 183369, 133620,
           59026, 108791, 48222, 649917, 118900,
           26860, 84255, 67336, 189238, 38380,
           44441, 87602, 55188, 58763, 111772,
           368946, 128287, 2076, 10229, 42310]
consonantes = [70422, 18618, 878789, 212737, 153872,
               68434, 126670, 57673, 744313, 141157,
               32269, 97561, 78490, 219277, 46588,
               54082, 101642, 63386, 70190, 128058,
               423469, 151592, 2426, 11868, 49663]

nvocales = np.sum(vocales)
nconsonantes = np.sum(consonantes)
print ('Muestra de ' + str(nvocales + nconsonantes) +
       ' letras, de las cuales ' + str(nvocales) + ' son vocales.')
pormil = np.zeros(25, float)
for i in range(0, 25):  # vocales por cada mil letras
    pormil[i] = float("%8.2f" % (1000.0 * vocales[i] /
                      (vocales[i] + consonantes[i])))
print 'datos: '
print pormil
creciente = np.sort(pormil)
print 'datos ordenados de forma creciente: '
print creciente
#max, min, recorrido, numero de datos
maximo = float("%8.2f" % np.max(pormil))
print 'máximo: ', maximo
minimo = float("%8.2f" % np.min(pormil))
print 'mínimo: ', minimo
recorrido = float("%8.2f" % (maximo - minimo))
print 'recorrido: ', recorrido
n = len(pormil)
print 'n: ', n
suma = np.sum(pormil)
print 'suma: ', suma

nintervalos = 11  # 10 + 1
amplitud = np.ceil((recorrido / (nintervalos - 1)))  # 2
print 'amplitud de los intervalos: ', amplitud

liminf = np.trunc(np.min(pormil)) - (amplitud / 2.0)
intervalos = np.zeros(nintervalos, int)
intervalos[0] = liminf  # -1
marcasclase = np.zeros(nintervalos, float)
marcasclase[0] = liminf + (amplitud / 2.0)
for i in range(1, nintervalos):
    intervalos[i] = intervalos[i - 1] + amplitud
for i in range(1, nintervalos - 1):
    marcasclase[i] = float("%8.2f" %
                           (marcasclase[i - 1] + amplitud))
print str(nintervalos - 1) + ' intervalos: ' + str(intervalos)
print 'marcas de clase: ' + str(marcasclase)
fintervalos = np.zeros(nintervalos - 1, int)
for i in range(1, nintervalos):
    for j in range(0, n):
        if ((creciente[j] < intervalos[i]) and (creciente[j] >= intervalos[i - 1])):
            fintervalos[i - 1] += 1
print 'f de los intervalos: ', fintervalos
#print creciente

#medidas de tendencia central
mediaaritmetica = float("%8.2f" % np.mean(pormil))
print 'media aritmética: ', mediaaritmetica
mediana = float("%8.2f" % np.median(pormil))
print 'mediana: ', mediana
producto = 1.0
for i in range(0, n):
    producto = producto * creciente[i]
mediageometrica = float("%8.2f" % producto ** (1.0 / n))
print 'media geométrica: ', mediageometrica
print 'la media aritmética debe ser mayor que la geométrica:'
print mediaaritmetica, ' > ', mediageometrica
#medidas de variabilidad
diferencias = np.zeros(25, float)
for i in range(0, n):
    diferencias[i] = float("%8.2f" %
                    (np.absolute(pormil[i] - mediaaritmetica)))
print '|xi - media|: ', diferencias
desviacionmedia = float("%8.2f" % (np.sum(diferencias) / n))
print ('desviación media de los datos sin agrupar: ' +
        str(desviacionmedia))
diferenciasAG = np.zeros(nintervalos - 1, float)
for i in range(0, nintervalos - 1):
    diferenciasAG[i] = float("%8.2f" % (fintervalos[i] *
                        np.absolute(marcasclase[i] - mediaaritmetica)))
print 'fi |marcai - media|: ', diferenciasAG
desviacionmediaAG = float("%8.2f" % (np.sum(diferenciasAG) / nintervalos))
print 'desviación media de los datos agrupados: ', desviacionmediaAG
desviaciontipica = float("%8.2f" % np.std(pormil))
print 'desviacion típica s: ', desviaciontipica
varianza = float("%8.2f" % np.var(pormil))
print 'varianza s2: ', varianza
print 'Si los datos siguen la distribución normal,'
print 'la desviación media debe ser aproximadamente (4 * s / 5):'
print ('desviación media: ' + str(desviacionmedia) +
       '; 4s/5: ' + str(0.8 * desviaciontipica))
if mediaaritmetica != 0:
    variacionPearson = (100 * desviaciontipica / mediaaritmetica)
    print ('coefificente de variación de Pearson: C.V. =' +
            "%4.2f" % variacionPearson)
asimetriaPearson = float("%8.2f" %
     (3 * (mediaaritmetica - mediana) / desviaciontipica))
if asimetriaPearson == 0:
    frase1 = 'la media aritmética coincide con la mediana'
elif asimetriaPearson < 0:
    frase1 = 'la media aritmética es menor que la mediana'
else:
    frase1 = 'la media aritmética es mayor que la mediana'
print 'asimetría de Pearson: ', asimetriaPearson, ': ', frase1
m4 = 0
for i in range(0, n):
    m4 += diferencias[i] ** 4
m4 = float("%8.2f" % (m4 / n))
print 'm4 = ', m4
print ('a: C.V. =' +
            "%4.2f" % variacionPearson)
curtosis = float("%8.2f" % (m4 / (varianza ** 2)))
if curtosis == 0:
    frase2 = 'mesocúrtica, curva normal'
elif curtosis < 0:
    frase2 = 'platicúrtica'
else:
    frase2 = 'leptocúrtica'
print 'curtosis = ', curtosis, ' : la curva es ', frase2

#grafica
fig, ax = plt.subplots(1)
textstr = (
'$media=%.2f$\n$\mathrm{mediana}=%.2f$\n$\sigma=%.2f$' %
            (mediaaritmetica, mediana, desviaciontipica)
            )
props = dict(boxstyle='round', facecolor='#FCE945', alpha=0.6)
ax.text(0.05, 0.95, textstr, transform=ax.transAxes,
        fontsize=14, verticalalignment='top', bbox=props)
binsx = np.linspace(intervalos[0], intervalos[nintervalos - 1],
                    nintervalos)
ax.hist(pormil, binsx, alpha=0.75, color='#F2AE04')

plt.plot([mediaaritmetica, mediaaritmetica],
         [0, np.max(fintervalos) + 0.3], 'r', lw=2.5)
plt.text(mediaaritmetica, np.max(fintervalos) + 0.5,
         '$media=%.2f$' % mediaaritmetica,
         horizontalalignment='left', color='red')
plt.plot([mediana, mediana],
         [0, np.max(fintervalos) + 0.1], 'g', lw=2.5)
plt.text(mediana, np.max(fintervalos) + 0.2,
         '$mediana=%.2f$' % mediana,
         horizontalalignment='left', color='green')

plt.plot([np.min(intervalos) - 1, marcasclase[0]],
         [0, fintervalos[0]], 'k--', lw=2)
for i in range(0, (len(fintervalos) - 1)):
    plt.plot([marcasclase[i], marcasclase[i + 1]],
         [fintervalos[i], fintervalos[i + 1]], 'k--', lw=2)

plt.ylim(0, np.max(fintervalos) + 1)
plt.xlim(np.min(intervalos) - 1, np.max(intervalos) + 1)
plt.grid(axis='y')
xticks = intervalos
plt.xticks(xticks)
plt.show()
