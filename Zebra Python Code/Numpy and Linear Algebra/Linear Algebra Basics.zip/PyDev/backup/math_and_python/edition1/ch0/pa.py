# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
pa.py
"""

import itertools

elementos = ['a', 'e', 'i', 'o', 'u']
permutaciones = list(itertools.permutations(elementos))
resultado = ''
for permutacion in permutaciones:
    palabra = ''
    for i in range(0, 5):
        palabra += permutacion[i]
    resultado += palabra + ', '
resultado = resultado[0:len(resultado) - 2]
print resultado
