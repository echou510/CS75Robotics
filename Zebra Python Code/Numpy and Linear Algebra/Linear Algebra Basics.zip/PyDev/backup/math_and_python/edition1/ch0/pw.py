# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
pw.py
graficas de textos
"""

import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
xticks = ['$a$', '$e$', '$i$', '$o$', '$u$',
          '$b$', '$c$', '$\c{c}$', '$d$', '$f$',
          '$g$', '$h$', '$j$', '$k$', '$l$',
          '$m$', '$n$', '$\~{n}$', '$p$', '$q$',
          '$r$', '$s$', '$t$', '$v$', '$w$',
          '$x$', '$y$', '$z$']
x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
     16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]
cesar = [8.088, 11.861, 11.304, 5.631, 8.353,
         1.659, 3.905, 0.0, 2.659, 0.906,
         1.101, 0.712, 0.0, 0.001, 2.846,
         5.143, 6.394, 0.0, 2.827, 1.809,
         6.699, 8.009, 8.357, 1.118, 0.0,
         0.614, 0.004, 0.001]
cid = [13.503, 12.34, 4.757, 10.654, 4.11,
       1.187, 2.568, 1.303, 5.735, 1.059,
       1.232, 0.557, 0.121, 0.0, 5.637,
       2.795, 7.927, 0.0, 1.795, 1.232,
       6.424, 8.949, 3.104, 0.844, 0.0,
       0.257, 1.382, 0.528]
hita = [12.254, 13.647, 4.83, 9.895, 4.541,
        1.263, 2.486, 1.69, 5.004, 1.137,
        1.252, 0.448, 0.386, 0.0, 5.275,
        2.659, 7.392, 0.433, 2.288, 1.582,
        6.836, 7.475, 3.805, 1.352, 0.0,
        0.177, 1.113, 0.78]
quijote = [12.221, 13.97, 5.49, 9.906, 4.849,
           1.472, 3.623, 0.0, 5.317, 0.462,
           1.05, 1.214, 0.642, 0.0, 5.433,
           2.722, 6.61, 0.258, 2.162, 1.98,
           6.154, 7.663, 3.764, 1.088, 0.0,
           0.023, 1.531, 0.396]
larra = [12.148, 14.059, 6.061, 9.424, 4.601,
         1.491, 3.999, 0.004, 4.961, 0.581,
         1.027, 1.167, 0.435, 0.003, 5.242,
         2.959, 6.736, 0.226, 2.526, 1.441,
         6.414, 7.929, 4.016, 1.006, 0.002,
         0.114, 1.101, 0.328]
baroja = [13.607, 13.039, 6.43, 8.827, 4.574,
          1.744, 4.095, 0.0, 5.124, 0.588,
          1.02, 1.144, 0.543, 0.007, 5.797,
          2.626, 6.909, 0.212, 2.282, 1.104,
          6.5, 7.216, 4.026, 1.082, 0.003,
          0.125, 1.006, 0.371]
crusoe = [8.207, 12.293, 6.716, 7.945, 2.791,
          1.546, 2.174, 0.0, 4.646, 2.355,
          1.984, 6.728, 0.082, 0.68, 3.578,
          2.773, 6.697, 0.0, 1.537, 0.066,
          5.457, 5.777, 9.827, 1.096, 2.811,
          0.115, 2.08, 0.038]
media = []
for i in range(0, 28):
    promedio = float("%7.3f" % ((cid[i] + hita[i] + quijote[i] +
                     larra[i] + baroja[i]) / 5))
    media.append(promedio)
print media
izquierda = (media[0] + media[1] + media[5] + media[6] +
             media[8] + media[9] + media[10] + media[19] +
             media[20] + media[21] + media[22] + media[23] +
             media[24] + media[25] + media[27])
print 'castellano: teclado izquierdo: ', izquierda
print 'castellano: teclado derecho: ', 100 - izquierda

leftkeys = (crusoe[0] + crusoe[1] + crusoe[5] + crusoe[6] +
            crusoe[8] + crusoe[9] + crusoe[10] + crusoe[19] +
            crusoe[20] + crusoe[21] + crusoe[22] + crusoe[23] +
            crusoe[24] + crusoe[25] + crusoe[27])
print 'inglés: teclado izquierdo: ', leftkeys
print 'inglés: teclado derecho: ', 100 - leftkeys
plt.plot(x, media, color='#F00707', lw=1.5)
plt.plot(x, crusoe, color='#07A8F0', lw=1.5)
plt.plot(x, cesar, color='#000000', lw=1.5)
#plt.plot(x, cesar, 'k-', marker='o')
'''plt.plot(x, cid, 'r', lw=1)
plt.plot(x, hita, 'o-', lw=1)
plt.plot(x, quijote, 'b-', lw=1)
plt.subplots_adjust(left=0.2)'''

p1, = plt.plot(x, cid, 'bo')
p2, = plt.plot(x, hita, 'k+')
p3, = plt.plot(x, quijote, 'r*')
p4, = plt.plot(x, larra, 'yo')
p5, = plt.plot(x, baroja, 'go')
plt.ylabel('porcentaje de cada letra')
plt.xlabel('letras')
plt.legend(('castellano', 'english', 'latin',
            'cid', 'hita', 'quijote', 'larra',
            'baroja'), loc='best')
plt.grid(axis='x')
plt.xticks(x, xticks)
#plt.yticks(y,yticks)
#ax.set_ylim(0.5,max(y))
ax.set_xlim(-1, 28)
plt.show()
