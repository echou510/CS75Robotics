# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
"""

print 'hola'
