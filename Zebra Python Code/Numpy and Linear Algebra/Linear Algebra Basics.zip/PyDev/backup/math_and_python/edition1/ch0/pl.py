# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pl.py
'''
import numpy as np
import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
screen = tt.getscreen()
screen.colormode(255)
r = 221
g = 25
b = 127
tt.pencolor(r, g, b)
tt.speed('fastest')
grados = 0
a = 5
tt.pensize(5)
for grados in range(0, 360 * 5):
    radianes = np.deg2rad(grados)
    r = a * radianes
    x = int(r * np.cos(radianes))
    y = int(r * np.sin(radianes))
    tt.setpos(x, y)
    tt.forward(r - 5)
    tt.pendown()
    tt.forward(5)
    tt.penup()
    tt.left(1)
tt.hideturtle()
