# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pk.py
'''
import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
screen = tt.getscreen()
screen.colormode(255)
r = 255
g = 50
b = 30
tt.pencolor(r, g, b)
tt.pensize(3)
tt.write('0')
for i in range(0, 45):
    tt.forward(10 * i)
    tt.left(90)
    tt.pencolor('black')
    tt.write(str(i))
    if i < 15:
        g += 12
    elif i < 30:
        b += 12
    else:
        r -= 12
    #print r, g, b
    tt.pencolor(r, g, b)
tt.hideturtle()
