# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pq.py
'''

numero = int(raw_input('Escribe un numero natural: '))
resultado = str(numero) + ' = '
factorPrimo = 2
divisiones = 0

while factorPrimo <= numero:
    resto = numero % factorPrimo
    divisiones += 1
    if resto == 0:
        resultado = resultado + str(factorPrimo) + '.'
        numero = numero / factorPrimo
        divisiones += 1
    else:
        if factorPrimo > 2:
            factorPrimo += 2
        else:
            factorPrimo += 1
resultado = resultado.rstrip('.')
print resultado
print 'Se han realizado ', divisiones, ' divisiones.'
