# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pd.py
'''

import numpy as np

pi = np.pi
print pi
print str(pi)
print "%10.2f" % pi
print "%10.8f" % pi
print np.trunc(pi)
print "%20.18f" % pi
