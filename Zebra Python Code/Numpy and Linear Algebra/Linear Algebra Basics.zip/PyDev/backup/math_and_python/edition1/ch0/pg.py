# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pg.py
'''

numero = int(raw_input('Escribe un número entero: '))

if (numero % 2) == 0:
    print 'El número ', numero, ' es par'
else:
    print 'El número ', numero, ' es impar'
