# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pm.py
'''

import numpy as np
import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
tt.speed('fastest')
a = 200
grados = 0
while grados <= 180:
    radianes = np.deg2rad(grados)
    r = a * np.sin(3 * radianes)
    x = int(r * np.cos(radianes))
    y = int(r * np.sin(radianes))
    y2 = - y
    tt.goto(x, y)
    tt.pendown()
    tt.pencolor('blue')
    tt.dot(4)
    tt.penup()
    tt.goto(x, y2)
    tt.pendown()
    tt.pencolor('red')
    tt.dot(4)
    tt.penup()
    grados += 0.5
tt.hideturtle()
