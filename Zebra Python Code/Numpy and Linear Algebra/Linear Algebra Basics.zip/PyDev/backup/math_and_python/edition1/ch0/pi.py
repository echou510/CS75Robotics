# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pi.py
'''

lista = ''
for i in range(1, 20):
    lista = lista + str(i) + ','
print lista
