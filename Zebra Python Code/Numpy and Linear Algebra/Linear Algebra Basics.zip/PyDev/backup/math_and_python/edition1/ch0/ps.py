# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
ps.py
lee tabla densidades.csv e interpola
'''

import csv
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np

d = []
gl = []
with open('densidades.csv', 'rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
    fila = 0
    for row in spamreader:
        if fila > 0:
            d.append(int(row[0]))
            gl.append(int(row[1]))
        #print ', '.join(row)
        fila += 1
print d
print gl

# interpolacion lineal
delta = 5  # distancia entre los datos de densidades
densidad = 1068  # valor de densidad experimental
i = 0
for dato in d:
    if dato < densidad:
        dant = dato
        j = i
    i += 1
print 'densidad anterior: ', dant
glant = gl[j]
print 'azucares anterior: ', glant
f = np.round(glant + ((densidad - dant) * (gl[j + 1] - gl[j]) / 5.0), 1)
print 'densidad medida: ', densidad
print 'azucares interpolado linealmente: ', "%.1f" % f

#ajuste por minimos cuadrados
print 'ajuste por minimos cuadrados:'
slope, intercept, r_value, p_value, std_err = stats.linregress(d, gl)
print 'r^2: ', "%8.6f" % (r_value ** 2)
print ('recta: y =  ' + "%6.2f" % slope + 'x + ' + "%6.2f" % intercept)
print 'densidad medida: ', densidad
f2 = np.round(slope * densidad + intercept, 1)
print ('azucares por ajuste de minimos cuadrados a una recta: ' + "%.1f" % f2)

#grafica
f0 = slope * d[0] + intercept
fn = slope * d[-1] + intercept
plt.plot([d[0], d[-1]], [f0, fn], 'k-', lw=1.5)  # ajuste a una recta
plt.plot(d, gl, 'wo')
plt.xlim(1010, 1180)
plt.plot(densidad, f2, 'ro')
plt.plot([densidad, densidad], [0, f2], 'r--', lw=1.0)
plt.plot([1010, densidad], [f2, f2], 'r--', lw=1.0)
plt.xlabel('densidad (g/l)')
plt.ylabel('azucares (g/l)')
plt.show()
