# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pn.py
'''

import numpy as np

p1 = np.poly1d([1, 2, 3])
print 'p1 = '
print p1
print 'valor del polinomio p1 para x=5:', np.polyval(p1, 5)
p2 = np.poly1d([1, -2, 1, 3, 2])
print 'p2 = '
print p2
print 'suma: '
print np.polyadd(p1, p2)
print 'diferencia p2-p1:'
print np.polysub(p2, p1)
print 'producto: '
p = np.polymul(p1, p2)
print p
print 'división de polinomios: p2/p1: '
cociente = np.polydiv(p2, p1)
print cociente
print 'cociente = '
print cociente[0]
print 'resto = '
print cociente[1]
print 'p2 y sus derivadas: '
for i in range(0, 6):
    print np.polyder(p2, m=i)
print 'integral de la primera derivada de p2:'
#si no se especifica, la constante de integración es cero
p2int = np.polyint([4, -6, 2, 3])
print np.poly1d(p2int)
print 'binomios y su producto: '
polinomio = np.poly1d([0, 1])
for j in range(-2, 2):
    print np.poly1d([1, j])
    polinomio = np.polymul(polinomio, np.poly1d([1, j]))
print polinomio
print 'raices del polinomio'
print np.sort(np.roots(polinomio))
