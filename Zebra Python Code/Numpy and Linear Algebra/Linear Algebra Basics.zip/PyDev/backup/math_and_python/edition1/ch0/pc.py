# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pc.py
'''

e1 = 23
e2 = -2
r1 = 0.01
r2 = 2.5e-3
print 'operaciones con números enteros:'
print 'e1 + e2 = ', e1 + e2
print 'e1 - e2 = ', e1 - e2
print '-e2 = ', -e2
print 'e1 * e2 = ', e1 * e2
print 'e2 elevado a 5 = ', e2 ** 5
print 'división de enteros: e1/e2 = ', e1 / e2
print ('división exacta de enteros: e1/e2 = ' +
       str(1.0 * e1 / e2))
print 'operaciones con números reales:'
print 'e1 * r1 = ', e1 * r1
print 'e1 / r1 = ', e1 / r1
print 'r1 / r2 = ', r1 / r2
print 'r2 elevado a 4 = ', r2 ** 4
print 'división: 7.5/2 = ', 7.5 / 2
print 'división truncada 7.5//2 = ', 7.5 // 2
print ('módulo: el resultado es el resto de la división:' +
       ' 7.5 % 2 = ' + str(7.5 // 2))
