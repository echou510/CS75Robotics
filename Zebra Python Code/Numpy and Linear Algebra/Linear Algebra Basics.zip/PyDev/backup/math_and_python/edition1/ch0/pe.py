# -*- coding: utf-8 -*-
'''
Matematicas y programacion en Python
© www.pysamples.com
pe.py
'''

x = 1
z = 100 * x
print 'z = 100x = ', z
z += 2
print 'z aumenta en 2 unidades: z+=2 : ', z
z -= 52
print 'z disminuye en 52 unidades: z-=2 : ', z
z *= 3
print 'z se triplica: z*=3 :', z
z /= 10
print 'z se divide entre 10: z/=10 : ', z
z %= 4
print 'el resto de dividir z entre 4: z%=4 : ', z
