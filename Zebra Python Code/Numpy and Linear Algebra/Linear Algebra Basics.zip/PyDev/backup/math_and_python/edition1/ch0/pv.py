# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
pv.py
recuento de letras de un archivo .txt
"""

vocales = 'aeiouAEIOUÁÉÍÓÚáéíóúüÜ'
consonantes = 'bBcCdDfFgGhHjJkKlLmMnNñÑpPqQrRsStTvVwWxXyYzZ'

dictvoc = {}
dictcons = {}

#utexto = unicode('bBcccEspaña y olé, áéíóúüUÚ ÑÑÑÑ?¿¡!')
#input = file('01cesar.txt')
#input = file('02miocid.txt')
#input = file('03hita.txt')
#input = file('04quijote.txt')
#input = file('05larra.txt')
#input = file('06baroja.txt')
#input = file('07crusoe.txt')
#input = file('lopedevega.txt')
#input = file('trafalgar.txt')
#input = file('valleinclan.txt')
#input = file('laregenta.txt')
#input = file('labarraca.txt')
#input = file('espronceda.txt')
#input = file('buscon.txt')
#input = file('invertebrada.txt')
#input = file('hombregente.txt')
input = file('constitucion1812.txt')
#input = file('constitucion1978.txt')
#input = file('alcarria.txt')
#input = file('delibes.txt')
#input = file('legion.txt')
#input = file('contreras.txt')
#input = file('novelasejemplares.txt')
#input = file('araucana.txt')
#input = file('sonetos.txt')
#input = file('canciones.txt')
#input = file('ser11m.txt')
texto = input.read()
utexto = unicode(texto, 'utf-8')

longitud = len(utexto)
#print utexto
print longitud

dictvoc['a'] = (utexto.count('a') + utexto.count('á') +
                utexto.count('A') + utexto.count('Á'))
dictvoc['e'] = (utexto.count('e') + utexto.count('é') +
                utexto.count('E') + utexto.count('É'))
dictvoc['i'] = (utexto.count('i') + utexto.count('í') +
                utexto.count('I') + utexto.count('Í'))
dictvoc['o'] = (utexto.count('o') + utexto.count('ó') +
                utexto.count('O') + utexto.count('Ó'))
dictvoc['u'] = (utexto.count('u') + utexto.count('ú') +
                utexto.count('U') + utexto.count('Ú') +
                utexto.count('ü') + utexto.count('Ü'))
'''print dictvoc
print dictvoc.keys()'''
nvocales = dictvoc.values()
numero_vocales = 0
for i in nvocales:
    numero_vocales += i
print 'total de vocales: ', numero_vocales
listavocales = dictvoc.items()
listavocales.sort()
print listavocales


def cuentacons(texto, letra):
    recuento = (texto.count(letra) +
                texto.count(letra.upper()))
    return recuento
dictcons['b'] = cuentacons(utexto, 'b')
dictcons['c'] = cuentacons(utexto, 'c')
dictcons['cedilla'] = cuentacons(utexto, 'ç')
dictcons['d'] = cuentacons(utexto, 'd')
dictcons['f'] = cuentacons(utexto, 'f')
dictcons['g'] = cuentacons(utexto, 'g')
dictcons['h'] = cuentacons(utexto, 'h')
dictcons['j'] = cuentacons(utexto, 'j')
dictcons['k'] = cuentacons(utexto, 'k')
dictcons['l'] = cuentacons(utexto, 'l')
dictcons['m'] = cuentacons(utexto, 'm')
dictcons['n'] = cuentacons(utexto, 'n')
enemays = 'Ñ'.encode('utf-8')
nene = utexto.count('ñ') + utexto.count(enemays)
dictcons['ntilde'] = nene
dictcons['p'] = cuentacons(utexto, 'p')
dictcons['q'] = cuentacons(utexto, 'q')
dictcons['r'] = cuentacons(utexto, 'r')
dictcons['s'] = cuentacons(utexto, 's')
dictcons['t'] = cuentacons(utexto, 't')
dictcons['v'] = cuentacons(utexto, 'v')
dictcons['w'] = cuentacons(utexto, 'w')
dictcons['x'] = cuentacons(utexto, 'x')
dictcons['y'] = cuentacons(utexto, 'y')
dictcons['z'] = cuentacons(utexto, 'z')

'''print dictcons
print dictcons.values()'''
nconsonantes = dictcons.values()
numero_consonantes = 0
for i in nconsonantes:
    numero_consonantes += i
print 'total de consonantes: ', numero_consonantes
listacons = dictcons.items()
listacons.sort()
print listacons
#------------------------------------------------
array100vocales = [0.0, 0.0, 0.0, 0.0, 0.0]
for i in range(0, 5):
    array100vocales[i] = float("%7.3f" %
                               (100.0 * listavocales[i][1] /
                               (numero_vocales + numero_consonantes)))
porcentajevocales = 0
for i in array100vocales:
    porcentajevocales += i
print array100vocales, ' = ', porcentajevocales, '%'
#------------------------------------------------
array100cons = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0]
for i in range(0, 23):
    array100cons[i] = float("%7.3f" %
                            (100.0 * listacons[i][1] /
                            (numero_vocales + numero_consonantes)))
porcentajecons = 0
for i in array100cons:
    porcentajecons += i
print array100cons, ' = ', porcentajecons, '%'
