# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p1d.py
triangulos pitagoricos
"""

import turtle as tt

tt.mode('logo')
tt.reset()
tt.home()
screen = tt.getscreen()
screen.colormode(255)
r = 41
g = 67
b = 220
tt.pencolor(r, g, b)
tt.speed('slow')
tt.pensize(2)
tt.penup()
tt.setpos(-250, -275)
print ' m  n     a     b     h'
print '________________________'
for m in range(2, 6):
    for n in range(1, m):
        x = m ** 2 - n ** 2
        y = 2 * m * n
        z = m ** 2 + n ** 2
        tt.penup()
        tt.right(90)
        tt.pendown()
        tt.forward(13 * x)
        tt.write(' ' + str(x))
        tt.left(90)
        tt.forward(13 * y)
        tt.write(str(y))
        tt.setpos(-250, -275)
        r += 20
        g -= 5
        b -= 20
        tt.pencolor(r, g, b)
        print "%2d" % m, "%2d" % n, "%5d" % x, "%5d" % y, "%5d" % z
tt.hideturtle()
