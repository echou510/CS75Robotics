# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p1b.py
criba de Eratostenes
"""

import numpy as np

n = 100000
print 'calculando para n< ' + str(n) + '. (unos 2 segundos para n=50000).'
lista = np.arange(1, n + 1, 2)
lista[0] = 2
longitud = len(lista)
#lista del numero 2 y los impares <= n
raiz = np.floor(np.sqrt(n))


def f(x):
    return x != 0

for i in range(0, longitud):  # elimina multiplos de 3, 5
    if lista[i] > 5:
        if (lista[i] % 3 == 0):
            lista[i] = 0
        elif (lista[i] % 5 == 0):
            lista[i] = 0


lista = filter(f, lista)
longitud = len(lista)
print 'Comprobando', str(longitud), 'números menores de ', str(n), ':'
#lista del numero 2 y los impares no múltiplos de 3 ni de 5 y menores que n
#print lista

i = 0
j = 1

#while i < longitud:
while i <= raiz:
    if lista[i] > 0:  # solo comprueba los impares que no han sido eliminados
        while j < (longitud):
            if lista[j] != 0:
                resto = lista[j] % lista[i]
                #print i, j, resto, ': ', lista[i], lista[j], resto
                if resto == 0:
                    lista[j] = 0
                    #print lista
            j += 1
        if (longitud >= 1000) and (i % 500 == 0):
            print 'calculando para ' + str(lista[i])
    i += 1
    j = i + 1

primos = filter(f, lista)
print 'lista de números primos: ', primos
print 'hay ' + str(len(primos)) + ' primos <= ' + str(n)
