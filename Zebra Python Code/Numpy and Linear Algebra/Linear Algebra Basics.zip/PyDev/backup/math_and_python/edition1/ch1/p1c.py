# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p1c.py
algoritmo de Euclides
"""

def mcdmcm(x, y):
    MCD = mcd(x, y)
    print 'El MCD es ' + str(MCD)
    if MCD > 1:
        mcm = x * y / MCD
    else:
        print str(x) + ' y ' + str(y), ' son primos relativos'
        mcm = x * y
    s = 'El mcm es ' + str(mcm)
    return s


def mcd(a, b):  # x > y
    if b == 0:
        return 0
    else:
        r = a % b
        print 'resto de ', a, '/', b, ' = ', r
        if r > 0:
            return mcd(b, r)
        else:
            return b

print mcdmcm(256, 60)
print mcdmcm(13, 8)
print mcdmcm(1470, 1155)
