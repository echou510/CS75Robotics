# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p1a.py

calcula 25 numeros racionales
entre dos racionales dados a,b
elige a al azar y elige b de manera que
el numerador de b es igual al de a+1
num_a/den_ab + (i/(den_ab*(n+1))) =
(num_a*(n+1)+i)/(den_ab*(n+1))
"""

import numpy as np

maximo = 1000
n = 30  # numero de numeros racionales a calcular

num_a = np.random.randint(1, maximo)
den_ab = np.random.randint(1, maximo)
num_b = num_a + 1
print ('a = ' + str(num_a) + '/' + str(den_ab) +
       ' = ' + "%.6f" % (1.0 * num_a / den_ab))
print ('b = ' + str(num_b) + '/' + str(den_ab) +
       ' = ' + "%.6f" % (1.0 * num_b / den_ab))
print 'b-a = 1/', den_ab
print ('q = (' + str(num_a) + '*' + str(n + 1) +
       '+ i)/(' + str(den_ab) + '*' +
       str(n + 1) + ')')
print ('q = (' + str(num_a * (n + 1)) +
       '+ i)/' + str(den_ab * (n + 1)))


def qdenso():
    for i in range(1, n + 1):
        num = num_a * (n + 1) + i
        den = den_ab * (n + 1)
        print ('(' + str(i) + ') ' + str(num) +
               '/' + str(den) + ' = ' +
               "%.8f" % (1.0 * num / den))

qdenso()
