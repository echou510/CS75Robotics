# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p3c.py
sucesión de Fibonacci
"""

diccionarioiter = {1: 1, 2: 1}


def fibiter(n):
    i = 3
    while i <= n:
        diccionarioiter[i] = (diccionarioiter[i - 1] +
                              diccionarioiter[i - 2])
        i += 1

fibiter(100)


def ponecoma(n):  # http://pp.com.mx/python/doc/ejemplos.html
    # Devuelve n como cadena con comas cada tres dígitos.
    s = str(n)
    pos = len(s)
    while pos > 3:
        pos = pos - 3
        s = s[:pos] + ',' + s[pos:]
    return s

for i, valor in diccionarioiter.iteritems():
    termino = ponecoma(valor)
    print '%3d %28s' % (i, termino)
