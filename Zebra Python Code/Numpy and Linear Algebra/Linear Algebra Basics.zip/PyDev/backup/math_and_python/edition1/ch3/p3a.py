# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p3a.py
progresión aritmética
"""

import numpy as np


def aritmetica(x1, n, d):
    x = np.zeros(n + 1, int)
    x[1] = x1
    suma = x[1]
    sucesion = str(x[1]) + ', '
    for i in range(2, n + 1):
        x[i] = x[i - 1] + d
        sucesion = sucesion + str(x[i]) + ', '
        suma = suma + x[i]
    sucesion = sucesion[0:len(sucesion) - 2]
    print 'x1 =', x[1], '; d =', d, '; n =', n
    print ('Los ' + str(n) +
           ' primeros términos de la sucesión:')
    print sucesion
    sn = (x[1] + x[n]) * n / 2
    print
    print ('S(' + str(n) + ') : (' + str(x[1]) +
           ' + ' + str(x[n]) + ')' + str(n) +
           '/ 2 = ' + str(sn))
    print 'S(', n, ') sumados uno a uno:', suma
    print
    print ('Comprobación: xm + xn = ' +
           'xk+ xl si m+n = k+l: ')
    m = 1
    ene = np.random.random_integers(2, n)
    k = np.random.random_integers(2, ene)
    l = m + ene - k
    print 'm + n = k + l:'
    print m, ' + ', ene, ' = ', k, ' + ', l, ': '
    print (str(x[m]) + ' + ' + str(x[ene]) +
           ' = ' + str(x[k]) + ' + ' + str(x[l]))
    print x[m] + x[ene], ' = ', x[k] + x[l]

aritmetica(10, 100, -3)  # aritmetica(x1,n,d)
