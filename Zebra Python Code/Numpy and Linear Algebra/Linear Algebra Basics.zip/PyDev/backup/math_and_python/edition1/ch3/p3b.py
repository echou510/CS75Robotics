# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p3b.py
progresión geometrica
"""

import numpy as np


def geometrica(x1, n, r):
    x = np.zeros(n + 1, float)
    x[1] = x1
    suma = x[1]
    sucesion = str(x[1]) + ', '
    #print str(x1)
    for i in range(2, n + 1):
        x[i] = x[i - 1] * r
        #print "%.4f" % x[i]
        sucesion = sucesion + "%.8f" % x[i] + ', '
        suma = suma + x[i]
    sucesion = sucesion[0:len(sucesion) - 2]
    print ('x1 =' + str(x[1]) + '; r =' +
           "%.2f" % r + '; n =' + str(n))
    print ('Los ' + str(n) +
           ' primeros términos de la sucesión:')
    print sucesion
    sn = x[1] * (1 - r ** n) / (1 - r)
    print
    strsuma = ('S(' + str(n) + ') : ' +
               str(x1) + '(1 -  ' + "%.2f" % r)
    strsuma = (strsuma + '^' + str(n) +
               ') / (1-' + "%.2f" % r)
    strsuma = strsuma + ') = ' + "%.8f" % sn
    print strsuma
    print ('S(' + str(n) + ') sumados uno a uno:' +
           "%.8f" % suma)

geometrica(100.0, 20, 0.5)  # geometrica(x1,n,r)
