# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p2c.py
operaciones con numeros complejos
"""

import numpy as np


def r2(z):
    a = z.real
    b = z.imag
    rdos = a ** 2 + b ** 2
    return rdos


def modulo(z):
    m = np.sqrt(r2(z))
    return m


def explicacomplejo(z):
    explica = (str(z) + '; Re(z) = ' +
               str(z.real) + '; Im(z) = ' +
               str(z.imag) + '; |z| = ' +
               "%6.4f" % modulo(z) +
               '; r2(z) = ' + str(r2(z)))
    return explica


def str_inverso(z):
    coef = '(1/' + str(r2(z)) + ')'
    conjugado = np.conjugate(z)
    strinverso = coef + '*' + str(conjugado)
    return strinverso


def compruebainverso(z):
    print 'z = ' + str(z)
    print 'conjugado de z = ' + str(np.conjugate(z))
    print 'z * conjugado(z) = ', z * np.conjugate(z)
    print 'inverso de z = ' + str_inverso(z)
    print ('z * inv(z) = ' + str(z) +
           ' * [' + str_inverso(z) + '] = (1/' +
           str(r2(z)) + ') * ' + str(np.conjugate(z)) +
           ' = 1')

print 'potencias de j:'
j = complex(0, 1)
print 'j^1 = j'
print 'j^2 = ' + str(j * j) + ' = -1'
print 'j^3 = ' + str(-1 * j) + ' = -j'
print 'j^4 = ' + str(-j * j) + ' = 1'
print '--------------------------------'
z1 = 3 + 4j
z2 = complex(-1, 1)
print 'z1 = ' + explicacomplejo(z1)
print 'z2 = ' + explicacomplejo(z2)
print 'z1 + z2 = ', z1 + z2
print 'z1 - z2 = ', z1 - z2
print 'z1 * z2 = ', z1 * z2
print '--------------------------------'
print 'comprobación del inverso de z1:'
compruebainverso(z1)
print '--------------------------------'
print 'comprobación del inverso de z2:'
compruebainverso(z2)
