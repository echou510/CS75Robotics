# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p2d.py
representacion de numeros complejos
"""

import matplotlib.pyplot as plt
import numpy as np

j = complex(0, 1)
z1 = complex(2, 2)
z2 = complex(-1.5, -0.5)


def inverso(z):
    ro2 = z.real ** 2 + z.imag ** 2
    inversoz = (np.conj(z) / ro2)
    return inversoz

plt.figure()
plt.ylabel('Im')
plt.xlabel('Re')
plt.axhline(color='black', lw=1)
plt.axvline(color='black', lw=1)
plt.grid(b=None, which='major')
plt.ylim(-5, 3)
plt.xlim(-3, 3)


def flecha(z, texto):
    dx = z.real
    dy = z.imag
    plt.arrow(0, 0, dx, dy, width=0.02, fc='b',
              ec='none', length_includes_head=True, lw=1.5)
    if dx == 0:
        xtexto = dx + 0.05
    else:
        xtexto = np.sign(dx) * (abs(dx) * 1.2)
    if dy == 0:
        ytexto = dy + 0.05
    else:
        ytexto = np.sign(dy) * (abs(dy) * 1.2)
    plt.text(xtexto, ytexto, texto,
             horizontalalignment='center')

flecha(j, 'j')
flecha(z1, 'z1')
flecha(z2, 'z2')
flecha(np.conj(z1), 'conjugado(z1)')
flecha(- z1, 'opuesto(z1)')
flecha(inverso(z1), 'inv(z1)')
flecha(z1 + z2, 'z1+z2')
flecha(z1 * j, 'z1*j')
flecha(z1 * z2, 'z1*z2')
flecha(z1 * inverso(z1), 'z1*inv(z1)')
#plt.savefig('plot02p03.png')
plt.show()
