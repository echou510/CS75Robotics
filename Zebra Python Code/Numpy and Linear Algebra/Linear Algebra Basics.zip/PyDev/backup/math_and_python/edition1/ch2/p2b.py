# -*- coding: utf-8 -*-
"""
Matematicas y programacion en Python
© www.pysamples.com
p2b.py
Calculo de inversa mediante operaciones de filas
en la matriz ampliada
"""

import sympy as sy

a, b, r2 = sy.symbols('a b r2')
sy.init_printing(use_unicode=True)

fila1 = sy.Matrix([[a, b, 1, 0]])
fila2 = sy.Matrix([[-b, a, 0, 1]])
print fila1
print fila2
print 'r2 = a**2 + b**2'


def imprimir():
    print '-------------'
    print fila1
    print fila2


def H(fila, k):
    for columna in range(0, 3):
        Haux = fila * k
        return Haux

fila2 = fila2 + H(fila1, b / a)
imprimir()

fila2[1] = r2 / a
imprimir()

fila2 = fila2 * (a / r2)
imprimir()

fila1 = fila1 + H(fila2, -b)
imprimir()

fila1[2] = a ** 2 / r2
fila1 = fila1 * (1 / a)
imprimir()

print
print 'matriz inversa = '
print '(1/r2) . [', fila1[2] * r2, ', ', fila1[3] * r2, ']'
print '         [', fila2[2] * r2, ', ', fila2[3] * r2, ']'
