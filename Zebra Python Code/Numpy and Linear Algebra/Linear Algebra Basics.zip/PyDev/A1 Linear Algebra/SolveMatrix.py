import numpy as np
A = np.matrix(
    [[1, 4],
     [2, 0]]
)
B = np.matrix(
    [[-1, 2],
     [1, -2]]
)

X = np.linalg.solve(A, B)

print(X)