import numpy as np

matrix1 = np.matrix(
    [[1, 4],
     [2, 0]]
)

matrix2 = np.matrix(
    [[-1, 2],
     [1, -2]]
)

matrix_prod = matrix1 * matrix2

print(matrix_prod)