import numpy as np

matrix1 = np.matrix(
    [[0, 4],
     [2, 0]]
)

matrix2 = np.matrix(
    [[-1, 2],
     [1, -2]]
)

matrix_sum = matrix1 + matrix2

print(matrix_sum)