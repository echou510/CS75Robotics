
import numpy as np
matrix = np.matrix(
    [[1, 4],
     [2, 0]]
)

eigvals = np.linalg.eigvals(matrix)
print("The eigenvalues are %f and %f" %(eigvals[0], eigvals[1]))