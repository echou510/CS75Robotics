
import numpy as np
matrix = np.matrix(
    [[1, 4],
     [2, 0]]
)
svd = np.linalg.svd(matrix)
u = svd[0]
sigma = svd[1]
v = svd[2]
u = u.tolist()
sigma = sigma.tolist()
v = v.tolist()
matrix_prod = [
    ['U   ', '', '\u03A3   ', 'V*   ', ''],
    [u[0][0], u[0][1], sigma[0], v[0][0], v[0][1]],
    [u[1][0], u[1][1], sigma[1], v[1][0], v[1][1]]
]

for i in range(len(matrix_prod)):
    row = matrix_prod[i]
    if (i==0):
        for col in row:
            print("%10s" % str(col), end=" ")
    else:
        for col in row:
            print("%10.6f" % col, end=" ")
    print()
