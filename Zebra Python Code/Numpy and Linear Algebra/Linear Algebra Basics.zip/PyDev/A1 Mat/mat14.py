import numpy as np
import scipy.linalg as la

A = np.array([[1,2],[3,4]])
print(A)
print(la.det(A))