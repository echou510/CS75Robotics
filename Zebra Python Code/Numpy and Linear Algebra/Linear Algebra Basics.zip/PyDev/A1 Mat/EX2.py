import numpy as np

A = np.mat('3 4;-1 2')
print(A)

B = np.mat('5 2;8 -3')
print(B)

I = np.eye(2)
R = A@B + 2 * B@B -I
print(I)
print(R)