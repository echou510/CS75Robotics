import numpy as np
a = np.mat([[7,8], [9,10]])
a[0,0] = 4

print(a)