import numpy as np
s = input("Enter Matrix in String Format: ")
t = s.split(',')
A = np.array([[float(t[0].strip()),float(t[1].strip())],
              [float(t[2].strip()), float(t[3].strip())]
              ])
print(A)
i = int(input("Row i: "))
j = int(input("Row j: "))

dotA = A[i].dot(A[j])
scalarA = np.sum(dotA)
print(dotA)
print(scalarA)