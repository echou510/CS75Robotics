import numpy as np
from numpy import linalg as la
a = np.arange(9) - 4
print('a=', a)
b = a.reshape((3, 3))
print('b=', b)

print(la.norm(a))
print(la.norm(b))
print(la.norm(b, 'fro'))
print(la.norm(a, np.inf))
print(la.norm(b, np.inf))
print(la.norm(a, -np.inf))
print(la.norm(b, -np.inf))
print(la.norm(a, 1))
print(la.norm(b, 1))
print(la.norm(a, -1))
print(la.norm(b, -1))
print(la.norm(a, 2))
print(la.norm(b, 2))
print(la.norm(a, -2))
print(la.norm(b, -2))
print(la.norm(a, 3))
print(la.norm(a, -3))


