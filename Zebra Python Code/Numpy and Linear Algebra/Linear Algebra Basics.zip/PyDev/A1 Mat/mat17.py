import numpy as np
import numpy.linalg as nla
import scipy.linalg as sla
A = np.array([[1, 2], [3, 4]])
print(A)

trace_A = np.trace(A)
det_A = nla.det(A)
I = np.eye(2)
SH = A @ A - trace_A * A + det_A * I
print(SH)