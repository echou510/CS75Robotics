import numpy as np
def proj(v,w):
    '''Project vector v onto w.'''
    v = np.array(v)
    w = np.array(w)
    return np.sum(v * w)/np.sum(w * w) * w   # or (v @ w)/(w @ w) * w
print(proj([1,2,3],[1,1,1]))