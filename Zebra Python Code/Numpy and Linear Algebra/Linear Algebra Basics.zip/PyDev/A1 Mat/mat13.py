import numpy as np
from numpy import linalg as la
# Using the axis argument to compute vector norms:
c = np.array([[ 1, 2, 3],
              [-1, 1, 4]])
print(la.norm(c, axis=0))
print(la.norm(c, axis=1))
print(la.norm(c, ord=1, axis=1))
# Using the axis argument to compute matrix norms:
m = np.arange(8).reshape(2,2,2)
print(la.norm(m, axis=(1,2)))
print(la.norm(m[0, :, :]), la.norm(m[1, :, :]))