import numpy as np
a = np.array([[2,3], [4,5]])
y = np.asmatrix(a)   # shallow copy

a[0,0] = 5

print(y)
