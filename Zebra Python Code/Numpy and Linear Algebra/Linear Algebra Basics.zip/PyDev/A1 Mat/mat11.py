import numpy as np
A = np.array([[1,2],[3,4]])
# sum of the diagonal terms
print(np.trace(A))