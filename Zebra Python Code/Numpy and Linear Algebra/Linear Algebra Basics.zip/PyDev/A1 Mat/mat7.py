import numpy as np

A = np.array([[1,3],[-1,7]])
B = np.array([[5,2],[1,2]])
I = np.eye(2)

X = 2*I + 3*A - A@B
print(X)