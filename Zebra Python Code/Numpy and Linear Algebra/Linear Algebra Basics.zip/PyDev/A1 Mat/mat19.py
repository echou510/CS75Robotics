import numpy as np

A = np.mat("1 2; 3 4")
print(A)
B = np.array(A)
print(B)
r0 = B[0]
rzero = A[0]
# r0 is an array
print(r0)
# rzero is still a matrix
print(rzero)