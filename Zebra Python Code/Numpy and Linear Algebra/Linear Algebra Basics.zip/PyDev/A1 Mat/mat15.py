import numpy as np
x = np.array( ((2,3), (3, 5)) )
y = np.matrix( ((1,2), (5, -1)) )
print(np.dot(x,y))

# Alternatively, we can cast them into matrix objects and use the "*" operator:
z = np.mat(x) * np.mat(y)
print(z)
# 
w = np.mat(x) @ np.mat(y)
print(w)
