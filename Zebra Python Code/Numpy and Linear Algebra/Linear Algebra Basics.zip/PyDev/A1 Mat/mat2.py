import numpy as np
P = np.mat('3 3; 4 4')
Q = np.mat('5 5; 5 5')
R = np.mat('3 4; 5 8')
S = np.mat('6 7; 8 9')
m1 = np.bmat([[P,Q], [R, S]])
print(m1)
