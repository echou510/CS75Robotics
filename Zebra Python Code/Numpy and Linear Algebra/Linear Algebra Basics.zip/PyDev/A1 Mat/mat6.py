import numpy as np
# initializing matrices
x = np.array([[1, 2], [4, 5]])
y = np.array([[7, 8], [9, 10]])
# using dot() to multiply matrices
print ("The product of matrices is : ")
print (np.dot(x,y))
# using sqrt() to print the square root of matrix
print("The element wise square root is : ")
print(np.sqrt(x))
# using sum() to print summation of all elements of matrix
print("The summation of all matrix element is : ")
print(np.sum(y))
# using sum(axis=0) to print summation of all columns of matrix
print("The column wise summation of all matrix  is : ")
print(np.sum(y, axis=0))
# using sum(axis=1) to print summation of all columns of matrix
print("The row wise summation of all matrix  is : ")
print(np.sum(y, axis=1))
# using "T" to transpose the matrix
print("The transpose of given matrix is : ")
print(x.T)