import numpy as np
M = np.array([[3,4],[-1,5]])
print(M)
print(M.T)
print(M@M.T)