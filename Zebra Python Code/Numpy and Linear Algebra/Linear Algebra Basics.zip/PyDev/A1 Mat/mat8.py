import numpy as np
from numpy.linalg import matrix_power as mpow
M = np.array([[3,4],[-1,5]])
print(M)
print(mpow(M,2))
