
public class Frames
{  static int[][] M = {
     {1, 0},
     {0, -1}
   }; 
   
   static int[] T = {100, 500}; 
 
   public static void printMatrix(String title, int[][] m){
        System.out.println(title);
        for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
              System.out.printf("%4d ", m[r][c]);
            }
           System.out.println(); 
        }
        System.out.println(); 
    } 
    
   static point dot(int[][] M, point p){
       int xp = M[0][0]*p.x + M[0][1]*p.y; 
       int yp = M[1][0]*p.x + M[1][1]*p.y; 

       return new point(xp, yp); 
    }
   
   static point translate(int[] T, point p){
      return new point(p.x+T[0], p.y+T[1]); 
    }
   public static void main(String[] args){
       System.out.print("\f"); 
       point p1 = new point(10, 10); 
       System.out.print("Point v: "); 
       System.out.println(p1); 
       System.out.println(); 
       
       printMatrix("Orientation Matrix: ", M); 
       System.out.println(); 
       
       point p2 = dot(M, p1); 
       System.out.print("Point vp: "); 
       System.out.println(p2); 
       System.out.println(); 
       
       point p3 = translate(T, p2); 
       System.out.print("Point u: "); 
       System.out.println(p3); 
       System.out.println(); 
    }
}
