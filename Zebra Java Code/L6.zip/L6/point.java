
public class point{
       int x; 
       int y; 
       point(int x, int y){  this.x = x; this.y =y; }
       public String toString(){ return "<"+x+","+y+">"; }
}