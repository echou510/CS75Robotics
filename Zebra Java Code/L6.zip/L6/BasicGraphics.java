import javax.swing.JFrame;
import javax.swing.JPanel; 
import java.awt.Graphics;
import java.awt.Graphics2D; 
import java.awt.Rectangle; 
import java.awt.Color; 
import java.awt.Dimension; 
public class BasicGraphics extends JPanel{
    static int[][] M = {
     {1, 0},
     {0, -1}
    }; 
   
    static int[] T = {100, 500}; 
    static point end_effector; 
    static point before_orientation; 
    static point end_at_frame0; 
    static point p1; 
    
    static point getframe0(point p){
       point before_orientation = Frames.dot(M, p); 
       point end_at_frame0 = Frames.translate(T, before_orientation); 
       return end_at_frame0; 
    }
    BasicGraphics(){
        end_effector =  new point(10, 10); 
        before_orientation = Frames.dot(M, end_effector); 
        end_at_frame0 = Frames.translate(T, before_orientation); 
        
        p1 = getframe0(end_effector); 
        
        System.out.print("Point v: "); 
        System.out.println(end_effector); 
        System.out.println(); 
       
       
        System.out.print("Point vp: "); 
        System.out.println(before_orientation); 
        System.out.println(); 
       
        System.out.print("Point u: "); 
        System.out.println(end_at_frame0); 
        System.out.println(); 
    }
    public void paintComponent(Graphics g){
      Graphics2D g2 = (Graphics2D) g; 
      g2.setColor(Color.red); 
      int x= p1.x; 
      int y= p1.y; 
      g2.fillOval(x, y, 10, 10);
    }

    
    public static void main(String[] args) {
      JFrame frame = new JFrame(); 
      BasicGraphics c = new BasicGraphics(); 
      c.setSize(800,600); 
      frame.add(c);
      frame.setBackground(Color.white);
      frame.setPreferredSize(new Dimension(800+20, 600+40));
      frame.setSize(800+20,600+40); 
      frame.setTitle("Coordinate Change");
      frame.pack();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
    }
}


