
import javax.swing.JFrame;
import javax.swing.JPanel; 
import java.awt.Graphics;
import java.awt.Graphics2D; 
import java.awt.Rectangle; 
import java.awt.Color; 
import java.awt.Dimension; 

public class BasicGraphics2 extends JPanel{
    static int width = 800; 
    static int height = 600; 
    static int[][] M = {
     {1, 0},
     {0, -1}
    }; 
   
    static int[] T = {100, 500}; 

    static point[] plist = new point[10]; 
    //static point[] plist = {new point(10, 20), new point(20, 40), new point(30, 60), new point(40, 80)}; 
    static int f(int x){
       return x* 3; 
    }
    static point getframe0(point p){
       point before_orientation = Frames.dot(M, p); 
       point end_at_frame0 = Frames.translate(T, before_orientation); 
       return end_at_frame0; 
    }
    BasicGraphics2(){
 
    }
    public void paintComponent(Graphics g){
      Graphics2D g2 = (Graphics2D) g; 
      g2.setColor(Color.BLACK);
      g2.drawLine(0, T[1], width-1, T[1]);
      g2.drawLine(T[0], 0, T[0], height-1); 
      
      g2.setColor(Color.red); 
      
      for (int i=0; i<plist.length; i++){
         plist[i] = new point(i*30, f(i*30)); 
         point p1 = getframe0(plist[i]); 
         int radius=5; 
         int x= p1.x; 
         int y= p1.y; 
         g2.fillOval(x-radius, y-radius, 2*radius, 2*radius);
      }
    }

    
    public static void main(String[] args) {
      JFrame frame = new JFrame(); 
      BasicGraphics2 c = new BasicGraphics2(); 
      c.setSize(width,height); 
      frame.add(c);
      frame.setBackground(Color.white);
      frame.setPreferredSize(new Dimension(width+20, height+40));
      frame.setSize(width+20,height+40); 
      frame.setTitle("Coordinate Change");
      frame.pack();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
    }
}


